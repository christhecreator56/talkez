"use client"

import { useState, useEffect } from "react"

export function useClientOnly<T>(serverFallback: T, clientCallback: () => T): T {
  const [value, setValue] = useState<T>(serverFallback)

  useEffect(() => {
    setValue(clientCallback())
  }, [clientCallback])

  return value
}

export function useWindowSize() {
  const size = useClientOnly(
    { width: 1024, height: 768 }, // Default fallback for server
    () => ({
      width: window.innerWidth,
      height: window.innerHeight,
    }),
  )

  useEffect(() => {
    function handleResize() {
      size.width = window.innerWidth
      size.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [size])

  return size
}

export function useIsMounted() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    return () => setMounted(false)
  }, [])

  return mounted
}
