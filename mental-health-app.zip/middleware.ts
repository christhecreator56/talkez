import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { verifyJwtToken } from "@/lib/jwt"

// This function can be marked `async` if using `await` inside
export async function middleware(request: NextRequest) {
  // Get token from cookies
  const token = request.cookies.get("token")?.value

  // API routes that require authentication
  const authRequiredPaths = ["/api/appointments", "/api/game-scores", "/api/mental-health-profile", "/api/user"]

  // Check if the request is for an API route that requires authentication
  const isAuthRequired = authRequiredPaths.some((path) => request.nextUrl.pathname.startsWith(path))

  // If no token and auth is required, redirect to login
  if (isAuthRequired && !token) {
    return NextResponse.json({ success: false, message: "Authentication required" }, { status: 401 })
  }

  // If token exists, verify it
  if (token) {
    const verifiedToken = await verifyJwtToken(token)

    // If token is invalid, clear it and redirect to login
    if (!verifiedToken) {
      const response = NextResponse.next()
      response.cookies.delete("token")

      if (isAuthRequired) {
        return NextResponse.json({ success: false, message: "Invalid token" }, { status: 401 })
      }

      return response
    }
  }

  return NextResponse.next()
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: [
    "/api/appointments/:path*",
    "/api/game-scores/:path*",
    "/api/mental-health-profile/:path*",
    "/api/user/:path*",
  ],
}
