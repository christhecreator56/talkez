"use client"

import { useState } from "react"
import { HamburgerMenu } from "@/components/hamburger-menu"
import { Logo } from "@/components/logo"
import { GamesTab } from "@/components/games-tab"
import { useRouter } from "next/navigation"
import { LoadingScreen } from "@/components/loading-screen"
import { motion } from "framer-motion"
import { ArrowLeft, Brain, Zap, Trophy, Puzzle } from "lucide-react"

export default function GamesPage() {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleNavigation = (href: string) => {
    setIsLoading(true)
    setTimeout(() => {
      router.push(href)
      setTimeout(() => {
        setIsLoading(false)
      }, 1000)
    }, 100)
  }

  return (
    <>
      {isLoading && <LoadingScreen />}
      <main className="min-h-screen bg-gradient-to-br from-[#FFD166]/30 to-[#FF9F1C]/20">
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <div className="flex items-center">
              <HamburgerMenu />
              <div className="ml-3 flex items-center">
                <Logo />
                <motion.h1
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                  className="text-2xl font-bold text-[#333] ml-3 hidden sm:block"
                >
                  TalkEZ
                </motion.h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex items-center text-gray-600 hover:text-[#FFD166] transition-colors"
                onClick={() => handleNavigation("/dashboard")}
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                <span>Dashboard</span>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.1, rotate: 5 }}
                whileTap={{ scale: 0.9 }}
                className="w-10 h-10 rounded-full bg-[#FFD166] flex items-center justify-center text-[#333] font-medium cursor-pointer shadow-md border-2 border-white"
                onClick={() => handleNavigation("/profile")}
                aria-label="Go to profile"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: "spring", stiffness: 400, damping: 17 }}
              >
                JS
              </motion.button>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-6"
          >
            <div className="flex items-center">
              <div className="w-12 h-12 rounded-full bg-[#FFD166] flex items-center justify-center mr-4">
                <Brain className="h-6 w-6 text-[#333]" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-[#333]">Mind Games</h1>
                <p className="text-gray-600">Engage your brain with fun cognitive exercises</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="mb-8 bg-white p-6 rounded-xl shadow-md"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-[#333]">Your Gaming Stats</h2>
              <div className="flex items-center bg-[#FFD166]/20 px-3 py-1 rounded-full">
                <Zap className="h-5 w-5 text-[#FFD166] mr-2" />
                <span className="font-medium">12 points</span>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex items-center p-4 bg-[#FFD166]/10 rounded-lg">
                <div className="w-10 h-10 rounded-full bg-[#FFD166] flex items-center justify-center mr-3">
                  <Trophy className="h-5 w-5 text-[#333]" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Games Completed</p>
                  <p className="text-xl font-bold text-[#333]">8</p>
                </div>
              </div>
              <div className="flex items-center p-4 bg-[#FFD166]/10 rounded-lg">
                <div className="w-10 h-10 rounded-full bg-[#FFD166] flex items-center justify-center mr-3">
                  <Puzzle className="h-5 w-5 text-[#333]" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Highest Score</p>
                  <p className="text-xl font-bold text-[#333]">Memory Match: 92%</p>
                </div>
              </div>
              <div className="flex items-center p-4 bg-[#FFD166]/10 rounded-lg">
                <div className="w-10 h-10 rounded-full bg-[#FFD166] flex items-center justify-center mr-3">
                  <Brain className="h-5 w-5 text-[#333]" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Cognitive Strength</p>
                  <p className="text-xl font-bold text-[#333]">Memory</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <GamesTab />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="mt-8 bg-white p-6 rounded-xl shadow-md"
          >
            <h2 className="text-xl font-semibold text-[#333] mb-4">Benefits of Mind Games</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex">
                <div className="w-10 h-10 rounded-full bg-[#FFD166]/30 flex items-center justify-center mr-3 flex-shrink-0">
                  <span className="font-bold text-[#333]">1</span>
                </div>
                <div>
                  <h3 className="font-medium text-[#333] mb-1">Improved Memory</h3>
                  <p className="text-sm text-gray-600">
                    Regular memory exercises can help strengthen both short and long-term memory capabilities.
                  </p>
                </div>
              </div>
              <div className="flex">
                <div className="w-10 h-10 rounded-full bg-[#FFD166]/30 flex items-center justify-center mr-3 flex-shrink-0">
                  <span className="font-bold text-[#333]">2</span>
                </div>
                <div>
                  <h3 className="font-medium text-[#333] mb-1">Enhanced Focus</h3>
                  <p className="text-sm text-gray-600">
                    Mind games require concentration, helping you develop better focus for everyday tasks.
                  </p>
                </div>
              </div>
              <div className="flex">
                <div className="w-10 h-10 rounded-full bg-[#FFD166]/30 flex items-center justify-center mr-3 flex-shrink-0">
                  <span className="font-bold text-[#333]">3</span>
                </div>
                <div>
                  <h3 className="font-medium text-[#333] mb-1">Stress Reduction</h3>
                  <p className="text-sm text-gray-600">
                    Taking a mental break with games can help reduce stress and anxiety levels.
                  </p>
                </div>
              </div>
              <div className="flex">
                <div className="w-10 h-10 rounded-full bg-[#FFD166]/30 flex items-center justify-center mr-3 flex-shrink-0">
                  <span className="font-bold text-[#333]">4</span>
                </div>
                <div>
                  <h3 className="font-medium text-[#333] mb-1">Cognitive Flexibility</h3>
                  <p className="text-sm text-gray-600">
                    Games that require quick thinking help improve your ability to adapt to new situations.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
    </>
  )
}
