import { LoadingScreen } from "@/components/loading-screen"

export default function GamesLoading() {
  return <LoadingScreen />
}
