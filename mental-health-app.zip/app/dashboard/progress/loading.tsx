import { LoadingScreen } from "@/components/loading-screen"

export default function ProgressLoading() {
  return <LoadingScreen />
}
