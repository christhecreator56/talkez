"use client"

import { useState } from "react"
import { HamburgerMenu } from "@/components/hamburger-menu"
import { Logo } from "@/components/logo"
import { ProgressOverview } from "@/components/progress/progress-overview"
import { ProgressCharts } from "@/components/progress/progress-charts"
import { ProgressInsights } from "@/components/progress/progress-insights"
import { useRouter } from "next/navigation"
import { LoadingScreen } from "@/components/loading-screen"

export default function ProgressPage() {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleNavigation = (href: string) => {
    setIsLoading(true)
    setTimeout(() => {
      router.push(href)
      setTimeout(() => {
        setIsLoading(false)
      }, 1000)
    }, 100)
  }

  return (
    <>
      {isLoading && <LoadingScreen />}
      <main className="min-h-screen bg-gradient-to-br from-rose-50 to-violet-50">
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <div className="flex items-center">
              <HamburgerMenu />
              <div className="ml-3 flex items-center">
                <Logo />
                <h1 className="text-2xl font-bold text-rose-600 ml-3 hidden sm:block">TalkEZ</h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button
                className="text-gray-600 hover:text-rose-600 transition-colors"
                onClick={() => handleNavigation("/dashboard")}
              >
                Dashboard
              </button>
              <div className="w-10 h-10 rounded-full bg-rose-200 flex items-center justify-center text-rose-600 font-medium">
                JS
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <ProgressOverview />
          <ProgressCharts />
          <ProgressInsights />
        </div>
      </main>
    </>
  )
}
