"use client"

import { useState, useEffect } from "react"
import { HamburgerMenu } from "@/components/hamburger-menu"
import { Logo } from "@/components/logo"
import { useRouter } from "next/navigation"
import { LoadingScreen } from "@/components/loading-screen"
import { Zap, Calendar, Brain, BarChart, MessageSquare } from "lucide-react"

// Remove motion imports and use CSS transitions instead
// This avoids client-side only code during prerendering

export default function Dashboard() {
  const [isLoading, setIsLoading] = useState(false)
  const [energyPoints, setEnergyPoints] = useState(0)
  const [userLevel, setUserLevel] = useState(1)
  const router = useRouter()

  // Calculate user level based on energy points
  const calculateLevel = (points: number) => {
    if (points < 15) return 1
    if (points < 30) return 2
    if (points < 50) return 3
    if (points < 75) return 4
    if (points < 100) return 5
    return Math.floor(points / 20) + 1
  }

  useEffect(() => {
    // Get initial energy points from localStorage or default to 8
    const storedEnergy = localStorage.getItem("energyPoints")
    const initialEnergy = storedEnergy ? Number.parseInt(storedEnergy) : 8
    setEnergyPoints(initialEnergy)
    setUserLevel(calculateLevel(initialEnergy))

    // Listen for energy updates from the progress page
    const handleEnergyUpdate = (event: any) => {
      const newEnergy = event.detail.points
      setEnergyPoints(newEnergy)
      setUserLevel(calculateLevel(newEnergy))
      // Save to localStorage to persist between page refreshes
      localStorage.setItem("energyPoints", newEnergy.toString())
    }

    // Add event listener
    document.addEventListener("energyUpdated", handleEnergyUpdate)

    // Clean up event listener
    return () => {
      document.removeEventListener("energyUpdated", handleEnergyUpdate)
    }
  }, [])

  const handleNavigation = (href: string) => {
    setIsLoading(true)
    setTimeout(() => {
      router.push(href)
      setTimeout(() => {
        setIsLoading(false)
      }, 1000)
    }, 100)
  }

  // Check if we're in a browser environment before rendering
  const isBrowser = typeof window !== "undefined"

  // If not in browser, render a simplified version
  if (!isBrowser) {
    return (
      <div className="min-h-screen bg-[#5ECFBC] p-8">
        <h1 className="text-white text-2xl font-bold">TalkEZ Dashboard</h1>
        <p className="text-white">Loading your mental wellness dashboard...</p>
      </div>
    )
  }

  return (
    <>
      {isLoading && <LoadingScreen />}
      <main className="min-h-screen bg-[#5ECFBC]">
        <header className="bg-[#B4E4E0] shadow-md rounded-b-3xl">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <div className="flex items-center">
              <HamburgerMenu />
              <div className="ml-3 flex items-center">
                <Logo />
                <h1 className="text-2xl font-bold text-[#333] ml-3 hidden sm:block transition-opacity duration-500 opacity-100">
                  TalkEZ
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-white px-3 py-1 rounded-full shadow-md">
                <Zap className="h-5 w-5 text-[#FFD166] mr-2" />
                <span className="font-medium">{energyPoints}</span>
              </div>
              <button
                className="w-12 h-12 rounded-full bg-[#FFD166] flex items-center justify-center text-[#333] font-medium cursor-pointer shadow-md border-2 border-white transition-transform duration-300 hover:scale-105 active:scale-95"
                onClick={() => handleNavigation("/profile")}
                aria-label="Go to profile"
              >
                JS
              </button>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-6 bg-[#B4E4E0] rounded-3xl p-6 shadow-lg transition-all duration-500 opacity-100 translate-y-0">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-[#FFD166] flex items-center justify-center text-[#333] font-bold mr-3 shadow-md">
                  {userLevel}
                </div>
                <h2 className="text-2xl font-bold text-[#333]">Level {userLevel} Explorer</h2>
              </div>
              <div className="flex items-center bg-white px-3 py-1 rounded-full shadow-md">
                <Zap className="h-5 w-5 text-[#FFD166] mr-2" />
                <span className="font-medium">
                  {energyPoints} / {userLevel * 15}
                </span>
              </div>
            </div>
            <div className="bg-white rounded-full h-4 overflow-hidden shadow-inner">
              <div
                className="h-full bg-gradient-to-r from-[#FFD166] to-[#FF9F1C] transition-all duration-1000 ease-out"
                style={{ width: `${((energyPoints % (userLevel * 15) || energyPoints) / (userLevel * 15)) * 100}%` }}
              ></div>
            </div>
            <div className="mt-4 flex justify-between text-sm text-[#333]">
              <span>Level {userLevel}</span>
              <span>Level {userLevel + 1}</span>
            </div>
            <p className="mt-2 text-center text-[#333]">
              Gain <Zap className="h-4 w-4 inline text-[#FFD166]" /> energy to level up and unlock new mental wellness
              techniques!
            </p>
          </div>

          <section className="grid grid-cols-1 gap-4 mb-6">
            <div className="bg-white rounded-3xl shadow-lg p-6 hover:shadow-xl transition-shadow opacity-100 translate-y-0 transition-all duration-300">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-[#B4E4E0] flex items-center justify-center mr-4">
                  <Calendar className="h-6 w-6 text-[#333]" />
                </div>
                <h3 className="text-xl font-semibold text-[#333]">Book Appointment</h3>
              </div>
              <p className="text-gray-600 mb-4">Schedule a session with a mental health professional.</p>
              <button
                className="w-full py-3 rounded-full bg-[#5ECFBC] text-white font-medium text-base transition-transform duration-300 hover:scale-[1.03] active:scale-[0.97]"
                onClick={() => handleNavigation("/appointment")}
              >
                Book Now
              </button>
            </div>

            <div className="bg-white rounded-3xl shadow-lg p-6 hover:shadow-xl transition-shadow opacity-100 translate-y-0 transition-all duration-300 delay-100">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-[#FFD166] flex items-center justify-center mr-4">
                  <Brain className="h-6 w-6 text-[#333]" />
                </div>
                <h3 className="text-xl font-semibold text-[#333]">Mind Games</h3>
              </div>
              <p className="text-gray-600 mb-4">Engage in activities designed to improve mental wellness.</p>
              <button
                className="w-full py-2 rounded-full bg-[#FFD166] text-[#333] font-medium transition-transform duration-300 hover:scale-[1.03] active:scale-[0.97]"
                onClick={() => handleNavigation("/games")}
              >
                Play Now
              </button>
            </div>

            <div className="bg-white rounded-3xl shadow-lg p-6 hover:shadow-xl transition-shadow opacity-100 translate-y-0 transition-all duration-300 delay-200">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-[#FF9F1C] flex items-center justify-center mr-4">
                  <BarChart className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-[#333]">Track Progress</h3>
              </div>
              <p className="text-gray-600 mb-4">Monitor your mental health journey with visual insights.</p>
              <button
                className="w-full py-2 rounded-full bg-[#FF9F1C] text-white font-medium transition-transform duration-300 hover:scale-[1.03] active:scale-[0.97]"
                onClick={() => handleNavigation("/dashboard/progress")}
              >
                View Progress
              </button>
            </div>

            <div className="bg-white rounded-3xl shadow-lg p-6 hover:shadow-xl transition-shadow opacity-100 translate-y-0 transition-all duration-300 delay-300">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-[#8B5CF6] flex items-center justify-center mr-4">
                  <MessageSquare className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-[#333]">Chat Bot</h3>
              </div>
              <p className="text-gray-600 mb-4">Talk to our AI assistant about your mental health concerns.</p>
              <button
                className="w-full py-2 rounded-full bg-[#8B5CF6] text-white font-medium transition-transform duration-300 hover:scale-[1.03] active:scale-[0.97]"
                onClick={() => handleNavigation("/chatbot")}
              >
                Chat Now
              </button>
            </div>
          </section>
        </div>
      </main>
    </>
  )
}
