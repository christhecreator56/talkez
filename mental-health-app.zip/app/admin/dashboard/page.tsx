"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { LoadingScreen } from "@/components/loading-screen"
import { Logo } from "@/components/logo"
import {
  Users,
  Calendar,
  BarChart,
  LogOut,
  Settings,
  User,
  Clock,
  CheckCircle,
  XCircle,
  Zap,
  RefreshCw,
  CheckSquare,
} from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { Switch } from "@/components/ui/switch"

// Admin user type
interface AdminUser {
  id: string
  name: string
  role: "admin" | "counselor"
}

// Appointment type
interface Appointment {
  id: string
  studentName: string
  studentId: string
  date: string
  time: string
  counselorId: string
  status: "upcoming" | "completed" | "cancelled"
  notes?: string
}

// Student type
interface Student {
  id: string
  name: string
  registerNumber: string
  email: string
  lastActive: string
  energyPoints: number
  appointmentsAttended: number
}

// Add TimeSlot and CounselorAvailability interfaces within the existing interfaces
interface TimeSlot {
  id: string
  time: string
  available: boolean
}

interface CounselorAvailability {
  counselorId: string
  dayOfWeek: number // 0-6 (Sunday-Saturday)
  slots: TimeSlot[]
}

// Add the weekdays array after the interfaces
const weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

// Add time slots array after the weekdays
const timeSlotOptions = ["9:00 AM", "10:00 AM", "11:00 AM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM"]

export default function AdminDashboard() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null)
  const [activeTab, setActiveTab] = useState("overview")

  // Add counselorAvailability state to the AdminDashboard component, below the other state declarations
  const [counselorAvailability, setCounselorAvailability] = useState<CounselorAvailability[]>([])
  const [selectedDay, setSelectedDay] = useState<number>(1) // Monday default

  // Mock data for the dashboard
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: "apt-001",
      studentName: "John Smith",
      studentId: "STU001",
      date: "May 15, 2024",
      time: "2:00 PM",
      counselorId: "dr-nisha",
      status: "completed",
      notes: "Discussed anxiety management techniques and breathing exercises for stress reduction.",
    },
    {
      id: "apt-002",
      studentName: "John Smith",
      studentId: "STU001",
      date: "May 22, 2024",
      time: "3:30 PM",
      counselorId: "dr-nisha",
      status: "upcoming",
    },
    {
      id: "apt-003",
      studentName: "Sarah Johnson",
      studentId: "STU002",
      date: "May 18, 2024",
      time: "11:00 AM",
      counselorId: "dr-lavanya",
      status: "upcoming",
    },
    {
      id: "apt-004",
      studentName: "Michael Brown",
      studentId: "STU003",
      date: "May 20, 2024",
      time: "10:00 AM",
      counselorId: "dr-sangeetha",
      status: "upcoming",
    },
    {
      id: "apt-005",
      studentName: "Emily Davis",
      studentId: "STU004",
      date: "May 19, 2024",
      time: "1:00 PM",
      counselorId: "dr-harikumar",
      status: "upcoming",
    },
  ])

  const [students, setStudents] = useState<Student[]>([
    {
      id: "STU001",
      name: "John Smith",
      registerNumber: "REG12345",
      email: "john.smith@example.com",
      lastActive: "Today, 10:30 AM",
      energyPoints: 45,
      appointmentsAttended: 3,
    },
    {
      id: "STU002",
      name: "Sarah Johnson",
      registerNumber: "REG23456",
      email: "sarah.johnson@example.com",
      lastActive: "Yesterday, 3:15 PM",
      energyPoints: 32,
      appointmentsAttended: 2,
    },
    {
      id: "STU003",
      name: "Michael Brown",
      registerNumber: "REG34567",
      email: "michael.brown@example.com",
      lastActive: "May 10, 2024",
      energyPoints: 18,
      appointmentsAttended: 1,
    },
    {
      id: "STU004",
      name: "Emily Davis",
      registerNumber: "REG45678",
      email: "emily.davis@example.com",
      lastActive: "May 12, 2024",
      energyPoints: 27,
      appointmentsAttended: 2,
    },
    {
      id: "STU005",
      name: "David Wilson",
      registerNumber: "REG56789",
      email: "david.wilson@example.com",
      lastActive: "May 14, 2024",
      energyPoints: 15,
      appointmentsAttended: 1,
    },
  ])

  // Check if we're in a browser environment
  const isBrowser = typeof window !== "undefined"

  // Check if user is logged in
  useEffect(() => {
    if (!isBrowser) {
      return // Skip this effect during SSR
    }

    const checkAuth = async () => {
      const storedUser = localStorage.getItem("adminUser")

      if (storedUser) {
        try {
          const user = JSON.parse(storedUser) as AdminUser
          setAdminUser(user)
          setIsLoading(false)
        } catch (error) {
          console.error("Error parsing admin user:", error)
          router.push("/admin/login")
        }
      } else {
        // Not logged in, redirect to login
        router.push("/admin/login")
      }
    }

    checkAuth()
  }, [router, isBrowser])

  const handleLogout = () => {
    if (!isBrowser) return // Skip during SSR

    setIsLoading(true)

    // Clear admin user from localStorage
    localStorage.removeItem("adminUser")

    // Show toast
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out.",
    })

    // Redirect to login page
    setTimeout(() => {
      router.push("/admin/login")
    }, 1000)
  }

  // Add this function inside the AdminDashboard component to load appointments from localStorage
  const loadAppointments = () => {
    if (!isBrowser) return // Skip during SSR

    const storedAppointments = localStorage.getItem("bookedAppointments")

    if (storedAppointments) {
      try {
        // Replace the mock appointments with real data
        setAppointments(JSON.parse(storedAppointments))
      } catch (error) {
        console.error("Error parsing booked appointments:", error)
        // Keep using the mock data if there's an error
      }
    }
  }

  // Update the handleUpdateAppointment function to save changes to localStorage
  const handleUpdateAppointment = (id: string, status: "completed" | "cancelled") => {
    if (!isBrowser) return // Skip during SSR

    // Update appointment status in state
    const updatedAppointments = appointments.map((apt) => (apt.id === id ? { ...apt, status } : apt))

    setAppointments(updatedAppointments)

    // Update localStorage
    localStorage.setItem("bookedAppointments", JSON.stringify(updatedAppointments))

    // Show toast
    toast({
      title: `Appointment ${status === "completed" ? "Completed" : "Cancelled"}`,
      description: `The appointment has been marked as ${status}.`,
    })
  }

  const handleResetTasks = () => {
    if (!isBrowser) return // Skip during SSR

    // Clear task cooldowns from localStorage
    localStorage.removeItem("claimedTasks")

    // Show toast
    toast({
      title: "Tasks Reset",
      description: "All energy tasks have been reset and are now available for students.",
    })
  }

  // Add loadCounselorAvailability function inside the component, below the other functions but before return
  const loadCounselorAvailability = () => {
    if (!isBrowser) return // Skip during SSR

    // In a real app, this would load from an API/database
    // For demo purposes, we're initializing with some default values
    // and storing in localStorage

    const storedAvailability = localStorage.getItem("counselorAvailability")

    if (storedAvailability) {
      try {
        setCounselorAvailability(JSON.parse(storedAvailability))
      } catch (error) {
        console.error("Error parsing counselor availability:", error)
        initializeAvailability()
      }
    } else {
      initializeAvailability()
    }
  }

  // Add initializeAvailability function
  const initializeAvailability = () => {
    if (!isBrowser) return // Skip during SSR

    // Initialize availability for each counselor for each day
    const counselorIds = ["dr-nisha", "dr-lavanya", "dr-sangeetha", "dr-harikumar"]
    const newAvailability: CounselorAvailability[] = []

    counselorIds.forEach((counselorId) => {
      // Create availability for each day of the week (Monday-Friday)
      for (let day = 1; day <= 5; day++) {
        newAvailability.push({
          counselorId,
          dayOfWeek: day,
          slots: timeSlotOptions.map((time) => ({
            id: `${counselorId}-${day}-${time}`,
            time,
            available: Math.random() > 0.3, // Randomly set some slots as available
          })),
        })
      }
    })

    setCounselorAvailability(newAvailability)
    localStorage.setItem("counselorAvailability", JSON.stringify(newAvailability))
  }

  // Add toggleAvailability function
  const toggleAvailability = (slotId: string) => {
    if (!isBrowser) return // Skip during SSR

    const [counselorId, dayOfWeek, time] = slotId.split("-")

    const newAvailability = counselorAvailability.map((item) => {
      if (item.counselorId === counselorId && item.dayOfWeek.toString() === dayOfWeek) {
        return {
          ...item,
          slots: item.slots.map((slot) => {
            if (slot.id === slotId) {
              return { ...slot, available: !slot.available }
            }
            return slot
          }),
        }
      }
      return item
    })

    setCounselorAvailability(newAvailability)
    localStorage.setItem("counselorAvailability", JSON.stringify(newAvailability))

    toast({
      title: "Availability Updated",
      description: `Time slot ${time} is now ${!getSlotAvailability(slotId) ? "available" : "unavailable"}.`,
    })
  }

  // Add getSlotAvailability function
  const getSlotAvailability = (slotId: string): boolean => {
    if (!isBrowser) return false // Skip during SSR

    const [counselorId, dayOfWeek, time] = slotId.split("-")

    const availability = counselorAvailability.find(
      (item) => item.counselorId === counselorId && item.dayOfWeek.toString() === dayOfWeek,
    )

    if (!availability) return false

    const slot = availability.slots.find((slot) => slot.id === slotId)
    return slot ? slot.available : false
  }

  // Add this function to refresh appointments
  const refreshAppointments = () => {
    if (!isBrowser) return // Skip during SSR

    loadAppointments()

    toast({
      title: "Appointments Refreshed",
      description: "The appointments list has been updated with the latest bookings.",
    })
  }

  // Add useEffect to load counselor availability on component mount
  useEffect(() => {
    if (!isBrowser) return // Skip during SSR
    loadCounselorAvailability()
  }, [isBrowser])

  // Add this useEffect to load appointments on component mount
  useEffect(() => {
    if (!isBrowser) return // Skip during SSR
    loadAppointments()
  }, [isBrowser])

  // If not in browser, render a simplified version
  if (!isBrowser) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <h1 className="text-2xl font-bold text-gray-900">TalkEZ Admin Dashboard</h1>
        <p className="text-gray-600">Loading admin dashboard...</p>
      </div>
    )
  }

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <Logo />
            <h1 className="text-2xl font-bold text-[#333] ml-3">TalkEZ Admin</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center space-x-1 bg-[#B4E4E0]/20 px-3 py-1 rounded-full">
              <User className="h-4 w-4 text-[#5ECFBC]" />
              <span className="text-sm font-medium">{adminUser?.name}</span>
              <Badge variant="outline" className="ml-2 text-xs">
                {adminUser?.role === "admin" ? "Admin" : "Counselor"}
              </Badge>
            </div>
            <Button variant="ghost" size="sm" onClick={handleLogout} className="text-gray-500">
              <LogOut className="h-4 w-4 mr-2" />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar */}
          <div className="w-full md:w-64 space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col items-center py-4">
                  <Avatar className="h-20 w-20 mb-4">
                    <AvatarFallback className="bg-[#5ECFBC] text-white text-xl">
                      {adminUser?.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <h2 className="text-xl font-bold text-center">{adminUser?.name}</h2>
                  <Badge className="mt-1">{adminUser?.role === "admin" ? "Administrator" : "Counselor"}</Badge>
                </div>

                <div className="mt-6 space-y-2">
                  <Button
                    variant={activeTab === "overview" ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => setActiveTab("overview")}
                  >
                    <BarChart className="h-4 w-4 mr-2" />
                    Overview
                  </Button>
                  <Button
                    variant={activeTab === "appointments" ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => setActiveTab("appointments")}
                  >
                    <Calendar className="h-4 w-4 mr-2" />
                    Appointments
                  </Button>
                  <Button
                    variant={activeTab === "availability" ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => setActiveTab("availability")}
                  >
                    <Clock className="h-4 w-4 mr-2" />
                    Availability
                  </Button>
                  <Button
                    variant={activeTab === "students" ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => setActiveTab("students")}
                  >
                    <Users className="h-4 w-4 mr-2" />
                    Students
                  </Button>
                  <Button
                    variant={activeTab === "settings" ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => setActiveTab("settings")}
                  >
                    <Settings className="h-4 w-4 mr-2" />
                    Settings
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                      <Users className="h-4 w-4 text-blue-600" />
                    </div>
                    <span className="text-sm">Total Students</span>
                  </div>
                  <span className="font-bold">{students.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                      <Calendar className="h-4 w-4 text-green-600" />
                    </div>
                    <span className="text-sm">Appointments</span>
                  </div>
                  <span className="font-bold">{appointments.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center mr-2">
                      <Clock className="h-4 w-4 text-amber-600" />
                    </div>
                    <span className="text-sm">Upcoming</span>
                  </div>
                  <span className="font-bold">{appointments.filter((apt) => apt.status === "upcoming").length}</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <div className="md:hidden mb-4">
                <TabsList className="grid grid-cols-3 w-full mb-2">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="appointments">Appointments</TabsTrigger>
                  <TabsTrigger value="availability">Availability</TabsTrigger>
                </TabsList>
                <TabsList className="grid grid-cols-2 w-full">
                  <TabsTrigger value="students">Students</TabsTrigger>
                  <TabsTrigger value="settings">Settings</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="overview" className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Dashboard Overview</CardTitle>
                    <CardDescription>
                      Welcome to the TalkEZ admin dashboard. Here's an overview of the system.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium text-gray-500">Total Students</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center">
                            <div className="text-2xl font-bold">{students.length}</div>
                            <div className="ml-auto bg-blue-100 p-2 rounded-full">
                              <Users className="h-5 w-5 text-blue-600" />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium text-gray-500">Upcoming Appointments</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center">
                            <div className="text-2xl font-bold">
                              {appointments.filter((apt) => apt.status === "upcoming").length}
                            </div>
                            <div className="ml-auto bg-green-100 p-2 rounded-full">
                              <Calendar className="h-5 w-5 text-green-600" />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium text-gray-500">Active Counselors</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center">
                            <div className="text-2xl font-bold">4</div>
                            <div className="ml-auto bg-purple-100 p-2 rounded-full">
                              <User className="h-5 w-5 text-purple-600" />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <h3 className="text-lg font-medium mb-4">Recent Appointments</h3>
                    <div className="space-y-4">
                      {appointments.slice(0, 3).map((appointment) => (
                        <Card key={appointment.id} className="overflow-hidden">
                          <CardContent className="p-0">
                            <div className="flex items-center p-4">
                              <div className="flex-shrink-0 mr-4">
                                <Avatar>
                                  <AvatarFallback className="bg-gray-200">
                                    {appointment.studentName
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("")}
                                  </AvatarFallback>
                                </Avatar>
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-gray-900 truncate">{appointment.studentName}</p>
                                <p className="text-sm text-gray-500 truncate">
                                  {appointment.date} at {appointment.time}
                                </p>
                              </div>
                              <div>
                                <Badge
                                  className={
                                    appointment.status === "upcoming"
                                      ? "bg-blue-100 text-blue-800"
                                      : appointment.status === "completed"
                                        ? "bg-green-100 text-green-800"
                                        : "bg-red-100 text-red-800"
                                  }
                                >
                                  {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                                </Badge>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="appointments" className="mt-0">
                <Card>
                  <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
                    <div>
                      <CardTitle>Appointment Management</CardTitle>
                      <CardDescription>View and manage all student appointments.</CardDescription>
                    </div>
                    <Button variant="outline" size="sm" onClick={refreshAppointments} className="mt-4 sm:mt-0">
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Refresh
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {appointments.map((appointment) => (
                        <Card key={appointment.id} className="overflow-hidden">
                          <CardContent className="p-4">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                              <div className="flex items-center mb-4 sm:mb-0">
                                <Avatar className="h-10 w-10 mr-4">
                                  <AvatarFallback className="bg-gray-200">
                                    {appointment.studentName
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("")}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <h4 className="font-medium">{appointment.studentName}</h4>
                                  <p className="text-sm text-gray-500">
                                    {appointment.date} at {appointment.time}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Badge
                                  className={
                                    appointment.status === "upcoming"
                                      ? "bg-blue-100 text-blue-800"
                                      : appointment.status === "completed"
                                        ? "bg-green-100 text-green-800"
                                        : "bg-red-100 text-red-800"
                                  }
                                >
                                  {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                                </Badge>
                                {appointment.status === "upcoming" && (
                                  <div className="flex space-x-2">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      className="text-green-600 border-green-200 hover:bg-green-50"
                                      onClick={() => handleUpdateAppointment(appointment.id, "completed")}
                                    >
                                      <CheckCircle className="h-4 w-4 mr-1" />
                                      Complete
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      className="text-red-600 border-red-200 hover:bg-red-50"
                                      onClick={() => handleUpdateAppointment(appointment.id, "cancelled")}
                                    >
                                      <XCircle className="h-4 w-4 mr-1" />
                                      Cancel
                                    </Button>
                                  </div>
                                )}
                              </div>
                            </div>
                            {appointment.notes && (
                              <div className="mt-4 bg-gray-50 p-3 rounded-md text-sm">
                                <span className="font-medium">Notes:</span> {appointment.notes}
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="availability" className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Counselor Availability</CardTitle>
                    <CardDescription>
                      Manage your available time slots for student appointments. Toggle slots to mark them as available
                      or unavailable.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Day selection */}
                      <div className="flex flex-wrap gap-2">
                        {weekdays.slice(1, 6).map((day, index) => (
                          <Button
                            key={day}
                            variant={selectedDay === index + 1 ? "default" : "outline"}
                            onClick={() => setSelectedDay(index + 1)}
                            className="px-3 py-1 h-auto"
                          >
                            {day}
                          </Button>
                        ))}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Filter counselors based on admin role - system admin sees all, counselors see only their own */}
                        {adminUser?.role === "admin" ? (
                          // For system admin - show all counselors
                          ["dr-nisha", "dr-lavanya", "dr-sangeetha", "dr-harikumar"].map((counselorId) => {
                            const counselorName = {
                              "dr-nisha": "Dr. Nisha",
                              "dr-lavanya": "Dr. Lavanya",
                              "dr-sangeetha": "Dr. Sangeetha",
                              "dr-harikumar": "Dr. Harikumar",
                            }[counselorId]

                            return (
                              <Card key={counselorId}>
                                <CardHeader className="pb-2">
                                  <div className="flex items-center gap-2">
                                    <Avatar className="h-8 w-8">
                                      <AvatarFallback className="bg-[#5ECFBC] text-white">
                                        {counselorName?.charAt(3)}
                                      </AvatarFallback>
                                    </Avatar>
                                    <CardTitle className="text-base">{counselorName}</CardTitle>
                                  </div>
                                </CardHeader>
                                <CardContent>
                                  <div className="space-y-3">
                                    {timeSlotOptions.map((time) => {
                                      const slotId = `${counselorId}-${selectedDay}-${time}`
                                      const isAvailable = getSlotAvailability(slotId)

                                      return (
                                        <div
                                          key={slotId}
                                          className="flex items-center justify-between p-2 rounded-lg border"
                                        >
                                          <div className="flex items-center gap-2">
                                            <div
                                              className={`w-3 h-3 rounded-full ${isAvailable ? "bg-green-500" : "bg-red-500"}`}
                                            ></div>
                                            <span>{time}</span>
                                          </div>
                                          <Switch
                                            checked={isAvailable}
                                            onCheckedChange={() => toggleAvailability(slotId)}
                                          />
                                        </div>
                                      )
                                    })}
                                  </div>
                                </CardContent>
                              </Card>
                            )
                          })
                        ) : (
                          // For counselor - show only their availability
                          <Card>
                            <CardHeader className="pb-2">
                              <div className="flex items-center gap-2">
                                <Avatar className="h-8 w-8">
                                  <AvatarFallback className="bg-[#5ECFBC] text-white">
                                    {adminUser?.name.charAt(3)}
                                  </AvatarFallback>
                                </Avatar>
                                <CardTitle className="text-base">Your Availability</CardTitle>
                              </div>
                            </CardHeader>
                            <CardContent>
                              <div className="space-y-3">
                                {timeSlotOptions.map((time) => {
                                  const slotId = `${adminUser?.id}-${selectedDay}-${time}`
                                  const isAvailable = getSlotAvailability(slotId)

                                  return (
                                    <div
                                      key={slotId}
                                      className="flex items-center justify-between p-2 rounded-lg border"
                                    >
                                      <div className="flex items-center gap-2">
                                        <div
                                          className={`w-3 h-3 rounded-full ${isAvailable ? "bg-green-500" : "bg-red-500"}`}
                                        ></div>
                                        <span>{time}</span>
                                      </div>
                                      <Switch
                                        checked={isAvailable}
                                        onCheckedChange={() => toggleAvailability(slotId)}
                                      />
                                    </div>
                                  )
                                })}
                              </div>
                            </CardContent>
                          </Card>
                        )}
                      </div>

                      <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
                        <div className="flex gap-2">
                          <CheckSquare className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
                          <div>
                            <h4 className="text-blue-800 font-medium">Appointment Booking Rules</h4>
                            <p className="text-sm text-blue-700 mt-1">
                              Students can only book appointments during time slots you've marked as available. Time
                              slots marked red will not be available for booking. Already booked slots will appear in
                              your appointments section.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <div className="mt-8">
                  <h3 className="text-lg font-medium mb-4">Your Upcoming Appointments</h3>
                  <div className="space-y-4">
                    {appointments
                      .filter(
                        (apt) =>
                          apt.status === "upcoming" &&
                          (adminUser?.role === "admin" || apt.counselorId === adminUser?.id),
                      )
                      .slice(0, 5) // Limit to 5 most recent
                      .map((appointment) => (
                        <Card key={appointment.id} className="overflow-hidden">
                          <CardContent className="p-4">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                              <div className="flex items-center mb-4 sm:mb-0">
                                <Avatar className="h-10 w-10 mr-4">
                                  <AvatarFallback className="bg-gray-200">
                                    {appointment.studentName
                                      ?.split(" ")
                                      .map((n) => n[0])
                                      .join("")}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <div className="flex items-center">
                                    <h4 className="font-medium">{appointment.studentName}</h4>
                                    <Badge className="ml-2 bg-blue-100 text-blue-800">Upcoming</Badge>
                                  </div>
                                  <p className="text-sm text-gray-500">
                                    {appointment.date} at {appointment.time}
                                  </p>
                                </div>
                              </div>
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-green-600 border-green-200 hover:bg-green-50"
                                  onClick={() => handleUpdateAppointment(appointment.id, "completed")}
                                >
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Complete
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-red-600 border-red-200 hover:bg-red-50"
                                  onClick={() => handleUpdateAppointment(appointment.id, "cancelled")}
                                >
                                  <XCircle className="h-4 w-4 mr-1" />
                                  Cancel
                                </Button>
                              </div>
                            </div>
                            {appointment.notes && (
                              <div className="mt-4 bg-gray-50 p-3 rounded-md text-sm">
                                <span className="font-medium">Notes:</span> {appointment.notes}
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    {appointments.filter(
                      (apt) =>
                        apt.status === "upcoming" && (adminUser?.role === "admin" || apt.counselorId === adminUser?.id),
                    ).length === 0 && (
                      <div className="text-center p-6 bg-gray-50 rounded-lg">
                        <p className="text-gray-500">No upcoming appointments found.</p>
                      </div>
                    )}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="students" className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Student Management</CardTitle>
                    <CardDescription>View and manage student information and progress.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {students.map((student) => (
                        <Card key={student.id} className="overflow-hidden">
                          <CardContent className="p-4">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                              <div className="flex items-center mb-4 sm:mb-0">
                                <Avatar className="h-10 w-10 mr-4">
                                  <AvatarFallback className="bg-gray-200">
                                    {student.name
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("")}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <h4 className="font-medium">{student.name}</h4>
                                  <p className="text-sm text-gray-500">{student.email}</p>
                                  <p className="text-xs text-gray-400">Reg: {student.registerNumber}</p>
                                </div>
                              </div>
                              <div className="flex flex-col sm:items-end">
                                <div className="flex items-center mb-1">
                                  <Zap className="h-4 w-4 text-[#FFD166] mr-1" />
                                  <span className="text-sm font-medium">{student.energyPoints} energy points</span>
                                </div>
                                <p className="text-xs text-gray-500">Last active: {student.lastActive}</p>
                                <p className="text-xs text-gray-500">Appointments: {student.appointmentsAttended}</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="settings" className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle>System Settings</CardTitle>
                    <CardDescription>Manage system settings and perform administrative tasks.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Energy Task Management</h3>
                      <Card className="bg-amber-50 border-amber-200">
                        <CardContent className="p-4">
                          <div className="flex items-start">
                            <div className="mr-4 mt-1">
                              <RefreshCw className="h-5 w-5 text-amber-500" />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-medium text-amber-800 mb-2">Reset Energy Tasks</h4>
                              <p className="text-sm text-amber-700 mb-4">
                                This will reset all energy task cooldowns for all students, making them immediately
                                available again. Use this feature with caution.
                              </p>
                              <Button
                                variant="outline"
                                className="bg-white border-amber-300 text-amber-700 hover:bg-amber-100"
                                onClick={handleResetTasks}
                              >
                                <RefreshCw className="h-4 w-4 mr-2" />
                                Reset All Tasks
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Counselor Management</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Card>
                          <CardContent className="p-4">
                            <div className="flex items-center">
                              <Avatar className="h-10 w-10 mr-3">
                                <AvatarFallback className="bg-[#5ECFBC] text-white">N</AvatarFallback>
                              </Avatar>
                              <div>
                                <h4 className="font-medium">Dr. Nisha</h4>
                                <p className="text-sm text-gray-500">Anxiety & Stress Management</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4">
                            <div className="flex items-center">
                              <Avatar className="h-10 w-10 mr-3">
                                <AvatarFallback className="bg-[#FFD166] text-[#333]">L</AvatarFallback>
                              </Avatar>
                              <div>
                                <h4 className="font-medium">Dr. Lavanya</h4>
                                <p className="text-sm text-gray-500">Depression & Mood Disorders</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4">
                            <div className="flex items-center">
                              <Avatar className="h-10 w-10 mr-3">
                                <AvatarFallback className="bg-[#FF9F1C] text-white">S</AvatarFallback>
                              </Avatar>
                              <div>
                                <h4 className="font-medium">Dr. Sangeetha</h4>
                                <p className="text-sm text-gray-500">Academic Pressure & Career</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4">
                            <div className="flex items-center">
                              <Avatar className="h-10 w-10 mr-3">
                                <AvatarFallback className="bg-[#8B5CF6] text-white">H</AvatarFallback>
                              </Avatar>
                              <div>
                                <h4 className="font-medium">Dr. Harikumar</h4>
                                <p className="text-sm text-gray-500">Relationships & Social Issues</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </main>
  )
}
