"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { LoadingScreen } from "@/components/loading-screen"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import { Users, Calendar, Activity, Award, TrendingUp, RefreshCw } from "lucide-react"

// Define types for our stats
interface AdminStats {
  overview: {
    totalUsers: number
    activeUsers: number
    totalAppointments: number
    totalGameScores: number
  }
  appointmentsByStatus: Array<{
    _id: string
    count: number
  }>
  gamePopularity: Array<{
    _id: string
    count: number
    avgScore: number
  }>
  newUsersPerDay: Array<{
    _id: string
    count: number
  }>
}

export default function AnalyticsDashboard() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [refreshing, setRefreshing] = useState(false)

  // Colors for charts
  const COLORS = ["#5ECFBC", "#FF9F1C", "#F25C54", "#8B5CF6", "#3B82F6"]

  // Fetch stats from API
  const fetchStats = async () => {
    try {
      setRefreshing(true)
      const response = await fetch("/api/admin/stats")

      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          // Redirect to login if unauthorized
          router.push("/admin/login")
          return
        }
        throw new Error(`Error ${response.status}: ${response.statusText}`)
      }

      const data = await response.json()
      setStats(data)
      setError(null)
    } catch (err) {
      console.error("Failed to fetch stats:", err)
      setError("Failed to load analytics data. Please try again.")
    } finally {
      setIsLoading(false)
      setRefreshing(false)
    }
  }

  // Load stats on component mount
  useEffect(() => {
    fetchStats()
  }, [router])

  // Format appointment status data for pie chart
  const formatAppointmentData = () => {
    if (!stats?.appointmentsByStatus) return []

    return stats.appointmentsByStatus.map((item) => ({
      name: item._id.charAt(0).toUpperCase() + item._id.slice(1),
      value: item.count,
    }))
  }

  // Format game popularity data for bar chart
  const formatGameData = () => {
    if (!stats?.gamePopularity) return []

    return stats.gamePopularity.map((item) => ({
      name:
        item._id === "memoryMatch"
          ? "Memory Match"
          : item._id === "wordAssociation"
            ? "Word Association"
            : item._id === "numberNinja"
              ? "Number Ninja"
              : item._id === "patternPuzzle"
                ? "Pattern Puzzle"
                : item._id,
      plays: item.count,
      avgScore: Math.round(item.avgScore * 10) / 10,
    }))
  }

  // Format new users data for line chart
  const formatNewUsersData = () => {
    if (!stats?.newUsersPerDay) return []

    return stats.newUsersPerDay.map((item) => ({
      date: item._id,
      users: item.count,
    }))
  }

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <main className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-800">Analytics Dashboard</h1>
            <p className="text-gray-500 mt-1">Monitor app usage and user engagement</p>
          </div>
          <Button onClick={fetchStats} disabled={refreshing} className="mt-4 md:mt-0">
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
            {refreshing ? "Refreshing..." : "Refresh Data"}
          </Button>
        </div>

        {error && (
          <Card className="mb-8 border-red-200 bg-red-50">
            <CardContent className="p-4">
              <p className="text-red-600">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* Overview Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Users</p>
                  <h3 className="text-2xl font-bold mt-1">{stats?.overview.totalUsers || 0}</h3>
                </div>
                <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  {stats?.overview.activeUsers || 0} active users
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-500">Appointments</p>
                  <h3 className="text-2xl font-bold mt-1">{stats?.overview.totalAppointments || 0}</h3>
                </div>
                <div className="h-12 w-12 bg-rose-100 rounded-full flex items-center justify-center">
                  <Calendar className="h-6 w-6 text-rose-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                  {stats?.appointmentsByStatus.find((a) => a._id === "upcoming")?.count || 0} upcoming
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-500">Game Sessions</p>
                  <h3 className="text-2xl font-bold mt-1">{stats?.overview.totalGameScores || 0}</h3>
                </div>
                <div className="h-12 w-12 bg-amber-100 rounded-full flex items-center justify-center">
                  <Award className="h-6 w-6 text-amber-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                  {stats?.gamePopularity[0]?._id || "No"} most popular
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-500">User Growth</p>
                  <h3 className="text-2xl font-bold mt-1">
                    {stats?.newUsersPerDay.reduce((sum, day) => sum + day.count, 0) || 0}
                  </h3>
                </div>
                <div className="h-12 w-12 bg-emerald-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-emerald-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <Badge variant="outline" className="bg-teal-50 text-teal-700 border-teal-200">
                  Last 30 days
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>User Growth</CardTitle>
              <CardDescription>New user registrations over the last 30 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={formatNewUsersData()} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis
                      dataKey="date"
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value) => {
                        const date = new Date(value)
                        return `${date.getDate()}/${date.getMonth() + 1}`
                      }}
                    />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="users"
                      name="New Users"
                      stroke="#5ECFBC"
                      activeDot={{ r: 8 }}
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Appointment Distribution</CardTitle>
              <CardDescription>Breakdown of appointments by status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80 flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={formatAppointmentData()}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {formatAppointmentData().map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Game Popularity</CardTitle>
            <CardDescription>Number of plays and average scores by game</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={formatGameData()} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" orientation="left" stroke="#5ECFBC" />
                  <YAxis yAxisId="right" orientation="right" stroke="#FF9F1C" />
                  <Tooltip />
                  <Legend />
                  <Bar yAxisId="left" dataKey="plays" name="Total Plays" fill="#5ECFBC" />
                  <Bar yAxisId="right" dataKey="avgScore" name="Avg Score" fill="#FF9F1C" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* User Activity Heatmap would go here */}
        <Card>
          <CardHeader>
            <CardTitle>User Activity</CardTitle>
            <CardDescription>Active users by hour and day of week</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="flex items-center justify-center h-60 bg-gray-100 rounded-md">
              <div className="text-center">
                <Activity className="h-10 w-10 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500">Activity heatmap will be available soon</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
