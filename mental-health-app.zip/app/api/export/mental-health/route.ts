import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import MentalHealthProfile from "@/models/MentalHealthProfile"
import { verifyToken } from "@/lib/jwt"

export async function GET(req: NextRequest) {
  try {
    // Verify user authentication
    const token = req.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const payload = await verifyToken(token)
    if (!payload || !payload.userId) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    // Get format from query params
    const url = new URL(req.url)
    const format = url.searchParams.get("format") || "json"

    // Connect to database
    await connectToDatabase()

    // Get user's mental health data
    const mentalHealthData = await MentalHealthProfile.findOne({
      userId: payload.userId,
    })

    if (!mentalHealthData) {
      return NextResponse.json({ error: "No mental health data found" }, { status: 404 })
    }

    // Format data based on requested format
    switch (format.toLowerCase()) {
      case "csv":
        return formatCSV(mentalHealthData)
      case "text":
        return formatText(mentalHealthData)
      case "json":
      default:
        return NextResponse.json(mentalHealthData)
    }
  } catch (error) {
    console.error("Error exporting mental health data:", error)
    return NextResponse.json({ error: "Failed to export mental health data" }, { status: 500 })
  }
}

function formatCSV(data: any) {
  try {
    // Convert data to CSV format
    const headers = Object.keys(data._doc).filter((key) => key !== "_id" && key !== "__v")
    let csv = headers.join(",") + "\n"

    const values = headers.map((header) => {
      const value = data[header]
      if (typeof value === "object" && value !== null) {
        return JSON.stringify(value).replace(/,/g, ";")
      }
      return value
    })

    csv += values.join(",")

    // Return CSV response
    return new NextResponse(csv, {
      headers: {
        "Content-Type": "text/csv",
        "Content-Disposition": 'attachment; filename="mental_health_data.csv"',
      },
    })
  } catch (error) {
    console.error("Error formatting CSV:", error)
    return NextResponse.json({ error: "Failed to format data as CSV" }, { status: 500 })
  }
}

function formatText(data: any) {
  try {
    // Convert data to readable text format
    let text = "MENTAL HEALTH DATA EXPORT\n"
    text += "===========================\n\n"

    Object.entries(data._doc)
      .filter(([key]) => key !== "_id" && key !== "__v")
      .forEach(([key, value]) => {
        text += `${key.toUpperCase()}:\n`
        if (typeof value === "object" && value !== null) {
          Object.entries(value as object).forEach(([subKey, subValue]) => {
            text += `  ${subKey}: ${subValue}\n`
          })
        } else {
          text += `  ${value}\n`
        }
        text += "\n"
      })

    // Return text response
    return new NextResponse(text, {
      headers: {
        "Content-Type": "text/plain",
        "Content-Disposition": 'attachment; filename="mental_health_data.txt"',
      },
    })
  } catch (error) {
    console.error("Error formatting text:", error)
    return NextResponse.json({ error: "Failed to format data as text" }, { status: 500 })
  }
}
