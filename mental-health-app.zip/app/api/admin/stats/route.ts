import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import User from "@/models/User"
import Appointment from "@/models/Appointment"
import GameScore from "@/models/GameScore"
import { verifyToken } from "@/lib/jwt"

export async function GET(req: NextRequest) {
  try {
    // Verify admin access
    const token = req.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const payload = await verifyToken(token)
    if (!payload || payload.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Connect to database
    await connectToDatabase()

    // Get basic stats
    const totalUsers = await User.countDocuments()
    const totalAppointments = await Appointment.countDocuments()
    const totalGameScores = await GameScore.countDocuments()

    // Get active users (users who logged in within the last 7 days)
    const sevenDaysAgo = new Date()
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

    const activeUsers = await User.countDocuments({
      lastLogin: { $gte: sevenDaysAgo },
    })

    // Get appointment stats
    const appointmentsByStatus = await Appointment.aggregate([
      {
        $group: {
          _id: "$status",
          count: { $sum: 1 },
        },
      },
    ])

    // Get game popularity
    const gamePopularity = await GameScore.aggregate([
      {
        $group: {
          _id: "$gameType",
          count: { $sum: 1 },
          avgScore: { $avg: "$score" },
        },
      },
      {
        $sort: { count: -1 },
      },
    ])

    // Get new users per day (last 30 days)
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    const newUsersPerDay = await User.aggregate([
      {
        $match: {
          createdAt: { $gte: thirtyDaysAgo },
        },
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$createdAt" },
          },
          count: { $sum: 1 },
        },
      },
      {
        $sort: { _id: 1 },
      },
    ])

    return NextResponse.json({
      overview: {
        totalUsers,
        activeUsers,
        totalAppointments,
        totalGameScores,
      },
      appointmentsByStatus,
      gamePopularity,
      newUsersPerDay,
    })
  } catch (error) {
    console.error("Error fetching admin stats:", error)
    return NextResponse.json({ error: "Failed to fetch admin statistics" }, { status: 500 })
  }
}
