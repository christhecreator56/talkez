import { NextResponse } from "next/server"
import dbConnect from "@/lib/mongodb"
import GameScore from "@/models/GameScore"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"

// GET high scores for a specific game
export async function GET(req: Request) {
  try {
    // Connect to database
    await dbConnect()

    // Get query parameters
    const { searchParams } = new URL(req.url)
    const gameType = searchParams.get("gameType")
    const userId = searchParams.get("userId")

    if (!gameType) {
      return NextResponse.json({ success: false, message: "Game type is required" }, { status: 400 })
    }

    // Build query
    const query: any = { gameType }
    if (userId) {
      query.userId = userId
    }

    // Find high scores
    const scores = await GameScore.find(query).sort({ score: -1 }).limit(10).populate("userId", "name")

    return NextResponse.json({ success: true, scores }, { status: 200 })
  } catch (error) {
    console.error("Error fetching game scores:", error)
    return NextResponse.json({ success: false, message: "Error fetching game scores" }, { status: 500 })
  }
}

// POST save a new game score
export async function POST(req: Request) {
  try {
    // Get user from session
    const session = await getServerSession(authOptions)
    if (!session || !session.user) {
      return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
    }

    // Connect to database
    await dbConnect()

    // Get score data
    const scoreData = await req.json()

    // Create score
    const score = await GameScore.create({
      userId: session.user.id,
      gameType: scoreData.gameType,
      score: scoreData.score,
      level: scoreData.level,
      timeSpent: scoreData.timeSpent,
      difficulty: scoreData.difficulty,
    })

    // Get user's high score for this game
    const highScore = await GameScore.findOne({
      userId: session.user.id,
      gameType: scoreData.gameType,
    })
      .sort({ score: -1 })
      .limit(1)

    return NextResponse.json(
      {
        success: true,
        score,
        isHighScore: !highScore || score.score > highScore.score,
        highScore: highScore ? highScore.score : score.score,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Error saving game score:", error)
    return NextResponse.json({ success: false, message: "Error saving game score" }, { status: 500 })
  }
}
