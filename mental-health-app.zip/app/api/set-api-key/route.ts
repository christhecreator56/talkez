import { NextResponse } from "next/server"

export async function POST(req: Request) {
  try {
    const { apiKey } = await req.json()

    if (!apiKey) {
      return NextResponse.json({ success: false, message: "API key is required" }, { status: 400 })
    }

    // In a real application, you would securely store this in environment variables
    // or a secure storage solution. This is just for demonstration purposes.
    // process.env.GOOGLE_GENERATIVE_AI_API_KEY = apiKey

    return NextResponse.json({ success: true, message: "API key set successfully" })
  } catch (error) {
    console.error("Error setting API key:", error)
    return NextResponse.json({ success: false, message: "Failed to set API key" }, { status: 500 })
  }
}
