import { NextResponse } from "next/server"
import dbConnect from "@/lib/mongodb"
import Appointment from "@/models/Appointment"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"

// GET all appointments for the current user
export async function GET(req: Request) {
  try {
    // Get user from session
    const session = await getServerSession(authOptions)
    if (!session || !session.user) {
      return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
    }

    // Connect to database
    await dbConnect()

    // Get query parameters
    const { searchParams } = new URL(req.url)
    const status = searchParams.get("status")

    // Build query
    const query: any = { userId: session.user.id }
    if (status) {
      query.status = status
    }

    // Find appointments
    const appointments = await Appointment.find(query).sort({ date: 1, time: 1 })

    return NextResponse.json({ success: true, appointments }, { status: 200 })
  } catch (error) {
    console.error("Error fetching appointments:", error)
    return NextResponse.json({ success: false, message: "Error fetching appointments" }, { status: 500 })
  }
}

// POST create a new appointment
export async function POST(req: Request) {
  try {
    // Get user from session
    const session = await getServerSession(authOptions)
    if (!session || !session.user) {
      return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
    }

    // Connect to database
    await dbConnect()

    // Get appointment data
    const appointmentData = await req.json()

    // Create appointment
    const appointment = await Appointment.create({
      userId: session.user.id,
      counselorId: appointmentData.counselorId,
      date: new Date(appointmentData.date),
      time: appointmentData.time,
      sessionType: appointmentData.sessionType,
      notes: appointmentData.notes,
      status: "upcoming",
    })

    return NextResponse.json({ success: true, appointment }, { status: 201 })
  } catch (error) {
    console.error("Error creating appointment:", error)
    return NextResponse.json({ success: false, message: "Error creating appointment" }, { status: 500 })
  }
}
