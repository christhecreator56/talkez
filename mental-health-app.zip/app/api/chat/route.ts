import { NextResponse } from "next/server"

// Define the system prompt for a more natural, conversational mental health assistant
const SYSTEM_PROMPT = `
You are Emma, a warm and empathetic mental health companion for college students.

Your personality:
- You're compassionate, understanding, and genuinely caring
- You use a conversational, friendly tone (not clinical or robotic)
- You occasionally use light emojis where appropriate (but don't overdo it)
- You ask thoughtful follow-up questions to show you're listening
- You share brief personal anecdotes when relevant (as if you were a fellow student)
- You validate feelings first before offering suggestions
- You use casual language like "I get that" or "That sounds tough"

Guidelines:
- Respond like a supportive friend, not a therapist or AI
- Use the student's name if they share it
- Keep responses concise and conversational (2-4 sentences is often enough)
- Show genuine curiosity about their experiences
- Acknowledge emotions explicitly ("It sounds like you're feeling...")
- Offer practical, relatable advice a friend might give
- For serious concerns, gently suggest professional resources
- Never use clinical language or sound like you're diagnosing

Remember, you're having a natural conversation, not delivering a mental health lecture. Be real, be kind, and be present.
`

// The API key provided by the user
const FALLBACK_API_KEY = "AIzaSyBGT-m-2J_OHlMwqjz60acqLwdBnZNbb5s"

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // Get the last user message
    const lastMessage = messages[messages.length - 1]

    // Use the API key from environment variables or the fallback key
    const apiKey = process.env.GOOGLE_GENERATIVE_AI_API_KEY || process.env.GOOGLE_AI_API_KEY || FALLBACK_API_KEY

    try {
      // Prepare the conversation history for the API
      const conversationHistory = messages.slice(0, -1).map((msg) => ({
        role: msg.role === "user" ? "user" : "model",
        parts: [{ text: msg.content }],
      }))

      // Add system prompt as a "model" message at the beginning if there's no system message yet
      if (conversationHistory.length === 0 || conversationHistory[0].role !== "model") {
        conversationHistory.unshift({
          role: "model",
          parts: [{ text: SYSTEM_PROMPT }],
        })
      }

      // Add the current user message
      const userMessage = {
        role: "user",
        parts: [{ text: lastMessage.content }],
      }

      // Prepare the API request payload
      const payload = {
        contents: [...conversationHistory, userMessage],
        generationConfig: {
          temperature: 0.9, // Increased for more natural variation
          topP: 0.95,
          topK: 40,
          maxOutputTokens: 1024,
        },
        safetySettings: [
          {
            category: "HARM_CATEGORY_HARASSMENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE",
          },
          {
            category: "HARM_CATEGORY_HATE_SPEECH",
            threshold: "BLOCK_MEDIUM_AND_ABOVE",
          },
          {
            category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE",
          },
          {
            category: "HARM_CATEGORY_DANGEROUS_CONTENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE",
          },
        ],
      }

      // Make the API request to Gemini
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        },
      )

      if (!response.ok) {
        const errorData = await response.json()
        console.error("Gemini API error:", errorData)
        throw new Error(`API request failed with status ${response.status}: ${JSON.stringify(errorData)}`)
      }

      const data = await response.json()

      // Extract the response text
      const responseText =
        data.candidates?.[0]?.content?.parts?.[0]?.text ||
        "I'm having trouble generating a response right now. Please try again."

      return NextResponse.json({
        role: "assistant",
        content: responseText,
      })
    } catch (apiError) {
      console.error("Error with Google Generative AI API:", apiError)
      return NextResponse.json({
        role: "assistant",
        content: "Sorry, I'm having a bit of trouble connecting right now. Can we try again in a moment?",
      })
    }
  } catch (error) {
    console.error("Error in chat API:", error)
    return NextResponse.json({
      role: "assistant",
      content:
        "I seem to be having some connection issues. If you need immediate support, reaching out to your university's counseling services might be helpful right now.",
    })
  }
}
