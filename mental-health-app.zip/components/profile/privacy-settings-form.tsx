"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"
import { AlertTriangle, Loader2 } from "lucide-react"

// Default data for v85 version (no database connection)
const defaultPrivacySettings = {
  shareDataWithCounselors: true,
  receiveAppointmentReminders: true,
  receiveEmailUpdates: false,
  allowAnonymizedDataUse: true,
  twoFactorAuth: false,
  activityLogging: true,
}

export function PrivacySettingsForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [settings, setSettings] = useState(defaultPrivacySettings)

  // Load data from localStorage
  useEffect(() => {
    const savedData = localStorage.getItem("talkez_privacy_settings")
    if (savedData) {
      setSettings(JSON.parse(savedData))
    }
    setIsLoading(false)
  }, [])

  const handleToggle = (setting: keyof typeof settings) => {
    setSettings((prev) => ({ ...prev, [setting]: !prev[setting] }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Save to localStorage
    localStorage.setItem("talkez_privacy_settings", JSON.stringify(settings))

    // Simulate API delay
    setTimeout(() => {
      setIsSubmitting(false)
      toast({
        title: "Privacy Settings Updated",
        description: "Your privacy preferences have been saved successfully.",
      })
    }, 800)
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6 flex justify-center items-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Privacy & Security</CardTitle>
        <CardDescription>
          Manage how your information is used and protected. We take your privacy seriously.
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Data Sharing</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="shareDataWithCounselors">Share data with counselors</Label>
                  <p className="text-sm text-gray-500">Allow your counselors to access your mental health profile</p>
                </div>
                <Switch
                  id="shareDataWithCounselors"
                  checked={settings.shareDataWithCounselors}
                  onCheckedChange={() => handleToggle("shareDataWithCounselors")}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="allowAnonymizedDataUse">Anonymized data for research</Label>
                  <p className="text-sm text-gray-500">Allow anonymized data to be used for mental health research</p>
                </div>
                <Switch
                  id="allowAnonymizedDataUse"
                  checked={settings.allowAnonymizedDataUse}
                  onCheckedChange={() => handleToggle("allowAnonymizedDataUse")}
                />
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h3 className="text-lg font-medium">Notifications</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="receiveAppointmentReminders">Appointment reminders</Label>
                  <p className="text-sm text-gray-500">Receive notifications about upcoming appointments</p>
                </div>
                <Switch
                  id="receiveAppointmentReminders"
                  checked={settings.receiveAppointmentReminders}
                  onCheckedChange={() => handleToggle("receiveAppointmentReminders")}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="receiveEmailUpdates">Email updates</Label>
                  <p className="text-sm text-gray-500">Receive emails about new features and mental health resources</p>
                </div>
                <Switch
                  id="receiveEmailUpdates"
                  checked={settings.receiveEmailUpdates}
                  onCheckedChange={() => handleToggle("receiveEmailUpdates")}
                />
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h3 className="text-lg font-medium">Security</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="twoFactorAuth">Two-factor authentication</Label>
                  <p className="text-sm text-gray-500">Add an extra layer of security to your account</p>
                </div>
                <Switch
                  id="twoFactorAuth"
                  checked={settings.twoFactorAuth}
                  onCheckedChange={() => handleToggle("twoFactorAuth")}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="activityLogging">Activity logging</Label>
                  <p className="text-sm text-gray-500">Keep a record of account activity for security purposes</p>
                </div>
                <Switch
                  id="activityLogging"
                  checked={settings.activityLogging}
                  onCheckedChange={() => handleToggle("activityLogging")}
                />
              </div>
            </div>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-md p-4 flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 flex-shrink-0" />
            <div>
              <h4 className="font-medium text-amber-800">Data Deletion</h4>
              <p className="text-sm text-amber-700 mt-1">
                If you wish to delete your account and all associated data, please contact our support team. This action
                cannot be undone.
              </p>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isSubmitting} className="ml-auto">
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              "Save Changes"
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
