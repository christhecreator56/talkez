"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "@/hooks/use-toast"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

type Appointment = {
  id: string
  date: string
  time: string
  counselor: string
  type: string
  status: "completed" | "upcoming" | "cancelled"
  notes?: string
}

export function AppointmentHistory() {
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: "apt-001",
      date: "May 15, 2024",
      time: "2:00 PM",
      counselor: "Dr. Nisha",
      type: "Initial Consultation",
      status: "completed",
      notes: "Discussed anxiety management techniques and breathing exercises for stress reduction.",
    },
    {
      id: "apt-002",
      date: "May 22, 2024",
      time: "3:30 PM",
      counselor: "Dr. Nisha",
      type: "Follow-up Session",
      status: "upcoming",
    },
    {
      id: "apt-003",
      date: "June 5, 2024",
      time: "11:00 AM",
      counselor: "Dr. Lavanya",
      type: "Depression Assessment",
      status: "upcoming",
    },
  ])
  const [isLoading, setIsLoading] = useState<string | null>(null)
  const router = useRouter()

  const handleReschedule = (appointmentId: string) => {
    setIsLoading(appointmentId + "-reschedule")

    // Simulate API call
    setTimeout(() => {
      setIsLoading(null)
      // Navigate to appointment page
      router.push("/appointment")

      toast({
        title: "Reschedule initiated",
        description: "You can now select a new date and time for your appointment.",
      })
    }, 1000)
  }

  const handleCancel = (appointmentId: string) => {
    setIsLoading(appointmentId + "-cancel")

    // Simulate API call
    setTimeout(() => {
      // Update the appointment status to cancelled
      setAppointments(
        appointments.map((appointment) =>
          appointment.id === appointmentId ? { ...appointment, status: "cancelled" } : appointment,
        ),
      )

      setIsLoading(null)

      toast({
        title: "Appointment Cancelled",
        description: "Your appointment has been successfully cancelled.",
      })
    }, 1000)
  }

  const getStatusColor = (status: Appointment["status"]) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "upcoming":
        return "bg-blue-100 text-blue-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Appointment History</CardTitle>
        <CardDescription>View your past and upcoming appointments.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {appointments.length > 0 ? (
            appointments.map((appointment) => (
              <div key={appointment.id} className="border rounded-lg p-4 hover:border-[#5ECFBC] transition-colors">
                <div className="flex flex-col sm:flex-row justify-between mb-2">
                  <div className="flex items-center gap-2 mb-2 sm:mb-0">
                    <h3 className="font-medium">{appointment.type}</h3>
                    <Badge className={getStatusColor(appointment.status)}>
                      {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-500">
                    {appointment.date} at {appointment.time}
                  </div>
                </div>
                <p className="text-sm mb-2">
                  <span className="font-medium">Counselor:</span> {appointment.counselor}
                </p>
                {appointment.notes && (
                  <div className="mt-2 text-sm bg-gray-50 p-3 rounded-md">
                    <span className="font-medium">Session Notes:</span> {appointment.notes}
                  </div>
                )}
                {appointment.status === "upcoming" && (
                  <div className="mt-3 flex justify-end gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-amber-600 border-amber-200 hover:bg-amber-50"
                      onClick={() => handleReschedule(appointment.id)}
                      disabled={isLoading === appointment.id + "-reschedule"}
                    >
                      {isLoading === appointment.id + "-reschedule" ? "Processing..." : "Reschedule"}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-rose-600 border-rose-200 hover:bg-rose-50"
                      onClick={() => handleCancel(appointment.id)}
                      disabled={isLoading === appointment.id + "-cancel"}
                    >
                      {isLoading === appointment.id + "-cancel" ? "Processing..." : "Cancel"}
                    </Button>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="text-center py-8 bg-gray-50 rounded-lg">
              <p className="text-gray-500 mb-2">You don't have any appointments yet.</p>
              <Button variant="link" className="text-[#5ECFBC]" onClick={() => (window.location.href = "/appointment")}>
                Book your first appointment
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
