"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Download, FileText, FileJson, FileSpreadsheet, Loader2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export function DataExport() {
  const [exportFormat, setExportFormat] = useState<"json" | "csv" | "text">("json")
  const [isExporting, setIsExporting] = useState(false)

  const handleExport = async () => {
    try {
      setIsExporting(true)

      // Request the export from the API
      const response = await fetch(`/api/export/mental-health?format=${exportFormat}`)

      if (!response.ok) {
        throw new Error(`Export failed: ${response.statusText}`)
      }

      // Get the filename from the Content-Disposition header if available
      const contentDisposition = response.headers.get("Content-Disposition")
      let filename = "mental_health_data"

      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="(.+)"/)
        if (filenameMatch && filenameMatch[1]) {
          filename = filenameMatch[1]
        }
      } else {
        // Add appropriate extension if not in the header
        filename += exportFormat === "json" ? ".json" : exportFormat === "csv" ? ".csv" : ".txt"
      }

      // Handle the response based on the format
      if (exportFormat === "json") {
        const data = await response.json()
        // Create a download link for the JSON
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
        downloadFile(blob, filename)
      } else {
        // For CSV and text, get the raw text
        const text = await response.text()
        const type = exportFormat === "csv" ? "text/csv" : "text/plain"
        const blob = new Blob([text], { type })
        downloadFile(blob, filename)
      }

      toast({
        title: "Export Successful",
        description: `Your mental health data has been exported as ${exportFormat.toUpperCase()}.`,
      })
    } catch (error) {
      console.error("Export error:", error)
      toast({
        title: "Export Failed",
        description: "There was an error exporting your data. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  // Helper function to trigger download
  const downloadFile = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Export Your Data</CardTitle>
        <CardDescription>
          Download your mental health data in various formats for personal records or to share with healthcare
          providers.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <h3 className="text-sm font-medium mb-3">Choose Export Format</h3>
            <RadioGroup
              value={exportFormat}
              onValueChange={(value) => setExportFormat(value as "json" | "csv" | "text")}
              className="grid grid-cols-1 sm:grid-cols-3 gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="json" id="json" />
                <Label htmlFor="json" className="flex items-center cursor-pointer">
                  <FileJson className="h-5 w-5 mr-2 text-blue-500" />
                  JSON
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="csv" id="csv" />
                <Label htmlFor="csv" className="flex items-center cursor-pointer">
                  <FileSpreadsheet className="h-5 w-5 mr-2 text-green-500" />
                  CSV
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="text" id="text" />
                <Label htmlFor="text" className="flex items-center cursor-pointer">
                  <FileText className="h-5 w-5 mr-2 text-gray-500" />
                  Text
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="bg-blue-50 border border-blue-100 rounded-md p-4">
            <h4 className="text-sm font-medium text-blue-800 mb-2">What's included in your export?</h4>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Mood and stress tracking data</li>
              <li>• Sleep quality records</li>
              <li>• Anxiety level measurements</li>
              <li>• Journal entries sentiment analysis</li>
              <li>• Personal goals and progress notes</li>
            </ul>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-end">
        <Button onClick={handleExport} disabled={isExporting}>
          {isExporting ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Exporting...
            </>
          ) : (
            <>
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
