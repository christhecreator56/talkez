"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PersonalInfoForm } from "@/components/profile/personal-info-form"
import { MentalHealthForm } from "@/components/profile/mental-health-form"
import { PrivacySettingsForm } from "@/components/profile/privacy-settings-form"
import { AppointmentHistory } from "@/components/profile/appointment-history"

export function ProfileTabs() {
  const [activeTab, setActiveTab] = useState("personal")

  return (
    <Tabs defaultValue="personal" value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="grid w-full grid-cols-2 mb-8">
        {" "}
        {/* Changed to 2 columns on mobile */}
        <TabsTrigger value="personal" className="text-sm sm:text-base py-3">
          {" "}
          {/* Increased padding */}
          Personal Info
        </TabsTrigger>
        <TabsTrigger value="mental-health" className="text-sm sm:text-base py-3">
          {" "}
          {/* Increased padding */}
          Mental Health
        </TabsTrigger>
      </TabsList>
      <TabsList className="grid w-full grid-cols-2 mb-8">
        {" "}
        {/* Second row of tabs */}
        <TabsTrigger value="appointments" className="text-sm sm:text-base py-3">
          {" "}
          {/* Increased padding */}
          Appointments
        </TabsTrigger>
        <TabsTrigger value="privacy" className="text-sm sm:text-base py-3">
          {" "}
          {/* Increased padding */}
          Privacy
        </TabsTrigger>
      </TabsList>

      <TabsContent value="personal">
        <PersonalInfoForm />
      </TabsContent>

      <TabsContent value="mental-health">
        <MentalHealthForm />
      </TabsContent>

      <TabsContent value="appointments">
        <AppointmentHistory />
      </TabsContent>

      <TabsContent value="privacy">
        <PrivacySettingsForm />
      </TabsContent>
    </Tabs>
  )
}
