"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { toast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"

// Default data for v85 version (no database connection)
const defaultMentalHealthData = {
  stressLevel: "moderate",
  sleepQuality: "fair",
  goals: "Improve stress management and develop better coping mechanisms for anxiety.",
  concerns: [
    { id: "anxiety", label: "Anxiety", checked: true },
    { id: "depression", label: "Depression", checked: false },
    { id: "stress", label: "Stress", checked: true },
    { id: "sleep", label: "Sleep Issues", checked: true },
    { id: "relationships", label: "Relationship Issues", checked: false },
    { id: "self-esteem", label: "Self-Esteem", checked: false },
    { id: "trauma", label: "Trauma", checked: false },
    { id: "other", label: "Other", checked: false },
  ],
  previousTherapy: "yes",
  medications: "None currently",
}

export function MentalHealthForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [formData, setFormData] = useState(defaultMentalHealthData)

  // Load data from localStorage
  useEffect(() => {
    const savedData = localStorage.getItem("talkez_mental_health")
    if (savedData) {
      setFormData(JSON.parse(savedData))
    }
    setIsLoading(false)
  }, [])

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleRadioChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (id: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      concerns: prev.concerns.map((item) => (item.id === id ? { ...item, checked } : item)),
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Save to localStorage
    localStorage.setItem("talkez_mental_health", JSON.stringify(formData))

    // Simulate API delay
    setTimeout(() => {
      setIsSubmitting(false)
      toast({
        title: "Mental Health Profile Updated",
        description: "Your mental health information has been updated successfully.",
      })
    }, 800)
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6 flex justify-center items-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Mental Health Profile</CardTitle>
        <CardDescription>
          This information helps us provide better support for your mental wellness journey. Your answers are
          confidential and will only be shared with your counselor.
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Current Stress Level</h3>
            <RadioGroup
              value={formData.stressLevel}
              onValueChange={(value) => handleRadioChange("stressLevel", value)}
              className="flex flex-col space-y-1"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="low" id="stress-low" />
                <Label htmlFor="stress-low">Low - I'm managing well</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="moderate" id="stress-moderate" />
                <Label htmlFor="stress-moderate">Moderate - Some challenges but coping</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="high" id="stress-high" />
                <Label htmlFor="stress-high">High - Frequently overwhelmed</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="severe" id="stress-severe" />
                <Label htmlFor="stress-severe">Severe - Constantly stressed and struggling</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-3">
            <h3 className="text-lg font-medium">Sleep Quality</h3>
            <RadioGroup
              value={formData.sleepQuality}
              onValueChange={(value) => handleRadioChange("sleepQuality", value)}
              className="flex flex-col space-y-1"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="excellent" id="sleep-excellent" />
                <Label htmlFor="sleep-excellent">Excellent - Sleep well consistently</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="good" id="sleep-good" />
                <Label htmlFor="sleep-good">Good - Occasional sleep issues</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="fair" id="sleep-fair" />
                <Label htmlFor="sleep-fair">Fair - Regular sleep difficulties</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="poor" id="sleep-poor" />
                <Label htmlFor="sleep-poor">Poor - Significant sleep problems</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-3">
            <h3 className="text-lg font-medium">Areas of Concern</h3>
            <p className="text-sm text-gray-500">Select all that apply to you</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {formData.concerns.map((item) => (
                <div key={item.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={item.id}
                    checked={item.checked}
                    onCheckedChange={(checked) => handleCheckboxChange(item.id, checked as boolean)}
                  />
                  <Label htmlFor={item.id}>{item.label}</Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-lg font-medium">Previous Therapy Experience</h3>
            <RadioGroup
              value={formData.previousTherapy}
              onValueChange={(value) => handleRadioChange("previousTherapy", value)}
              className="flex flex-col space-y-1"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id="therapy-yes" />
                <Label htmlFor="therapy-yes">Yes</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id="therapy-no" />
                <Label htmlFor="therapy-no">No</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-3">
            <Label htmlFor="medications">Current Medications (Optional)</Label>
            <Textarea
              id="medications"
              name="medications"
              placeholder="List any medications you're currently taking"
              value={formData.medications}
              onChange={handleTextChange}
              className="min-h-[80px]"
            />
          </div>

          <div className="space-y-3">
            <Label htmlFor="goals">Mental Health Goals</Label>
            <Textarea
              id="goals"
              name="goals"
              placeholder="What would you like to achieve through our services?"
              value={formData.goals}
              onChange={handleTextChange}
              className="min-h-[100px]"
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isSubmitting} className="ml-auto">
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              "Save Changes"
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
