"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Camera, Edit, Loader2 } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { toast } from "@/hooks/use-toast"

// Default data for v85 version (no database connection)
const defaultProfileData = {
  name: "John Smith",
  bio: "Psychology student passionate about mental health awareness and self-improvement.",
  avatarUrl: "/diverse-person-portrait.png",
}

export function ProfileHeader() {
  const [isEditing, setIsEditing] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [profileData, setProfileData] = useState(defaultProfileData)
  const [tempData, setTempData] = useState({
    name: "",
    bio: "",
  })

  // Load data from localStorage
  useEffect(() => {
    const savedData = localStorage.getItem("talkez_profile_header")
    if (savedData) {
      const parsedData = JSON.parse(savedData)
      setProfileData(parsedData)
      setTempData({
        name: parsedData.name,
        bio: parsedData.bio,
      })
    } else {
      setTempData({
        name: defaultProfileData.name,
        bio: defaultProfileData.bio,
      })
    }
    setIsLoading(false)
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setTempData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSave = () => {
    setIsSaving(true)

    // Update profile data
    const updatedProfile = {
      ...profileData,
      name: tempData.name,
      bio: tempData.bio,
    }

    // Save to localStorage
    localStorage.setItem("talkez_profile_header", JSON.stringify(updatedProfile))

    // Simulate API delay
    setTimeout(() => {
      setProfileData(updatedProfile)
      setIsEditing(false)
      setIsSaving(false)
      toast({
        title: "Profile Updated",
        description: "Your profile information has been updated successfully.",
      })
    }, 800)
  }

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // In a real app, we would upload the file to a server
    // For this demo, we'll just use a placeholder

    // Simulate API delay
    toast({
      title: "Upload Started",
      description: "Uploading your profile picture...",
    })

    setTimeout(() => {
      const updatedProfile = {
        ...profileData,
        avatarUrl: "/diverse-person-portrait.png", // Use the same image as a placeholder
      }

      setProfileData(updatedProfile)
      localStorage.setItem("talkez_profile_header", JSON.stringify(updatedProfile))

      toast({
        title: "Avatar Updated",
        description: "Your profile picture has been updated successfully.",
      })
    }, 1500)
  }

  if (isLoading) {
    return (
      <Card className="mb-8 overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-sky-200 to-violet-200"></div>
        <div className="px-6 pb-6 pt-16 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Card>
    )
  }

  const initials = profileData.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .substring(0, 2)

  return (
    <Card className="mb-8 overflow-hidden">
      <div className="h-32 bg-gradient-to-r from-sky-200 to-violet-200 relative">
        {isEditing && (
          <Button variant="secondary" size="sm" className="absolute right-4 top-4 bg-white/80 hover:bg-white">
            <Camera className="h-4 w-4 mr-1" />
            Change Cover
          </Button>
        )}
      </div>
      <div className="px-6 pb-6 pt-16">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="relative">
            <Avatar className="h-24 w-24 border-4 border-white shadow-md">
              <AvatarImage src={profileData.avatarUrl || "/placeholder.svg"} alt={profileData.name} />
              <AvatarFallback className="text-2xl">{initials}</AvatarFallback>
            </Avatar>
            {isEditing && (
              <div className="absolute bottom-0 right-0">
                <label htmlFor="avatar-upload">
                  <Button
                    variant="secondary"
                    size="icon"
                    className="h-8 w-8 rounded-full bg-rose-100 hover:bg-rose-200 border border-white cursor-pointer"
                    tabIndex={-1}
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                </label>
                <input
                  id="avatar-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarUpload}
                />
              </div>
            )}
          </div>
          <div className="flex-1 space-y-2">
            {isEditing ? (
              <input
                type="text"
                name="name"
                value={tempData.name}
                onChange={handleInputChange}
                className="text-2xl font-bold w-full border-b border-gray-300 focus:border-rose-500 focus:outline-none pb-1"
              />
            ) : (
              <h2 className="text-2xl font-bold">{profileData.name}</h2>
            )}
            {isEditing ? (
              <textarea
                name="bio"
                value={tempData.bio}
                onChange={handleInputChange}
                className="w-full text-gray-600 border rounded-md p-2 focus:border-rose-500 focus:outline-none"
                rows={2}
              />
            ) : (
              <p className="text-gray-600">{profileData.bio}</p>
            )}
          </div>
          <div>
            {isEditing ? (
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsEditing(false)} disabled={isSaving}>
                  Cancel
                </Button>
                <Button onClick={handleSave} disabled={isSaving}>
                  {isSaving ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Save"
                  )}
                </Button>
              </div>
            ) : (
              <Button variant="outline" onClick={() => setIsEditing(true)}>
                <Edit className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
            )}
          </div>
        </div>
      </div>
    </Card>
  )
}
