"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AppointmentTab } from "@/components/appointment-tab"
import { GamesTab } from "@/components/games-tab"

export function FeatureTabs() {
  const searchParams = useSearchParams()
  const tabParam = searchParams.get("tab")

  // Set default tab or use the one from URL
  const [activeTab, setActiveTab] = useState(tabParam === "chatbot" || tabParam === "games" ? tabParam : "appointment")

  // Update active tab when URL changes
  useEffect(() => {
    if (tabParam === "chatbot" || tabParam === "games") {
      setActiveTab(tabParam)
    }
  }, [tabParam])

  return (
    <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="grid w-full grid-cols-2 mb-8">
        <TabsTrigger value="appointment" className="text-sm sm:text-base">
          Book Appointment
        </TabsTrigger>
        <TabsTrigger value="games" className="text-sm sm:text-base">
          Mind Games
        </TabsTrigger>
      </TabsList>

      <TabsContent value="appointment">
        <AppointmentTab />
      </TabsContent>

      <TabsContent value="games">
        <GamesTab />
      </TabsContent>
    </Tabs>
  )
}
