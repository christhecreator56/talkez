"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Brain, Puzzle, Dices, Lightbulb } from "lucide-react"
import { MemoryMatch } from "@/components/games/memory-match"
import { WordAssociation } from "@/components/games/word-association"
import { NumberNinja } from "@/components/games/number-ninja"

type Game = {
  id: string
  title: string
  description: string
  icon: React.ReactNode
  emoji: string
  difficulty: "Easy" | "Medium" | "Hard"
  category: string
  component?: React.ReactNode
}

const games: Game[] = [
  {
    id: "memory",
    title: "Memory Match",
    description: "Test and improve your memory by matching pairs of cards.",
    icon: <Brain className="h-8 w-8 text-[#5ECFBC]" />,
    emoji: "🧠",
    difficulty: "Easy",
    category: "Memory",
    component: <MemoryMatch />,
  },
  {
    id: "puzzle",
    title: "Pattern Puzzle",
    description: "Solve visual puzzles by identifying patterns and sequences.",
    icon: <Puzzle className="h-8 w-8 text-[#FFD166]" />,
    emoji: "🧩",
    difficulty: "Medium",
    category: "Logic",
  },
  {
    id: "word",
    title: "Word Association",
    description: "Strengthen vocabulary and mental connections through word associations.",
    icon: <Lightbulb className="h-8 w-8 text-amber-500" />,
    emoji: "💡",
    difficulty: "Medium",
    category: "Language",
    component: <WordAssociation />,
  },
  {
    id: "math",
    title: "Number Ninja",
    description: "Sharpen your mental math skills with quick calculation challenges.",
    icon: <Dices className="h-8 w-8 text-emerald-500" />,
    emoji: "🔢",
    difficulty: "Hard",
    category: "Mathematics",
    component: <NumberNinja />,
  },
]

export function GamesTab() {
  const [selectedGame, setSelectedGame] = useState<string | null>(null)
  const [level, setLevel] = useState(1)
  const [score, setScore] = useState(0)
  const [pattern, setPattern] = useState<number[]>([])
  const [userSelections, setUserSelections] = useState<number[]>([])
  const [gameStatus, setGameStatus] = useState<"playing" | "success" | "failed">("playing")
  const [message, setMessage] = useState("Find the pattern and select the correct squares!")

  // Generate a new pattern when level changes
  useEffect(() => {
    generateNewPattern()
  }, [level])

  // Generate a new pattern based on level
  const generateNewPattern = useCallback(() => {
    setGameStatus("playing")
    setUserSelections([])

    // Different pattern types based on level
    let newPattern: number[] = []
    if (level <= 3) {
      // Simple patterns: every Nth square
      const step = level === 1 ? 3 : level === 2 ? 2 : 4
      for (let i = 0; i < 9; i++) {
        if (i % step === 0) newPattern.push(i)
      }
    } else if (level <= 6) {
      // Diagonal or shape patterns
      if (level === 4)
        newPattern = [0, 4, 8] // diagonal
      else if (level === 5)
        newPattern = [1, 3, 5, 7] // cross
      else newPattern = [0, 2, 6, 8] // corners
    } else {
      // Random patterns for higher levels
      const count = Math.min(4 + Math.floor(level / 2), 7)
      while (newPattern.length < count) {
        const num = Math.floor(Math.random() * 9)
        if (!newPattern.includes(num)) newPattern.push(num)
      }
    }

    setPattern(newPattern)
    setMessage(`Level ${level}: Find the pattern and select the correct squares!`)
  }, [level])

  // Handle square click
  const handleSquareClick = (index: number) => {
    if (gameStatus !== "playing") return

    // Check if already selected
    if (userSelections.includes(index)) {
      setUserSelections(userSelections.filter((i) => i !== index))
      return
    }

    // Add to selections
    const newSelections = [...userSelections, index]
    setUserSelections(newSelections)

    // Check if selection is correct
    const isCorrect = pattern.includes(index)

    // Check if all pattern squares are selected
    const allFound = pattern.every((p) => newSelections.includes(p))
    const hasExtraSelections = newSelections.some((s) => !pattern.includes(s))

    if (!isCorrect) {
      // Wrong selection
      setMessage("Oops! That's not part of the pattern. Try again!")
      setTimeout(() => {
        setUserSelections(userSelections)
      }, 800)
    } else if (allFound && !hasExtraSelections) {
      // All correct selections made
      setScore(score + level * 10)
      setGameStatus("success")
      setMessage(`Great job! You found the pattern. +${level * 10} points!`)
    }
  }

  // Move to next level
  const nextLevel = () => {
    setLevel(level + 1)
  }

  return (
    <div className="space-y-6">
      {!selectedGame ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {games.map((game) => (
            <Card
              key={game.id}
              className="cursor-pointer transition-all hover:shadow-md"
              onClick={() => setSelectedGame(game.id)}
            >
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    {game.icon}
                    <span className="text-2xl ml-2">{game.emoji}</span>
                  </div>
                  <span
                    className={`text-xs font-medium px-2 py-1 rounded-full ${
                      game.difficulty === "Easy"
                        ? "bg-green-100 text-green-700"
                        : game.difficulty === "Medium"
                          ? "bg-amber-100 text-amber-700"
                          : "bg-red-100 text-red-700"
                    }`}
                  >
                    {game.difficulty}
                  </span>
                </div>
                <CardTitle className="text-lg">{game.title}</CardTitle>
                <CardDescription className="text-xs text-gray-500">{game.category}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">{game.description}</p>
              </CardContent>
              <CardFooter>
                <Button
                  variant="outline"
                  className="w-full text-[#5ECFBC] border-[#B4E4E0] hover:bg-[#B4E4E0]/20"
                  onClick={(e) => {
                    e.stopPropagation() // Prevent triggering the card's onClick
                    setSelectedGame(game.id)
                  }}
                >
                  Play Now {game.emoji}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-gray-800">
              {games.find((g) => g.id === selectedGame)?.title}{" "}
              <span className="text-2xl">{games.find((g) => g.id === selectedGame)?.emoji}</span>
            </h3>
            <Button variant="outline" onClick={() => setSelectedGame(null)} className="text-[#5ECFBC] border-[#B4E4E0]">
              Back to Games
            </Button>
          </div>

          {selectedGame === "memory" ? (
            <MemoryMatch />
          ) : selectedGame === "word" ? (
            <WordAssociation />
          ) : selectedGame === "math" ? (
            <NumberNinja />
          ) : selectedGame === "puzzle" ? (
            <Card>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <>
                    <div className="flex justify-between items-center">
                      <h3 className="text-xl font-bold text-[#333]">Pattern Puzzle</h3>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium bg-[#FFD166] px-3 py-1 rounded-full text-[#333]">
                          Level: {level}
                        </span>
                        <span className="font-medium bg-[#5ECFBC] px-3 py-1 rounded-full text-white">
                          Score: {score}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                      {Array.from({ length: 9 }).map((_, index) => {
                        const isSelected = userSelections.includes(index)
                        const isCorrect = pattern.includes(index) && isSelected
                        const isWrong = !pattern.includes(index) && isSelected

                        return (
                          <div
                            key={index}
                            className={`aspect-square rounded-lg flex items-center justify-center text-4xl cursor-pointer transition-all duration-200 hover:scale-105 shadow-md ${
                              gameStatus === "success" && pattern.includes(index)
                                ? "bg-green-200 border-4 border-green-500"
                                : isCorrect
                                  ? "bg-[#FFD166] border-4 border-[#FF9F1C]"
                                  : isWrong
                                    ? "bg-red-200 border-4 border-red-400"
                                    : isSelected
                                      ? "bg-blue-200 border-4 border-blue-400"
                                      : "bg-white border-4 border-[#B4E4E0]"
                            }`}
                            onClick={() => handleSquareClick(index)}
                          >
                            {gameStatus === "success" && pattern.includes(index)
                              ? "✓"
                              : isCorrect
                                ? "🧩"
                                : isWrong
                                  ? "❌"
                                  : isSelected
                                    ? "?"
                                    : ""}
                          </div>
                        )
                      })}
                    </div>

                    <div
                      className={`p-4 rounded-lg shadow-md ${
                        gameStatus === "success"
                          ? "bg-green-100"
                          : gameStatus === "failed"
                            ? "bg-red-100"
                            : "bg-[#B4E4E0]"
                      }`}
                    >
                      <p className="text-center text-[#333] font-medium">{message}</p>
                    </div>

                    <div className="flex justify-center">
                      {gameStatus === "playing" ? (
                        <Button
                          className="flex items-center space-x-2 bg-[#FFD166] hover:bg-[#FF9F1C] text-[#333] font-bold px-6 py-3 rounded-full shadow-md"
                          onClick={generateNewPattern}
                        >
                          <span>New Pattern 🔄</span>
                        </Button>
                      ) : (
                        <Button
                          className="flex items-center space-x-2 bg-[#5ECFBC] hover:bg-[#3DBBAA] text-white font-bold px-6 py-3 rounded-full shadow-md"
                          onClick={nextLevel}
                        >
                          <span>Next Level ➡️</span>
                        </Button>
                      )}
                    </div>
                  </>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="p-6 text-center">
              <div className="text-6xl mb-4">{games.find((g) => g.id === selectedGame)?.emoji}</div>
              <p className="text-gray-600">{games.find((g) => g.id === selectedGame)?.title} will be available soon!</p>
            </Card>
          )}
        </div>
      )}
    </div>
  )
}
