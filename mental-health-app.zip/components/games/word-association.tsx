"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock, Trophy, Check, X } from "lucide-react"
import { toast } from "@/hooks/use-toast"

// Word pairs for the game
const WORD_PAIRS = [
  { word: "Happy", associations: ["Joy", "Smile", "Cheerful", "Glad"] },
  { word: "Calm", associations: ["Peace", "Quiet", "Serene", "Tranquil"] },
  { word: "Mind", associations: ["Brain", "Thought", "Intellect", "Psyche"] },
  { word: "Health", associations: ["Wellness", "Fitness", "Vigor", "Vitality"] },
  { word: "Stress", associations: ["Anxiety", "Pressure", "Tension", "Strain"] },
  { word: "Relax", associations: ["Rest", "Unwind", "Chill", "Ease"] },
  { word: "Focus", associations: ["Concentrate", "Attention", "Center", "Target"] },
  { word: "Growth", associations: ["Development", "Progress", "Expansion", "Improvement"] },
  { word: "Balance", associations: ["Equilibrium", "Harmony", "Stability", "Poise"] },
  { word: "Energy", associations: ["Power", "Vigor", "Vitality", "Strength"] },
  { word: "Dream", associations: ["Sleep", "Aspiration", "Vision", "Fantasy"] },
  { word: "Courage", associations: ["Bravery", "Valor", "Nerve", "Daring"] },
]

// Options for each round
const OPTIONS_COUNT = 4

export function WordAssociation() {
  const [gameStarted, setGameStarted] = useState<boolean>(false)
  const [currentRound, setCurrentRound] = useState<number>(0)
  const [score, setScore] = useState<number>(0)
  const [timer, setTimer] = useState<number>(30)
  const [currentWord, setCurrentWord] = useState<string>("")
  const [options, setOptions] = useState<string[]>([])
  const [correctOption, setCorrectOption] = useState<string>("")
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null)
  const [gameOver, setGameOver] = useState<boolean>(false)
  const [difficulty, setDifficulty] = useState<"easy" | "medium" | "hard">("easy")
  const [usedWords, setUsedWords] = useState<string[]>([])

  // Initialize game
  const initializeGame = () => {
    setCurrentRound(0)
    setScore(0)
    setTimer(difficulty === "easy" ? 30 : difficulty === "medium" ? 20 : 15)
    setGameOver(false)
    setUsedWords([])
    generateRound()
    setGameStarted(true)
  }

  // Generate a new round
  const generateRound = () => {
    // Filter out already used words
    const availableWords = WORD_PAIRS.filter((pair) => !usedWords.includes(pair.word))

    // If all words have been used, reset
    if (availableWords.length === 0) {
      setUsedWords([])
      generateRound()
      return
    }

    // Select a random word pair
    const randomIndex = Math.floor(Math.random() * availableWords.length)
    const selectedPair = availableWords[randomIndex]

    // Update used words
    setUsedWords([...usedWords, selectedPair.word])

    // Set current word
    setCurrentWord(selectedPair.word)

    // Select a random correct association
    const correctAssociation = selectedPair.associations[Math.floor(Math.random() * selectedPair.associations.length)]
    setCorrectOption(correctAssociation)

    // Generate wrong options from other word pairs
    const wrongOptions: string[] = []
    while (wrongOptions.length < OPTIONS_COUNT - 1) {
      const randomPairIndex = Math.floor(Math.random() * WORD_PAIRS.length)
      if (randomPairIndex !== randomIndex) {
        const randomAssociationIndex = Math.floor(Math.random() * WORD_PAIRS[randomPairIndex].associations.length)
        const wrongOption = WORD_PAIRS[randomPairIndex].associations[randomAssociationIndex]
        if (!wrongOptions.includes(wrongOption) && wrongOption !== correctAssociation) {
          wrongOptions.push(wrongOption)
        }
      }
    }

    // Combine and shuffle options
    const allOptions = [...wrongOptions, correctAssociation]
    const shuffledOptions = allOptions.sort(() => Math.random() - 0.5)
    setOptions(shuffledOptions)

    // Reset selection state
    setSelectedOption(null)
    setIsCorrect(null)
  }

  // Handle option selection
  const handleOptionSelect = (option: string) => {
    if (selectedOption !== null) return // Prevent multiple selections

    setSelectedOption(option)
    const correct = option === correctOption
    setIsCorrect(correct)

    if (correct) {
      setScore(score + (difficulty === "easy" ? 1 : difficulty === "medium" ? 2 : 3))
      toast({
        title: "Correct! 🎉",
        description: `Great job! "${option}" is associated with "${currentWord}"`,
      })
    }

    // Move to next round after a delay
    setTimeout(() => {
      if (currentRound < 9) {
        // 10 rounds total (0-9)
        setCurrentRound(currentRound + 1)
        generateRound()
      } else {
        setGameOver(true)
        toast({
          title: "Game Over! 🏆",
          description: `Your final score is ${score + (correct ? (difficulty === "easy" ? 1 : difficulty === "medium" ? 2 : 3) : 0)} points!`,
        })
      }
    }, 1500)
  }

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout

    if (gameStarted && !gameOver) {
      interval = setInterval(() => {
        setTimer((prevTimer) => {
          if (prevTimer <= 1) {
            clearInterval(interval)
            setGameOver(true)
            toast({
              title: "Time's Up! ⏰",
              description: `Your final score is ${score} points!`,
            })
            return 0
          }
          return prevTimer - 1
        })
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [gameStarted, gameOver, score])

  // Render difficulty selection
  const renderDifficultySelection = () => {
    return (
      <div className="text-center space-y-6">
        <h3 className="text-xl font-semibold text-gray-800">Select Difficulty</h3>
        <div className="flex flex-col space-y-3">
          <Button
            variant="outline"
            className={`py-6 ${difficulty === "easy" ? "bg-amber-100 border-amber-500" : ""}`}
            onClick={() => setDifficulty("easy")}
          >
            Easy (30 seconds) 😊
          </Button>
          <Button
            variant="outline"
            className={`py-6 ${difficulty === "medium" ? "bg-amber-100 border-amber-500" : ""}`}
            onClick={() => setDifficulty("medium")}
          >
            Medium (20 seconds) 🧠
          </Button>
          <Button
            variant="outline"
            className={`py-6 ${difficulty === "hard" ? "bg-amber-100 border-amber-500" : ""}`}
            onClick={() => setDifficulty("hard")}
          >
            Hard (15 seconds) 🔥
          </Button>
        </div>
        <Button
          className="w-full bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-500 hover:to-amber-400 text-[#333] font-bold"
          onClick={initializeGame}
        >
          Start Game 💡
        </Button>
      </div>
    )
  }

  // Render game over screen
  const renderGameOver = () => {
    return (
      <div className="text-center space-y-6 py-8">
        <h3 className="text-2xl font-bold text-gray-800">Game Over!</h3>
        <div className="bg-amber-100 rounded-lg p-6 shadow-md">
          <Trophy className="h-12 w-12 text-amber-500 mx-auto mb-4" />
          <p className="text-xl font-semibold">Your Score: {score} points</p>
          <p className="text-gray-600 mt-2">
            {score < 5
              ? "Good effort! Keep practicing to improve your word associations."
              : score < 8
                ? "Great job! You have a good grasp of word associations."
                : "Amazing! You're a word association master!"}
          </p>
        </div>
        <Button
          className="w-full bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-500 hover:to-amber-400 text-[#333] font-bold"
          onClick={initializeGame}
        >
          Play Again 🔄
        </Button>
      </div>
    )
  }

  // Render game board
  const renderGameBoard = () => {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Trophy className="h-5 w-5 text-amber-500" />
            <span className="font-medium">Score: {score}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-amber-500" />
            <span className={`font-medium ${timer <= 10 ? "text-red-500" : ""}`}>{timer}s</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="font-medium">Round: {currentRound + 1}/10</span>
          </div>
        </div>

        <div className="bg-amber-50 p-6 rounded-lg shadow-md text-center">
          <p className="text-gray-600 mb-2">Find the word associated with:</p>
          <h3 className="text-3xl font-bold text-amber-600 mb-4">{currentWord}</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
            {options.map((option, index) => (
              <Button
                key={index}
                variant="outline"
                className={`py-4 text-lg transition-all ${
                  selectedOption === option
                    ? isCorrect
                      ? "bg-green-100 border-green-500"
                      : "bg-red-100 border-red-500"
                    : "hover:bg-amber-100 hover:border-amber-500"
                }`}
                onClick={() => handleOptionSelect(option)}
                disabled={selectedOption !== null}
              >
                {option}
                {selectedOption === option &&
                  (isCorrect ? (
                    <Check className="ml-2 h-5 w-5 text-green-500" />
                  ) : (
                    <X className="ml-2 h-5 w-5 text-red-500" />
                  ))}
              </Button>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <Card>
      <CardContent className="p-6">
        {!gameStarted ? renderDifficultySelection() : gameOver ? renderGameOver() : renderGameBoard()}
      </CardContent>
    </Card>
  )
}
