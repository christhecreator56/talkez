"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Brain, Clock, RotateCcw, Trophy } from "lucide-react"
import { toast } from "@/hooks/use-toast"

// Define card types
type CardType = {
  id: number
  emoji: string
  flipped: boolean
  matched: boolean
}

// Emoji pairs for the memory game
const EMOJIS = ["😊", "🌟", "🎓", "🧠", "💭", "🌈", "🌱", "💪", "🔥", "🎮", "🎯", "🎪", "🎭", "🎨", "🎧", "🏆"]

export function MemoryMatch() {
  const [cards, setCards] = useState<CardType[]>([])
  const [flippedCards, setFlippedCards] = useState<number[]>([])
  const [matchedPairs, setMatchedPairs] = useState<number>(0)
  const [moves, setMoves] = useState<number>(0)
  const [gameStarted, setGameStarted] = useState<boolean>(false)
  const [gameCompleted, setGameCompleted] = useState<boolean>(false)
  const [timer, setTimer] = useState<number>(0)
  const [difficulty, setDifficulty] = useState<"easy" | "medium" | "hard">("easy")

  // Initialize game
  const initializeGame = () => {
    // Determine number of pairs based on difficulty
    let numPairs = 4 // easy
    if (difficulty === "medium") numPairs = 8
    if (difficulty === "hard") numPairs = 12

    // Create pairs of cards
    const selectedEmojis = EMOJIS.slice(0, numPairs)
    const cardPairs = [...selectedEmojis, ...selectedEmojis]

    // Shuffle cards
    const shuffledCards = cardPairs
      .sort(() => Math.random() - 0.5)
      .map((emoji, index) => ({
        id: index,
        emoji,
        flipped: false,
        matched: false,
      }))

    console.log("Game initialized with cards:", shuffledCards)
    setCards(shuffledCards)
    setFlippedCards([])
    setMatchedPairs(0)
    setMoves(0)
    setTimer(0)
    setGameCompleted(false)
  }

  // Start game
  const startGame = () => {
    initializeGame()
    setGameStarted(true)
  }

  // Reset game
  const resetGame = () => {
    initializeGame()
    setGameStarted(true)
  }

  // Handle card click
  const handleCardClick = (id: number) => {
    // Ignore if already flipped or matched
    if (flippedCards.length === 2 || cards[id].flipped || cards[id].matched) return

    // Flip the card
    const newCards = [...cards]
    newCards[id].flipped = true
    setCards(newCards)

    // Add to flipped cards
    const newFlippedCards = [...flippedCards, id]
    setFlippedCards(newFlippedCards)

    // Check for match if two cards are flipped
    if (newFlippedCards.length === 2) {
      setMoves(moves + 1)

      const [firstId, secondId] = newFlippedCards
      if (cards[firstId].emoji === cards[secondId].emoji) {
        // Match found
        setTimeout(() => {
          const matchedCards = [...cards]
          matchedCards[firstId].matched = true
          matchedCards[secondId].matched = true
          setCards(matchedCards)
          setFlippedCards([])
          setMatchedPairs(matchedPairs + 1)

          // Check if game is completed
          if (matchedPairs + 1 === cards.length / 2) {
            setGameCompleted(true)
            toast({
              title: "Congratulations! 🎉",
              description: `You completed the game in ${moves + 1} moves and ${timer} seconds!`,
            })
          }
        }, 500)
      } else {
        // No match
        setTimeout(() => {
          const unmatchedCards = [...cards]
          unmatchedCards[firstId].flipped = false
          unmatchedCards[secondId].flipped = false
          setCards(unmatchedCards)
          setFlippedCards([])
        }, 1000)
      }
    }
  }

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout

    if (gameStarted && !gameCompleted) {
      interval = setInterval(() => {
        setTimer((prevTimer) => prevTimer + 1)
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [gameStarted, gameCompleted])

  // Render game board
  const renderGameBoard = () => {
    const gridCols =
      difficulty === "easy"
        ? "grid-cols-2" // Changed from 4 to 2 columns for mobile
        : difficulty === "medium"
          ? "grid-cols-3" // Changed from 4 to 3 columns for mobile
          : "grid-cols-4" // Changed from 6 to 4 columns for mobile

    return (
      <div className={`grid ${gridCols} gap-3 md:gap-4`}>
        {cards.map((card) => (
          <div
            key={card.id}
            className="aspect-square cursor-pointer touch-target"
            onClick={() => handleCardClick(card.id)}
          >
            <div className="relative w-full h-full">
              {/* Card back (shown when not flipped) */}
              <div
                className={`absolute w-full h-full rounded-lg flex items-center justify-center transition-opacity duration-300 ${
                  card.flipped || card.matched ? "opacity-0" : "opacity-100"
                } bg-[#B4E4E0] border-2 border-[#5ECFBC] shadow-md`}
              >
                <Brain className="h-6 w-6 text-[#5ECFBC]" />
              </div>

              {/* Card front (shown when flipped) */}
              <div
                className={`absolute w-full h-full rounded-lg flex items-center justify-center transition-opacity duration-300 ${
                  card.flipped || card.matched ? "opacity-100" : "opacity-0"
                } bg-[#FFD166] border-2 border-[#FF9F1C] shadow-md`}
              >
                <span className="text-4xl md:text-5xl bg-white p-2 rounded-full shadow-md">{card.emoji}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    )
  }

  // Render difficulty selection
  const renderDifficultySelection = () => {
    return (
      <div className="text-center space-y-6">
        <h3 className="text-xl font-semibold text-gray-800">Select Difficulty</h3>
        <div className="flex flex-col space-y-3">
          <Button
            variant="outline"
            className={`py-6 ${difficulty === "easy" ? "bg-[#B4E4E0] border-[#5ECFBC]" : ""}`}
            onClick={() => setDifficulty("easy")}
          >
            Easy (4 pairs) 😊
          </Button>
          <Button
            variant="outline"
            className={`py-6 ${difficulty === "medium" ? "bg-[#B4E4E0] border-[#5ECFBC]" : ""}`}
            onClick={() => setDifficulty("medium")}
          >
            Medium (8 pairs) 🧠
          </Button>
          <Button
            variant="outline"
            className={`py-6 ${difficulty === "hard" ? "bg-[#B4E4E0] border-[#5ECFBC]" : ""}`}
            onClick={() => setDifficulty("hard")}
          >
            Hard (12 pairs) 🔥
          </Button>
        </div>
        <Button
          className="w-full bg-gradient-to-r from-[#5ECFBC] to-[#B4E4E0] hover:from-[#4DB6A5] hover:to-[#A3D3CF] text-[#333] font-bold"
          onClick={startGame}
        >
          Start Game 🎮
        </Button>
      </div>
    )
  }

  return (
    <Card>
      <CardContent className="p-6">
        {!gameStarted ? (
          renderDifficultySelection()
        ) : (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <Trophy className="h-5 w-5 text-amber-500" />
                <span className="font-medium">
                  {matchedPairs} / {cards.length / 2} Pairs
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-[#5ECFBC]" />
                <span className="font-medium">{timer}s</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="font-medium">{moves} Moves</span>
              </div>
            </div>

            {renderGameBoard()}

            <div className="flex justify-center">
              <Button
                variant="outline"
                className="flex items-center space-x-2 border-[#5ECFBC] text-[#333] hover:bg-[#B4E4E0]/20"
                onClick={resetGame}
              >
                <RotateCcw className="h-4 w-4" />
                <span>Reset Game</span>
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
