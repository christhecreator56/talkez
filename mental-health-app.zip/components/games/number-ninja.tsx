"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dices, Clock, Award, RotateCcw } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

type Operation = "+" | "-" | "×" | "÷"
type Question = {
  num1: number
  num2: number
  operation: Operation
  answer: number
  options: number[]
}

export function NumberNinja() {
  const [score, setScore] = useState(0)
  const [level, setLevel] = useState(1)
  const [timeLeft, setTimeLeft] = useState(20)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null)
  const [streak, setStreak] = useState(0)
  const [gameOver, setGameOver] = useState(false)
  const [highScore, setHighScore] = useState(0)

  // Generate a random number between min and max (inclusive)
  const getRandomNumber = (min: number, max: number) => {
    return Math.floor(Math.random() * (max - min + 1)) + min
  }

  // Generate a new question based on the current level
  const generateQuestion = useCallback(() => {
    let num1: number, num2: number, answer: number
    let operation: Operation
    const operations: Operation[] = ["+", "-", "×", "÷"]

    // Determine available operations based on level
    const availableOperations = level < 3 ? ["+", "-"] : level < 5 ? ["+", "-", "×"] : operations

    // Select a random operation from available ones
    operation = availableOperations[Math.floor(Math.random() * availableOperations.length)]

    // Generate numbers based on operation and level
    switch (operation) {
      case "+":
        const maxAddend = Math.min(level * 10, 100)
        num1 = getRandomNumber(1, maxAddend)
        num2 = getRandomNumber(1, maxAddend)
        answer = num1 + num2
        break
      case "-":
        const maxMinuend = Math.min(level * 10, 100)
        num1 = getRandomNumber(Math.max(level, 10), maxMinuend)
        num2 = getRandomNumber(1, num1) // Ensure positive result
        answer = num1 - num2
        break
      case "×":
        const maxFactor = Math.min(level + 5, 12)
        num1 = getRandomNumber(2, maxFactor)
        num2 = getRandomNumber(2, maxFactor)
        answer = num1 * num2
        break
      case "÷":
        // For division, generate num2 first, then multiply to get num1
        // This ensures we have clean division without remainders
        num2 = getRandomNumber(2, Math.min(level + 3, 12))
        const multiplier = getRandomNumber(1, Math.min(level + 3, 12))
        num1 = num2 * multiplier
        answer = multiplier // The answer is the multiplier
        break
      default:
        num1 = 1
        num2 = 1
        answer = 2
    }

    // Generate options (including the correct answer)
    const options = [answer]

    // Generate 3 wrong answers
    while (options.length < 4) {
      // Generate a wrong answer close to the correct one
      let wrongAnswer
      const deviation = Math.max(1, Math.floor(answer * 0.3)) // Deviation based on answer magnitude

      if (operation === "÷" || operation === "×") {
        // For multiplication and division, make wrong answers more plausible
        wrongAnswer = answer + getRandomNumber(-2, 2) + getRandomNumber(-2, 2)
      } else {
        wrongAnswer = answer + getRandomNumber(-deviation, deviation)
      }

      // Ensure wrong answer is positive and not already in options
      if (wrongAnswer > 0 && !options.includes(wrongAnswer)) {
        options.push(wrongAnswer)
      }
    }

    // Shuffle options
    options.sort(() => Math.random() - 0.5)

    return {
      num1,
      num2,
      operation,
      answer,
      options,
    }
  }, [level])

  // Start a new game
  const startGame = () => {
    setScore(0)
    setLevel(1)
    setTimeLeft(20)
    setIsPlaying(true)
    setCurrentQuestion(generateQuestion())
    setSelectedAnswer(null)
    setIsCorrect(null)
    setStreak(0)
    setGameOver(false)
  }

  // Handle answer selection
  const handleAnswerSelect = (selected: number) => {
    if (selectedAnswer !== null || !currentQuestion) return

    setSelectedAnswer(selected)
    const correct = selected === currentQuestion.answer
    setIsCorrect(correct)

    if (correct) {
      const newStreak = streak + 1
      setStreak(newStreak)

      // Calculate points based on level, time left, and streak
      const timeBonus = Math.floor(timeLeft / 2)
      const streakMultiplier = Math.min(1 + newStreak * 0.1, 2) // Max 2x multiplier
      const points = Math.floor((level * 10 + timeBonus) * streakMultiplier)

      setScore((prevScore) => prevScore + points)

      // Level up every 3 correct answers
      if (newStreak % 3 === 0) {
        setLevel((prevLevel) => prevLevel + 1)
        // Add bonus time on level up
        setTimeLeft((prevTime) => Math.min(prevTime + 5, 30))
      }
    } else {
      setStreak(0)
    }

    // Move to next question after a delay
    setTimeout(() => {
      if (!correct) {
        // Game over on wrong answer for higher levels
        if (level > 3) {
          endGame()
          return
        }
      }

      setSelectedAnswer(null)
      setIsCorrect(null)
      setCurrentQuestion(generateQuestion())
    }, 1500)
  }

  // End the game
  const endGame = () => {
    setIsPlaying(false)
    setGameOver(true)

    // Update high score if needed
    if (score > highScore) {
      setHighScore(score)
    }
  }

  // Timer effect
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying && timeLeft > 0) {
      timer = setTimeout(() => {
        setTimeLeft((prevTime) => prevTime - 1)
      }, 1000)
    } else if (isPlaying && timeLeft === 0) {
      endGame()
    }

    return () => {
      if (timer) clearTimeout(timer)
    }
  }, [isPlaying, timeLeft])

  // Get feedback message based on score
  const getFeedbackMessage = () => {
    if (score < 100) {
      return "Good effort! Keep practicing to improve your mental math skills."
    } else if (score < 300) {
      return "Well done! Your mental math skills are developing nicely."
    } else if (score < 600) {
      return "Great job! You're becoming a true Number Ninja!"
    } else {
      return "Amazing! You have mastered the art of mental math. You are a Number Ninja Master!"
    }
  }

  return (
    <div className="space-y-6">
      {!isPlaying && !gameOver ? (
        <Card className="overflow-hidden">
          <CardContent className="p-6 space-y-6">
            <div className="flex flex-col items-center space-y-4">
              <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center">
                <Dices className="w-10 h-10 text-emerald-500" />
              </div>
              <h2 className="text-2xl font-bold text-center">Number Ninja</h2>
              <p className="text-center text-gray-600 max-w-md">
                Test your mental math skills with quick calculation challenges! Solve problems quickly to earn points
                and advance to harder levels.
              </p>

              <div className="grid grid-cols-2 gap-4 w-full max-w-md mt-4">
                <div className="bg-emerald-50 p-4 rounded-lg text-center">
                  <p className="text-sm text-gray-600">High Score</p>
                  <p className="text-xl font-bold text-emerald-600">{highScore}</p>
                </div>
                <div className="bg-amber-50 p-4 rounded-lg text-center">
                  <p className="text-sm text-gray-600">Difficulty</p>
                  <p className="text-xl font-bold text-amber-600">Hard</p>
                </div>
              </div>

              <Button
                onClick={startGame}
                className="mt-6 bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-3 rounded-full text-lg font-semibold"
              >
                Start Game
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : gameOver ? (
        <Card>
          <CardContent className="p-6 space-y-6">
            <div className="flex flex-col items-center space-y-4">
              <div className="w-20 h-20 rounded-full bg-amber-100 flex items-center justify-center">
                <Award className="w-10 h-10 text-amber-500" />
              </div>
              <h2 className="text-2xl font-bold text-center">Game Over!</h2>

              <div className="grid grid-cols-2 gap-4 w-full max-w-md">
                <div className="bg-emerald-50 p-4 rounded-lg text-center">
                  <p className="text-sm text-gray-600">Final Score</p>
                  <p className="text-2xl font-bold text-emerald-600">{score}</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg text-center">
                  <p className="text-sm text-gray-600">Highest Level</p>
                  <p className="text-2xl font-bold text-purple-600">{level}</p>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg w-full max-w-md">
                <p className="text-center text-gray-700">{getFeedbackMessage()}</p>
              </div>

              <div className="flex space-x-4 mt-4">
                <Button
                  onClick={startGame}
                  className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-2 rounded-full flex items-center space-x-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Play Again</span>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : currentQuestion ? (
        <Card>
          <CardContent className="p-6 space-y-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <span className="text-lg font-bold text-emerald-600">Level {level}</span>
                <span className="text-sm bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full">Score: {score}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-amber-500" />
                <span className={`font-medium ${timeLeft <= 5 ? "text-red-500 animate-pulse" : "text-amber-500"}`}>
                  {timeLeft}s
                </span>
              </div>
            </div>

            <div className="flex items-center justify-center space-x-2 my-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={`${currentQuestion.num1}-${currentQuestion.operation}-${currentQuestion.num2}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="flex items-center justify-center text-3xl font-bold"
                >
                  <span>{currentQuestion.num1}</span>
                  <span className="mx-2 text-emerald-500">{currentQuestion.operation}</span>
                  <span>{currentQuestion.num2}</span>
                  <span className="mx-2">=</span>
                  <span className="text-emerald-500">?</span>
                </motion.div>
              </AnimatePresence>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {currentQuestion.options.map((option, index) => (
                <Button
                  key={`${option}-${index}`}
                  onClick={() => handleAnswerSelect(option)}
                  disabled={selectedAnswer !== null}
                  className={`p-4 text-xl font-bold rounded-xl transition-all ${
                    selectedAnswer === option
                      ? option === currentQuestion.answer
                        ? "bg-green-500 hover:bg-green-600 text-white"
                        : "bg-red-500 hover:bg-red-600 text-white"
                      : selectedAnswer !== null && option === currentQuestion.answer
                        ? "bg-green-500 hover:bg-green-600 text-white"
                        : "bg-white hover:bg-emerald-50 text-gray-800 border-2 border-emerald-200"
                  }`}
                >
                  {option}
                </Button>
              ))}
            </div>

            {selectedAnswer !== null && (
              <div
                className={`p-3 rounded-lg text-center ${
                  isCorrect ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                }`}
              >
                {isCorrect
                  ? `Correct! +${Math.floor((level * 10 + Math.floor(timeLeft / 2)) * Math.min(1 + streak * 0.1, 2))} points`
                  : `Incorrect! The answer is ${currentQuestion.answer}`}
              </div>
            )}

            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-1">
                <span className="text-xs text-gray-500">Streak:</span>
                <div className="flex">
                  {[...Array(Math.min(streak, 5))].map((_, i) => (
                    <span key={i} className="text-amber-500">
                      🔥
                    </span>
                  ))}
                  {streak > 5 && <span className="text-xs text-amber-500">+{streak - 5}</span>}
                </div>
              </div>
              <div>
                <Button variant="outline" size="sm" onClick={endGame} className="text-gray-500 border-gray-300">
                  End Game
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : null}
    </div>
  )
}
