"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Logo } from "./logo"
import { HamburgerMenu } from "./hamburger-menu"
import { motion } from "framer-motion"
import dynamic from "next/dynamic"

// Dynamically import the tutorial component to avoid SSR issues
const TutorialModalClient = dynamic(
  () => import("@/components/tutorial/tutorial-modal").then((mod) => ({ default: mod.TutorialModal })),
  { ssr: false },
)

interface NavigationWrapperProps {
  children: React.ReactNode
}

export function NavigationWrapper({ children }: NavigationWrapperProps) {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isHelpMenuOpen, setIsHelpMenuOpen] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const isActive = (path: string) => {
    return pathname === path
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header
        className={`fixed top-0 left-0 right-0 z-30 transition-all duration-300 ${
          isScrolled ? "bg-white shadow-md py-2" : "bg-transparent py-4"
        }`}
      >
        <div className="container mx-auto px-4 flex justify-between items-center">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <Logo size={32} />
            <span className="font-bold text-xl">
              TalkEZ<span className="text-blue-600">v85</span>
            </span>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <Link
              href="/dashboard"
              className={`transition-colors ${
                isActive("/dashboard") ? "text-blue-600 font-medium" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Dashboard
            </Link>
            <Link
              href="/appointment"
              className={`transition-colors ${
                isActive("/appointment") ? "text-blue-600 font-medium" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Appointments
            </Link>
            <Link
              href="/chatbot"
              className={`transition-colors ${
                isActive("/chatbot") ? "text-blue-600 font-medium" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Chatbot
            </Link>
            <Link
              href="/games"
              className={`transition-colors ${
                isActive("/games") ? "text-blue-600 font-medium" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Mind Games
            </Link>
            <Link
              href="/dashboard/progress"
              className={`transition-colors ${
                isActive("/dashboard/progress") ? "text-blue-600 font-medium" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Progress
            </Link>

            {/* Help menu with tutorial restart */}
            <div className="relative">
              <button onClick={() => setIsHelpMenuOpen(!isHelpMenuOpen)} className="text-gray-600 hover:text-gray-900">
                Help
              </button>

              {isHelpMenuOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50"
                >
                  <TutorialModalClient />
                  <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    FAQs
                  </a>
                  <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    Contact Support
                  </a>
                </motion.div>
              )}
            </div>

            <Link href="/profile" className="profile-link text-gray-600 hover:text-gray-900">
              Profile
            </Link>
          </div>

          <div className="md:hidden">
            <HamburgerMenu />
          </div>
        </div>
      </header>

      <main className="pt-20">{children}</main>
    </div>
  )
}
