import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, ArrowUpRight, ArrowDownRight, Zap, Moon } from "lucide-react"

export function ProgressOverview() {
  return (
    <section className="mb-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Your Progress</h1>
          <p className="text-gray-600 mt-1">Track your mental health journey over time</p>
        </div>
        <Tabs defaultValue="30" className="w-full md:w-auto mt-4 md:mt-0">
          <TabsList>
            <TabsTrigger value="7">7 days</TabsTrigger>
            <TabsTrigger value="30">30 days</TabsTrigger>
            <TabsTrigger value="90">90 days</TabsTrigger>
            <TabsTrigger value="all">All time</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Overall Wellbeing</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold">72%</div>
                <div className="flex items-center text-emerald-500 text-sm font-medium">
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                  <span>12% from last month</span>
                </div>
              </div>
              <div className="bg-rose-100 p-3 rounded-full">
                <TrendingUp className="h-6 w-6 text-rose-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Stress Level</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold">Medium</div>
                <div className="flex items-center text-emerald-500 text-sm font-medium">
                  <ArrowDownRight className="h-4 w-4 mr-1" />
                  <span>Down from "High"</span>
                </div>
              </div>
              <div className="bg-amber-100 p-3 rounded-full">
                <Zap className="h-6 w-6 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Sleep Quality</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold">6.8 hrs</div>
                <div className="flex items-center text-amber-500 text-sm font-medium">
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                  <span>0.5 hrs from last week</span>
                </div>
              </div>
              <div className="bg-violet-100 p-3 rounded-full">
                <Moon className="h-6 w-6 text-violet-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
