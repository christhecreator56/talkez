"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Zap,
  PenLine,
  Trees,
  Wind,
  Smartphone,
  Phone,
  FolderOpen,
  Sparkles,
  Target,
  Palette,
  MessageCircle,
  Trophy,
} from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { Button } from "@/components/ui/button"

interface Task {
  id: string
  task: string
  icon: React.ReactNode
  points: number
  lastClaimed?: number // Timestamp when last claimed
}

export function ProgressCharts() {
  const [activeMetric, setActiveMetric] = useState("mood")
  const [tasks, setTasks] = useState<Task[]>([
    { id: "journal", task: "Write in a journal", icon: <PenLine className="h-5 w-5" />, points: 2 },
    { id: "nature", task: "Take a nature walk", icon: <Trees className="h-5 w-5" />, points: 3 },
    { id: "breathing", task: "Practice deep breathing", icon: <Wind className="h-5 w-5" />, points: 1 },
    { id: "screen", task: "Limit screen time", icon: <Smartphone className="h-5 w-5" />, points: 2 },
    { id: "friend", task: "Call a friend", icon: <Phone className="h-5 w-5" />, points: 2 },
    { id: "declutter", task: "Declutter a small space", icon: <FolderOpen className="h-5 w-5" />, points: 2 },
    { id: "meditation", task: "Do a guided meditation", icon: <Sparkles className="h-5 w-5" />, points: 3 },
    { id: "goal", task: "Set a daily goal", icon: <Target className="h-5 w-5" />, points: 1 },
    { id: "create", task: "Create something", icon: <Palette className="h-5 w-5" />, points: 3 },
    { id: "affirmation", task: "Say a positive affirmation", icon: <MessageCircle className="h-5 w-5" />, points: 1 },
  ])

  // Load claimed tasks from localStorage on component mount
  useEffect(() => {
    const savedTasks = localStorage.getItem("claimedTasks")
    if (savedTasks) {
      try {
        const parsedTasks = JSON.parse(savedTasks)
        setTasks((current) =>
          current.map((task) => {
            // Find this task in the saved data
            const savedTask = parsedTasks.find((t) => t.id === task.id)
            // Only update the lastClaimed property if found
            return savedTask ? { ...task, lastClaimed: savedTask.lastClaimed } : task
          }),
        )
      } catch (e) {
        console.error("Error parsing saved tasks:", e)
      }
    }
  }, [])

  // Check if a task is on cooldown (claimed less than 3 days ago)
  const isTaskOnCooldown = (task: Task) => {
    if (!task.lastClaimed) return false

    const now = Date.now()
    const threeDaysMs = 3 * 24 * 60 * 60 * 1000
    return now - task.lastClaimed < threeDaysMs
  }

  // Calculate time remaining until a task is available again
  const getTimeRemaining = (lastClaimed: number) => {
    const now = Date.now()
    const threeDaysMs = 3 * 24 * 60 * 60 * 1000
    const elapsedMs = now - lastClaimed
    const remainingMs = threeDaysMs - elapsedMs

    if (remainingMs <= 0) return "Available now"

    const days = Math.floor(remainingMs / (24 * 60 * 60 * 1000))
    const hours = Math.floor((remainingMs % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000))

    if (days > 0) {
      return `Available in ${days}d ${hours}h`
    } else {
      const minutes = Math.floor((remainingMs % (60 * 60 * 1000)) / (60 * 1000))
      return `Available in ${hours}h ${minutes}m`
    }
  }

  // Handle claiming energy points
  const handleClaimEnergy = (taskId: string, points: number) => {
    // Find the task
    const taskIndex = tasks.findIndex((t) => t.id === taskId)
    if (taskIndex === -1) return

    const task = tasks[taskIndex]

    // Check if task is on cooldown
    if (isTaskOnCooldown(task)) {
      toast({
        title: "Task on Cooldown",
        description: `This task was recently completed. ${getTimeRemaining(task.lastClaimed!)}`,
        variant: "destructive",
      })
      return
    }

    // Update the task's lastClaimed timestamp
    const updatedTasks = [...tasks]
    updatedTasks[taskIndex] = {
      ...task,
      lastClaimed: Date.now(),
    }
    setTasks(updatedTasks)

    // Save ONLY the necessary data to localStorage (avoid circular references)
    const tasksForStorage = updatedTasks.map((task) => ({
      id: task.id,
      lastClaimed: task.lastClaimed,
    }))
    localStorage.setItem("claimedTasks", JSON.stringify(tasksForStorage))

    // Update energy points
    const currentEnergy = localStorage.getItem("energyPoints")
      ? Number.parseInt(localStorage.getItem("energyPoints")!)
      : 8
    const newEnergy = currentEnergy + points
    localStorage.setItem("energyPoints", newEnergy.toString())

    // Dispatch event to update UI
    const event = new CustomEvent("energyUpdated", { detail: { points: newEnergy } })
    document.dispatchEvent(event)

    // Show toast notification
    toast({
      title: "Energy Claimed!",
      description: `You earned ${points} energy points for completing "${task.task}". Your energy bar has been updated!`,
    })
  }

  return (
    <section className="mb-10">
      <div className="space-y-6">
        <Card className="border-[#5ECFBC]/30 shadow-md">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-[#333] flex items-center">
              <Zap className="h-5 w-5 text-[#FFD166] mr-2" />
              Energy-Boosting Tasks
            </CardTitle>
            <CardDescription>
              Complete these wellness activities to gain energy points. Tasks can be completed once every 3 days.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {tasks.map((item) => {
                const onCooldown = isTaskOnCooldown(item)
                return (
                  <Card
                    key={item.id}
                    className={`border ${onCooldown ? "border-gray-200" : "border-[#B4E4E0] hover:border-[#5ECFBC]"} transition-colors`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-3">
                        <div
                          className={`w-10 h-10 rounded-full ${onCooldown ? "bg-gray-100" : "bg-[#B4E4E0]/50"} flex items-center justify-center flex-shrink-0`}
                        >
                          {item.icon}
                        </div>
                        <div className="flex-1">
                          <h3 className={`font-medium ${onCooldown ? "text-gray-500" : "text-[#333]"} mb-1`}>
                            {item.task}
                          </h3>
                          <div className="flex items-center">
                            <Zap className={`h-4 w-4 ${onCooldown ? "text-gray-400" : "text-[#FFD166]"} mr-1`} />
                            <span className={`text-sm ${onCooldown ? "text-gray-400" : "text-gray-600"}`}>
                              {item.points} energy points
                            </span>
                          </div>
                          {onCooldown && (
                            <p className="text-xs text-gray-500 mt-1">{getTimeRemaining(item.lastClaimed!)}</p>
                          )}
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className={`flex-shrink-0 ${
                            onCooldown
                              ? "border-gray-200 text-gray-400 cursor-not-allowed"
                              : "border-[#5ECFBC] hover:bg-[#5ECFBC]/10"
                          }`}
                          onClick={() => handleClaimEnergy(item.id, item.points)}
                          disabled={onCooldown}
                        >
                          {onCooldown ? "Claimed" : "Claim Energy"}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </CardContent>
        </Card>

        <Card className="border-[#FFD166]/30 shadow-md">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-[#333] flex items-center">
              <Trophy className="h-5 w-5 text-[#FF9F1C] mr-2" />
              Your Energy Progress
            </CardTitle>
            <CardDescription>Track your energy points earned through wellness activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm text-gray-500">Today's Energy</p>
                  <p className="text-2xl font-bold text-[#333]">8 points</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Weekly Total</p>
                  <p className="text-2xl font-bold text-[#333]">23 points</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Monthly Goal</p>
                  <p className="text-2xl font-bold text-[#333]">100 points</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">Monthly Progress</span>
                  <span className="text-[#5ECFBC] font-medium">45/100</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-4">
                  <div
                    className="bg-gradient-to-r from-[#5ECFBC] to-[#B4E4E0] h-4 rounded-full"
                    style={{ width: "45%" }}
                  ></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
