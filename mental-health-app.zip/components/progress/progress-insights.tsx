import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function ProgressInsights() {
  return (
    <section>
      <h2 className="text-2xl font-semibold text-gray-800 mb-6">Insights & Patterns</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Weekly Analysis</CardTitle>
            <CardDescription>Key observations from the past week</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-green-50 rounded-lg border border-green-100">
              <div className="flex items-start">
                <Badge className="bg-green-100 text-green-800 mt-0.5">Positive Trend</Badge>
                <h4 className="text-lg font-medium text-green-800 ml-3">Improved Sleep Quality</h4>
              </div>
              <p className="mt-2 text-green-700">
                Your average sleep score increased from 5.2 to 6.8 over the past week. This correlates with your
                reported decrease in anxiety levels.
              </p>
            </div>

            <div className="p-4 bg-amber-50 rounded-lg border border-amber-100">
              <div className="flex items-start">
                <Badge className="bg-amber-100 text-amber-800 mt-0.5">Area for Growth</Badge>
                <h4 className="text-lg font-medium text-amber-800 ml-3">Stress Management</h4>
              </div>
              <p className="mt-2 text-amber-700">
                Your stress levels tend to peak mid-week (Wednesday-Thursday). Consider scheduling relaxation activities
                during these days.
              </p>
            </div>

            <div className="p-4 bg-rose-50 rounded-lg border border-rose-100">
              <div className="flex items-start">
                <Badge className="bg-rose-100 text-rose-800 mt-0.5">Pattern Detected</Badge>
                <h4 className="text-lg font-medium text-rose-800 ml-3">Mood Correlation</h4>
              </div>
              <p className="mt-2 text-rose-700">
                Your mood ratings show a strong positive correlation with sleep quality (r=0.82). Focusing on sleep
                hygiene may have significant benefits for your overall wellbeing.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recommended Actions</CardTitle>
            <CardDescription>Personalized suggestions based on your data</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start p-4 border rounded-lg">
              <div className="flex-shrink-0 h-10 w-10 rounded-full bg-violet-100 flex items-center justify-center text-violet-600">
                1
              </div>
              <div className="ml-4">
                <h4 className="font-medium text-gray-800">Continue Sleep Improvement</h4>
                <p className="text-gray-600 mt-1">
                  Maintain your current sleep schedule. Consider adding the deep breathing exercise from your therapy
                  sessions to your bedtime routine.
                </p>
              </div>
            </div>

            <div className="flex items-start p-4 border rounded-lg">
              <div className="flex-shrink-0 h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
                2
              </div>
              <div className="ml-4">
                <h4 className="font-medium text-gray-800">Mid-week Stress Management</h4>
                <p className="text-gray-600 mt-1">
                  Schedule 15-minute breaks on Wednesday and Thursday afternoons for mindfulness practice or short
                  walks.
                </p>
              </div>
            </div>

            <div className="flex items-start p-4 border rounded-lg">
              <div className="flex-shrink-0 h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                3
              </div>
              <div className="ml-4">
                <h4 className="font-medium text-gray-800">Journal More Consistently</h4>
                <p className="text-gray-600 mt-1">
                  Your journal entries show positive sentiment growth. Try to maintain consistent daily journaling to
                  track your thoughts and feelings.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
