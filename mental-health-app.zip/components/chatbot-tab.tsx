"use client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar } from "@/components/ui/avatar"
import { SendHorizontal, Bot, User, Check, CheckCheck } from "lucide-react"
import React, { useRef, useEffect, useState } from "react"
import { motion } from "framer-motion"

export function ChatbotTab() {
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [typingText, setTypingText] = useState("")
  const [typingDots, setTypingDots] = useState(1)
  const [messages, setMessages] = useState([
    {
      id: "welcome",
      role: "assistant",
      content: "Hey there! 👋 I'm Emma, your mental wellness buddy. How are you feeling today?",
      status: "read",
    },
  ])
  const [input, setInput] = useState("")
  const [userTyping, setUserTyping] = useState(false)
  const [lastTypingTime, setLastTypingTime] = useState(0)

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, isTyping])

  // Simulate typing indicator dots
  useEffect(() => {
    if (isTyping) {
      const interval = setInterval(() => {
        setTypingDots((prev) => (prev % 3) + 1)
      }, 500)
      return () => clearInterval(interval)
    }
  }, [isTyping])

  // Custom scrollbar styles
  const scrollbarStyles = `
  .custom-scrollbar::-webkit-scrollbar {
    width: 10px; /* Increased width */
  }
  .custom-scrollbar::-webkit-scrollbar-track {
    background: #f9f9f9;
    border-radius: 4px;
  }
  .custom-scrollbar::-webkit-scrollbar-thumb {
    background-color: #f43f5e;
    border-radius: 4px;
    border: 2px solid #f9f9f9;
  }
  .custom-scrollbar::-webkit-scrollbar-thumb:hover {
    background-color: #e11d48;
  }
  .custom-scrollbar {
    scrollbar-width: thin;
    scrollbar-color: #f43f5e #f9f9f9;
    overflow-y: scroll !important;
    -webkit-overflow-scrolling: touch;
    max-height: 100%;
    height: 100%;
  }
`

  useEffect(() => {
    // Force scrollbar to be visible and active
    const chatContainer = document.querySelector(".custom-scrollbar")
    if (chatContainer) {
      chatContainer.scrollTop = chatContainer.scrollHeight

      // Add a small scroll up and down to "activate" the scrollbar
      setTimeout(() => {
        chatContainer.scrollTop -= 1
        setTimeout(() => {
          chatContainer.scrollTop += 1
        }, 100)
      }, 100)
    }
  }, [])

  // Simulate "seen" status for messages
  useEffect(() => {
    const lastMessage = messages[messages.length - 1]
    if (lastMessage && lastMessage.role === "user" && lastMessage.status !== "read") {
      // First set to "delivered"
      setTimeout(() => {
        setMessages((prev) => prev.map((msg) => (msg.id === lastMessage.id ? { ...msg, status: "delivered" } : msg)))
      }, 500)

      // Then set to "read" after a delay
      setTimeout(() => {
        setMessages((prev) => prev.map((msg) => (msg.id === lastMessage.id ? { ...msg, status: "read" } : msg)))
      }, 1500)
    }
  }, [messages])

  // Handle user typing indicator
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value)
    setLastTypingTime(Date.now())

    if (!userTyping) {
      setUserTyping(true)
    }

    // Clear existing timeout
    const timeoutId = setTimeout(() => {
      if (Date.now() - lastTypingTime > 1000) {
        setUserTyping(false)
      }
    }, 1500)

    return () => clearTimeout(timeoutId)
  }

  // Simulate realistic typing
  const simulateTyping = async (text: string) => {
    setIsTyping(true)

    // Calculate a realistic typing time based on message length
    // Average person types 40 WPM, so ~200 characters per minute or ~3.3 per second
    const typingSpeed = 20 // ms per character (slightly faster than average human)
    const minTypingTime = 1000 // minimum typing time in ms
    const maxTypingTime = 8000 // maximum typing time in ms

    // Calculate typing time with some randomness
    let typingTime = text.length * typingSpeed * (0.8 + Math.random() * 0.4)
    typingTime = Math.max(minTypingTime, Math.min(typingTime, maxTypingTime))

    // Add a small thinking delay before typing starts
    await new Promise((resolve) => setTimeout(resolve, 500 + Math.random() * 1000))

    // Show typing indicator for the calculated time
    await new Promise((resolve) => setTimeout(resolve, typingTime))

    setIsTyping(false)
    return text
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    // Add user message to chat
    const userMessage = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      status: "sent",
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)
    setError(null)
    setUserTyping(false)

    try {
      // Send request to API
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: messages
            .map((m) => ({ role: m.role, content: m.content }))
            .concat({ role: userMessage.role, content: userMessage.content }),
        }),
      })

      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}`)
      }

      const data = await response.json()

      // Simulate typing before showing the response
      const typedResponse = await simulateTyping(data.content)

      // Add assistant response to chat
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: typedResponse,
          status: "read",
        },
      ])
    } catch (err) {
      console.error("Error sending message:", err)
      setError("Sorry, I couldn't send that message. Can we try again?")
      setIsTyping(false)
    } finally {
      setIsLoading(false)
    }
  }

  // Focus input when component mounts
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }, [])

  return (
    <>
      <style jsx global>
        {scrollbarStyles}
      </style>
      <Card className="h-[calc(100vh-180px)] flex flex-col overflow-hidden border-rose-100 shadow-lg">
        {" "}
        {/* Dynamic height */}
        <div className="bg-rose-50 p-3 border-b border-rose-100 flex items-center">
          <Avatar className="bg-rose-100 h-10 w-10">
            <Bot className="h-5 w-5 text-rose-600" />
          </Avatar>
          <div className="ml-3">
            <h3 className="font-medium text-gray-800">Emma</h3>
            <p className="text-xs text-gray-500">{isTyping ? "typing..." : "online"}</p>
          </div>
        </div>
        <CardContent className="flex-1 flex flex-col p-0">
          <div
            className="flex-1 overflow-y-scroll p-4 custom-scrollbar"
            style={{
              scrollbarWidth: "thin",
              scrollbarColor: "#f43f5e #f9f9f9",
              overflowY: "scroll",
              maxHeight: "calc(600px - 130px)", // Account for header and input area
              WebkitOverflowScrolling: "touch", // For smooth scrolling on iOS
            }}
          >
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`flex items-start gap-2 max-w-[80%] ${message.role === "user" ? "flex-row-reverse" : ""}`}
                  >
                    <Avatar className={message.role === "assistant" ? "bg-rose-100" : "bg-violet-100"}>
                      {message.role === "assistant" ? (
                        <Bot className="h-5 w-5 text-rose-600" />
                      ) : (
                        <User className="h-5 w-5 text-violet-600" />
                      )}
                    </Avatar>
                    <div className="flex flex-col">
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className={`rounded-lg px-4 py-2 ${
                          message.role === "assistant"
                            ? "bg-rose-100 text-gray-800 rounded-tl-none"
                            : "bg-violet-100 text-gray-800 rounded-tr-none"
                        }`}
                      >
                        {message.content.split("\n").map((text, i) => (
                          <React.Fragment key={i}>
                            {text}
                            {i < message.content.split("\n").length - 1 && <br />}
                          </React.Fragment>
                        ))}
                      </motion.div>
                      {message.role === "user" && (
                        <div className="flex justify-end mt-1 mr-1">
                          {message.status === "sent" && <Check className="h-3 w-3 text-gray-400" />}
                          {message.status === "delivered" && <Check className="h-3 w-3 text-gray-500" />}
                          {message.status === "read" && <CheckCheck className="h-3 w-3 text-violet-500" />}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex items-start gap-2 max-w-[80%]">
                    <Avatar className="bg-rose-100">
                      <Bot className="h-5 w-5 text-rose-600" />
                    </Avatar>
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="rounded-lg px-4 py-2 bg-rose-100 text-gray-800 rounded-tl-none"
                    >
                      <div className="flex space-x-1">
                        <div
                          className="h-2 w-2 bg-rose-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0ms" }}
                        ></div>
                        <div
                          className="h-2 w-2 bg-rose-400 rounded-full animate-bounce"
                          style={{ animationDelay: "150ms" }}
                        ></div>
                        <div
                          className="h-2 w-2 bg-rose-400 rounded-full animate-bounce"
                          style={{ animationDelay: "300ms" }}
                        ></div>
                      </div>
                    </motion.div>
                  </div>
                </div>
              )}

              {error && (
                <div className="flex justify-start">
                  <div className="flex items-start gap-2 max-w-[80%]">
                    <Avatar className="bg-red-100">
                      <Bot className="h-5 w-5 text-red-600" />
                    </Avatar>
                    <div className="rounded-lg px-4 py-2 bg-red-100 text-gray-800 rounded-tl-none">{error}</div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </div>

          <div className="p-4 border-t relative">
            {userTyping && (
              <div className="absolute -top-6 left-4 text-xs text-gray-500 bg-white px-2 py-1 rounded-full shadow-sm">
                You are typing...
              </div>
            )}
            <form onSubmit={handleSubmit} className="flex gap-2 p-3">
              {" "}
              {/* Added padding */}
              <Input
                ref={inputRef}
                value={input}
                onChange={handleInputChange}
                placeholder="Type your message..."
                disabled={isLoading}
                className="flex-1 border-rose-200 focus:border-rose-400 rounded-full pl-4 py-3 text-base" /* Increased padding and font size */
              />
              <Button
                type="submit"
                size="icon"
                disabled={isLoading || !input.trim()}
                className="bg-rose-500 hover:bg-rose-600 rounded-full h-12 w-12" /* Increased size */
              >
                <SendHorizontal className="h-6 w-6" /> {/* Increased icon size */}
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>
    </>
  )
}
