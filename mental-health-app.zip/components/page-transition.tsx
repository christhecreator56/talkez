"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { LoadingScreen } from "./loading-screen"

export function PageTransition({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const handleStart = () => {
      setLoading(true)
    }

    const handleComplete = () => {
      setTimeout(() => {
        setLoading(false)
      }, 800) // Short delay to ensure the loading screen is visible
    }

    // Add event listeners for navigation events
    document.addEventListener("beforeNavigate", handleStart)
    document.addEventListener("afterNavigate", handleComplete)

    // Simulate navigation events for links
    const handleLinkClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      const link = target.closest("a")

      if (link && link.href && link.href.startsWith(window.location.origin) && !e.ctrlKey && !e.metaKey) {
        handleStart()
        // The actual navigation will happen naturally
        setTimeout(handleComplete, 1500) // Ensure loading screen is cleared even if navigation fails
      }
    }

    document.addEventListener("click", handleLinkClick)

    return () => {
      document.removeEventListener("beforeNavigate", handleStart)
      document.removeEventListener("afterNavigate", handleComplete)
      document.removeEventListener("click", handleLinkClick)
    }
  }, [])

  return (
    <>
      {loading && <LoadingScreen />}
      {children}
    </>
  )
}
