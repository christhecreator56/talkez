"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight, Mail, Phone, BadgeIcon as IdCard, Zap, Lock, User } from "lucide-react"
import { LoadingScreen } from "@/components/loading-screen"
import { motion } from "framer-motion"
import { toast } from "@/hooks/use-toast"

// Counselor credentials (in a real app, this would be in a secure database)
const ADMIN_CREDENTIALS = [
  { id: "dr-nisha", password: "admin1", name: "Dr. Nisha", role: "counselor" },
  { id: "dr-lavanya", password: "admin2", name: "Dr. Lavanya", role: "counselor" },
  { id: "dr-sangeetha", password: "admin3", name: "Dr. Sangeetha", role: "counselor" },
  { id: "dr-harikumar", password: "admin4", name: "Dr. Harikumar", role: "counselor" },
  { id: "admin", password: "admin", name: "System Admin", role: "admin" },
]

export function LoginForm() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  // Student login fields
  const [email, setEmail] = useState("")
  const [regNumber, setRegNumber] = useState("")
  const [phone, setPhone] = useState("")

  // Admin login fields
  const [userId, setUserId] = useState("")
  const [password, setPassword] = useState("")

  const handleStudentSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Simulate authentication
    setTimeout(() => {
      setIsLoading(false)
      router.push("/dashboard")
    }, 1500)
  }

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    // Simple authentication logic
    const admin = ADMIN_CREDENTIALS.find((cred) => cred.id === userId.toLowerCase() && cred.password === password)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (admin) {
      // Store admin info in localStorage (in a real app, use secure cookies/JWT)
      localStorage.setItem(
        "adminUser",
        JSON.stringify({
          id: admin.id,
          name: admin.name,
          role: admin.role,
        }),
      )

      toast({
        title: "Login Successful",
        description: `Welcome back, ${admin.name}!`,
      })

      router.push("/admin/dashboard")
    } else {
      setError("Invalid credentials. Please try again.")
      setIsLoading(false)
    }
  }

  return (
    <>
      {isLoading && <LoadingScreen />}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        <Card className="w-full shadow-lg border-none bg-white rounded-3xl overflow-hidden">
          <motion.div
            className="bg-[#B4E4E0] p-6 flex flex-col items-center"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <motion.div
              className="w-20 h-20 bg-white rounded-full flex items-center justify-center mb-4 shadow-md"
              whileHover={{ scale: 1.05, rotate: 5 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <Zap className="h-10 w-10 text-[#FFD166]" />
            </motion.div>
            <CardTitle className="text-2xl text-center text-[#333] mb-1">Welcome to TalkEZ</CardTitle>
            <CardDescription className="text-center text-[#333]/70">
              Your mental wellness companion
              <span className="ml-2 text-xs bg-[#FFD166] text-[#333] px-2 py-0.5 rounded-full font-medium">v85</span>
            </CardDescription>
          </motion.div>

          <Tabs defaultValue="student" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-[#B4E4E0]/30 p-1 rounded-full mx-auto max-w-[90%] mt-6">
              <TabsTrigger
                value="student"
                className="rounded-full data-[state=active]:bg-[#5ECFBC] data-[state=active]:text-white"
              >
                Student
              </TabsTrigger>
              <TabsTrigger
                value="admin"
                className="rounded-full data-[state=active]:bg-[#5ECFBC] data-[state=active]:text-white"
              >
                Admin
              </TabsTrigger>
              <TabsTrigger
                value="register"
                className="rounded-full data-[state=active]:bg-[#5ECFBC] data-[state=active]:text-white"
              >
                Register
              </TabsTrigger>
            </TabsList>

            <TabsContent value="student">
              <form onSubmit={handleStudentSubmit}>
                <CardContent className="space-y-4 pt-6">
                  <motion.div
                    className="space-y-2"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3, duration: 0.5 }}
                  >
                    <Label htmlFor="email" className="text-[#333]">
                      Email Address
                    </Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-[#5ECFBC]" />
                      <Input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@example.com"
                        className="pl-10 py-3 text-base rounded-xl border-[#B4E4E0] focus:border-[#5ECFBC] focus:ring-[#5ECFBC]"
                        required
                      />
                    </div>
                  </motion.div>

                  <motion.div
                    className="space-y-2"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4, duration: 0.5 }}
                  >
                    <Label htmlFor="register" className="text-[#333]">
                      Register Number
                    </Label>
                    <div className="relative">
                      <IdCard className="absolute left-3 top-3 h-4 w-4 text-[#FFD166]" />
                      <Input
                        id="register"
                        value={regNumber}
                        onChange={(e) => setRegNumber(e.target.value)}
                        placeholder="e.g. REG12345"
                        className="pl-10 rounded-xl border-[#B4E4E0] focus:border-[#FFD166] focus:ring-[#FFD166]"
                        required
                      />
                    </div>
                  </motion.div>

                  <motion.div
                    className="space-y-2"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5, duration: 0.5 }}
                  >
                    <Label htmlFor="phone" className="text-[#333]">
                      Phone Number
                    </Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-3 h-4 w-4 text-[#FF9F1C]" />
                      <Input
                        id="phone"
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="(123) 456-7890"
                        className="pl-10 rounded-xl border-[#B4E4E0] focus:border-[#FF9F1C] focus:ring-[#FF9F1C]"
                        required
                      />
                    </div>
                  </motion.div>

                  <motion.div
                    className="pt-2"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6, duration: 0.5 }}
                  >
                    <div className="bg-[#B4E4E0]/30 p-3 rounded-xl flex items-center">
                      <div className="w-8 h-8 rounded-full bg-[#B4E4E0] flex items-center justify-center mr-3">
                        <Zap className="h-4 w-4 text-[#333]" />
                      </div>
                      <p className="text-sm text-[#333]/80">
                        Sign in to track your mental wellness journey and earn energy points!
                      </p>
                    </div>
                  </motion.div>
                </CardContent>

                <CardFooter className="pb-6">
                  <motion.button
                    type="submit"
                    className="w-full py-4 text-base rounded-xl bg-gradient-to-r from-[#5ECFBC] to-[#4DB6A5] text-white font-medium flex items-center justify-center"
                    disabled={isLoading}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7, duration: 0.5 }}
                  >
                    {isLoading ? "Signing in..." : "Sign In"}
                    {!isLoading && <ArrowRight className="ml-2 h-5 w-5" />}
                  </motion.button>
                </CardFooter>
              </form>
            </TabsContent>

            <TabsContent value="admin">
              <form onSubmit={handleAdminSubmit}>
                <CardContent className="space-y-4 pt-6">
                  <motion.div
                    className="space-y-2"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3, duration: 0.5 }}
                  >
                    <Label htmlFor="userId" className="text-[#333]">
                      User ID
                    </Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-[#5ECFBC]" />
                      <Input
                        id="userId"
                        value={userId}
                        onChange={(e) => setUserId(e.target.value)}
                        placeholder="Enter your user ID"
                        className="pl-10 py-3 text-base rounded-xl border-[#B4E4E0] focus:border-[#5ECFBC] focus:ring-[#5ECFBC]"
                        required
                      />
                    </div>
                  </motion.div>

                  <motion.div
                    className="space-y-2"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4, duration: 0.5 }}
                  >
                    <Label htmlFor="password" className="text-[#333]">
                      Password
                    </Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-[#5ECFBC]" />
                      <Input
                        id="password"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter your password"
                        className="pl-10 rounded-xl border-[#B4E4E0] focus:border-[#5ECFBC] focus:ring-[#5ECFBC]"
                        required
                      />
                    </div>
                  </motion.div>

                  {error && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="bg-red-50 text-red-500 p-3 rounded-lg text-sm"
                    >
                      {error}
                    </motion.div>
                  )}

                  <motion.div
                    className="pt-2"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6, duration: 0.5 }}
                  >
                    <div className="bg-[#B4E4E0]/30 p-3 rounded-xl flex items-center">
                      <div className="w-8 h-8 rounded-full bg-[#B4E4E0] flex items-center justify-center mr-3">
                        <Lock className="h-4 w-4 text-[#333]" />
                      </div>
                      <p className="text-sm text-[#333]/80">Secure access for counselors and administrators only.</p>
                    </div>
                  </motion.div>
                </CardContent>

                <CardFooter className="pb-6">
                  <motion.button
                    type="submit"
                    className="w-full py-4 text-base rounded-xl bg-gradient-to-r from-[#5ECFBC] to-[#4DB6A5] text-white font-medium flex items-center justify-center"
                    disabled={isLoading}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7, duration: 0.5 }}
                  >
                    {isLoading ? "Signing in..." : "Admin Sign In"}
                    {!isLoading && <ArrowRight className="ml-2 h-5 w-5" />}
                  </motion.button>
                </CardFooter>
              </form>
            </TabsContent>

            <TabsContent value="register">
              <CardContent className="text-center py-10">
                <motion.div
                  className="bg-[#B4E4E0]/30 p-6 rounded-xl"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="w-16 h-16 mx-auto rounded-full bg-[#FFD166] flex items-center justify-center mb-4">
                    <Mail className="h-8 w-8 text-[#333]" />
                  </div>
                  <p className="text-[#333] mb-4">
                    Please contact your college administrator to register for a new account.
                  </p>
                  <Button
                    className="bg-[#FFD166] text-[#333] hover:bg-[#FFD166]/80 rounded-xl"
                    onClick={() => (window.location.href = "mailto:support@talkez.com")}
                  >
                    Contact Support
                  </Button>
                </motion.div>
              </CardContent>
            </TabsContent>
          </Tabs>
        </Card>

        <motion.div
          className="mt-6 text-center text-white text-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.5 }}
        >
          <p>© 2024 TalkEZ. Mental Health Matters.</p>
        </motion.div>
      </motion.div>
    </>
  )
}
