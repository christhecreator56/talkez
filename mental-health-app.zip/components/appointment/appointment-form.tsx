"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { toast } from "@/hooks/use-toast"
import { motion } from "framer-motion"
import { Check, Clock, CalendarIcon, User } from "lucide-react"

// Available counselors
const counselors = [
  { id: "dr-nisha", name: "Dr. Nisha", specialty: "Anxiety & Stress Management", avatar: "N" },
  { id: "dr-lavanya", name: "Dr. Lavanya", specialty: "Depression & Mood Disorders", avatar: "L" },
  { id: "dr-sangeetha", name: "Dr. Sangeetha", specialty: "Academic Pressure & Career", avatar: "S" },
  { id: "dr-harikumar", name: "Dr. Harikumar", specialty: "Relationships & Social Issues", avatar: "H" },
]

// Available time slots
const timeSlots = ["9:00 AM", "10:00 AM", "11:00 AM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM"]

// Session types
const sessionTypes = [
  { id: "initial", label: "Initial Consultation (60 min)" },
  { id: "followup", label: "Follow-up Session (45 min)" },
  { id: "crisis", label: "Crisis Support (30 min)" },
]

// Add this interface after the existing imports
interface TimeSlot {
  id: string
  time: string
  available: boolean
}

export function AppointmentForm() {
  const [date, setDate] = useState<Date | undefined>(undefined)
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string | null>(null)
  const [selectedCounselor, setSelectedCounselor] = useState<string | null>(null)
  const [sessionType, setSessionType] = useState<string>("initial")
  const [notes, setNotes] = useState("")
  const [step, setStep] = useState(1)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isBooked, setIsBooked] = useState(false)
  const [bookingDetails, setBookingDetails] = useState<any>(null)

  // Add state for available time slots
  const [availableTimeSlots, setAvailableTimeSlots] = useState<TimeSlot[]>([])

  // Add this function inside the AppointmentForm component, after the state declarations
  const getCounselorAvailability = (counselorId: string, dayOfWeek: number): TimeSlot[] => {
    const storedAvailability = localStorage.getItem("counselorAvailability")

    if (!storedAvailability)
      return timeSlots.map((time) => ({
        id: `${counselorId}-${dayOfWeek}-${time}`,
        time,
        available: true, // Default to available if no data
      }))

    try {
      const availabilityData = JSON.parse(storedAvailability)
      const counselorDayData = availabilityData.find(
        (item) => item.counselorId === counselorId && item.dayOfWeek === dayOfWeek,
      )

      if (counselorDayData) {
        return counselorDayData.slots
      }

      // If no data for this counselor/day, return all slots as unavailable
      return timeSlots.map((time) => ({
        id: `${counselorId}-${dayOfWeek}-${time}`,
        time,
        available: false,
      }))
    } catch (error) {
      console.error("Error parsing counselor availability:", error)
      return timeSlots.map((time) => ({
        id: `${counselorId}-${dayOfWeek}-${time}`,
        time,
        available: true, // Default to available on error
      }))
    }
  }

  // Add this function to check if a time slot is booked
  const isTimeSlotBooked = (counselorId: string, date: Date, time: string): boolean => {
    const storedAppointments = localStorage.getItem("bookedAppointments")

    if (!storedAppointments) return false

    try {
      const appointments = JSON.parse(storedAppointments)
      return appointments.some(
        (appointment) =>
          appointment.counselorId === counselorId &&
          appointment.date === date.toLocaleDateString() &&
          appointment.time === time,
      )
    } catch (error) {
      console.error("Error parsing booked appointments:", error)
      return false
    }
  }

  // Add useEffect to update available time slots when date or selected counselor changes
  useEffect(() => {
    if (date && selectedCounselor) {
      const dayOfWeek = date.getDay()
      const slots = getCounselorAvailability(selectedCounselor, dayOfWeek)
      setAvailableTimeSlots(slots)
    } else {
      setAvailableTimeSlots([])
    }
  }, [date, selectedCounselor])

  // Update the getAvailableTimeSlots function
  const getAvailableTimeSlots = () => {
    if (!date || !selectedCounselor) return []

    // Filter out slots that are not available or already booked
    return availableTimeSlots
      .filter((slot) => slot.available)
      .filter((slot) => !isTimeSlotBooked(selectedCounselor, date, slot.time))
      .map((slot) => slot.time)
  }

  // Add save appointment function
  const saveAppointment = (appointmentData) => {
    const storedAppointments = localStorage.getItem("bookedAppointments")
    let appointments = []

    if (storedAppointments) {
      try {
        appointments = JSON.parse(storedAppointments)
      } catch (error) {
        console.error("Error parsing booked appointments:", error)
      }
    }

    appointments.push(appointmentData)
    localStorage.setItem("bookedAppointments", JSON.stringify(appointments))
  }

  // Update the handleSubmit function to save appointment data
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Create appointment data
    const appointmentData = {
      id: Date.now().toString(),
      date: date?.toLocaleDateString(),
      time: selectedTimeSlot,
      counselorId: selectedCounselor,
      counselorName: counselors.find((c) => c.id === selectedCounselor)?.name,
      sessionType,
      notes,
      status: "upcoming",
    }

    // Save to localStorage (in a real app, this would be an API call)
    saveAppointment(appointmentData)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      setIsBooked(true)

      // Store booking details for confirmation
      const counselor = counselors.find((c) => c.id === selectedCounselor)
      const sessionTypeLabel = sessionTypes.find((s) => s.id === sessionType)?.label

      setBookingDetails({
        date: date?.toLocaleDateString(),
        time: selectedTimeSlot,
        counselor: counselor?.name,
        sessionType: sessionTypeLabel,
        notes: notes,
      })

      // Show success toast
      toast({
        title: "Appointment Booked!",
        description: `Your appointment has been scheduled for ${date?.toLocaleDateString()} at ${selectedTimeSlot}.`,
      })
    }, 1500)
  }

  const resetForm = () => {
    setDate(undefined)
    setSelectedTimeSlot(null)
    setSelectedCounselor(null)
    setSessionType("initial")
    setNotes("")
    setStep(1)
    setIsBooked(false)
    setBookingDetails(null)
  }

  const handlePreviousStep = () => {
    setStep((prev) => Math.max(1, prev - 1))
  }

  const handleNextStep = () => {
    if (step === 1 && !date) {
      toast({
        title: "Please select a date",
        variant: "destructive",
      })
      return
    }

    if (step === 2 && !selectedTimeSlot) {
      toast({
        title: "Please select a time slot",
        variant: "destructive",
      })
      return
    }

    if (step === 3 && !selectedCounselor) {
      toast({
        title: "Please select a counselor",
        variant: "destructive",
      })
      return
    }

    setStep((prev) => Math.min(4, prev + 1))
  }

  // If appointment is booked, show confirmation
  if (isBooked && bookingDetails) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="border-[#5ECFBC] shadow-lg">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center mb-6">
              <div className="w-16 h-16 rounded-full bg-[#5ECFBC] flex items-center justify-center mb-4">
                <Check className="h-8 w-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-[#333] mb-2">Appointment Confirmed!</h2>
              <p className="text-gray-600">Your appointment has been successfully scheduled.</p>
            </div>

            <div className="bg-[#B4E4E0]/20 rounded-xl p-6 mb-6">
              <h3 className="font-semibold text-[#333] mb-4">Appointment Details</h3>

              <div className="space-y-4">
                <div className="flex items-start">
                  <CalendarIcon className="h-5 w-5 text-[#5ECFBC] mt-0.5 mr-3" />
                  <div>
                    <p className="font-medium text-[#333]">Date</p>
                    <p className="text-gray-600">{bookingDetails.date}</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Clock className="h-5 w-5 text-[#5ECFBC] mt-0.5 mr-3" />
                  <div>
                    <p className="font-medium text-[#333]">Time</p>
                    <p className="text-gray-600">{bookingDetails.time}</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <User className="h-5 w-5 text-[#5ECFBC] mt-0.5 mr-3" />
                  <div>
                    <p className="font-medium text-[#333]">Counselor</p>
                    <p className="text-gray-600">{bookingDetails.counselor}</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Clock className="h-5 w-5 text-[#5ECFBC] mt-0.5 mr-3" />
                  <div>
                    <p className="font-medium text-[#333]">Session Type</p>
                    <p className="text-gray-600">{bookingDetails.sessionType}</p>
                  </div>
                </div>

                {bookingDetails.notes && (
                  <div className="border-t border-[#5ECFBC]/30 pt-4 mt-4">
                    <p className="font-medium text-[#333] mb-2">Additional Notes</p>
                    <p className="text-gray-600">{bookingDetails.notes}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <p className="text-amber-800 text-sm">
                <strong>Important:</strong> You will receive a confirmation email with these details. Please arrive 10
                minutes before your scheduled appointment time.
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={resetForm} className="w-full bg-[#5ECFBC] hover:bg-[#4DB6A5] text-white">
              Book Another Appointment
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    )
  }

  return (
    <Card className="border-[#5ECFBC]/30 shadow-lg">
      <CardContent className="p-6">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-[#333]">Book Your Appointment</h2>
            <div className="flex items-center">
              <div className={`w-2.5 h-2.5 rounded-full ${step >= 1 ? "bg-[#5ECFBC]" : "bg-gray-300"} mr-1`}></div>
              <div className={`w-2.5 h-2.5 rounded-full ${step >= 2 ? "bg-[#5ECFBC]" : "bg-gray-300"} mr-1`}></div>
              <div className={`w-2.5 h-2.5 rounded-full ${step >= 3 ? "bg-[#5ECFBC]" : "bg-gray-300"} mr-1`}></div>
              <div className={`w-2.5 h-2.5 rounded-full ${step >= 4 ? "bg-[#5ECFBC]" : "bg-gray-300"}`}></div>
            </div>
          </div>

          <div className="relative pb-4">
            <div className="absolute left-0 top-0 h-full w-full flex justify-between">
              <div className="w-1/4 border-b-2 border-[#5ECFBC]"></div>
              <div className={`w-1/4 border-b-2 ${step >= 2 ? "border-[#5ECFBC]" : "border-gray-200"}`}></div>
              <div className={`w-1/4 border-b-2 ${step >= 3 ? "border-[#5ECFBC]" : "border-gray-200"}`}></div>
              <div className={`w-1/4 border-b-2 ${step >= 4 ? "border-[#5ECFBC]" : "border-gray-200"}`}></div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Step 1: Select Date */}
          {step === 1 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-4"
            >
              <h3 className="text-lg font-medium text-[#333] mb-4">Select a Date</h3>
              <div className="flex justify-center">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  className="rounded-md border border-[#B4E4E0] mx-auto max-w-full" /* Added max-width */
                  styles={{
                    day: { height: "40px", width: "40px" } /* Larger day cells */,
                    button: { fontSize: "1rem" } /* Larger font */,
                  }}
                  disabled={(date) => {
                    // Disable weekends, past dates, and dates more than 30 days in the future
                    const now = new Date()
                    const maxDate = new Date()
                    maxDate.setDate(maxDate.getDate() + 30)

                    const day = date.getDay()
                    return date < now || date > maxDate || day === 0 || day === 6
                  }}
                />
              </div>
              <div className="text-center text-sm text-gray-500 mt-4">
                <p>Appointments are available Monday to Friday</p>
                <p>You can book up to 30 days in advance</p>
              </div>
            </motion.div>
          )}

          {/* Step 2: Select Time Slot */}
          {step === 2 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-4"
            >
              <h3 className="text-lg font-medium text-[#333] mb-4">
                Select a Time Slot for {date?.toLocaleDateString()}
              </h3>

              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-500 mb-2">All Time Slots:</h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {availableTimeSlots.map((slot) => (
                    <div
                      key={slot.id}
                      className={`py-3 px-4 rounded-lg border text-center flex items-center justify-center ${
                        slot.available
                          ? "border-green-200 bg-green-50 text-green-700"
                          : "border-red-200 bg-red-50 text-red-700"
                      }`}
                    >
                      <div
                        className={`w-2 h-2 rounded-full mr-2 ${slot.available ? "bg-green-500" : "bg-red-500"}`}
                      ></div>
                      {slot.time}
                    </div>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-1"></span> Available
                  <span className="inline-block w-2 h-2 rounded-full bg-red-500 ml-3 mr-1"></span> Unavailable
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {getAvailableTimeSlots().length > 0 ? (
                  getAvailableTimeSlots().map((time) => (
                    <Button
                      key={time}
                      type="button"
                      variant="outline"
                      className={`py-6 px-4 text-base ${
                        selectedTimeSlot === time
                          ? "bg-[#5ECFBC] text-white border-[#5ECFBC]"
                          : "border-[#B4E4E0] hover:border-[#5ECFBC] hover:bg-[#B4E4E0]/20"
                      }`} /* Increased padding and font size */
                      onClick={() => setSelectedTimeSlot(time)}
                    >
                      <Clock className="h-5 w-5 mr-2" /> {/* Increased icon size */}
                      {time}
                    </Button>
                  ))
                ) : (
                  <div className="col-span-3 text-center p-6 bg-gray-50 rounded-lg">
                    <p className="text-gray-500">No available time slots for this date and counselor.</p>
                    <p className="text-gray-500 text-sm mt-2">Please select a different date or counselor.</p>
                  </div>
                )}
              </div>

              {/* {getAvailableTimeSlots().length === 0 && (
                <div className="text-center p-6 bg-gray-50 rounded-lg">
                  <p className="text-gray-500">No time slots available for this date.</p>
                  <p className="text-gray-500 text-sm mt-2">Please select a different date.</p>
                </div>
              )} */}
            </motion.div>
          )}

          {/* Step 3: Select Counselor */}
          {step === 3 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-4"
            >
              <h3 className="text-lg font-medium text-[#333] mb-4">Select a Counselor</h3>

              <div className="grid grid-cols-1 gap-3">
                {counselors.map((counselor) => (
                  <div
                    key={counselor.id}
                    className={`p-4 rounded-lg border cursor-pointer transition-all ${
                      selectedCounselor === counselor.id
                        ? "border-[#5ECFBC] bg-[#5ECFBC]/10"
                        : "border-gray-200 hover:border-[#B4E4E0] hover:bg-[#B4E4E0]/5"
                    }`}
                    onClick={() => setSelectedCounselor(counselor.id)}
                  >
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-[#B4E4E0] flex items-center justify-center mr-3 text-[#333] font-medium">
                        {counselor.avatar}
                      </div>
                      <div>
                        <h4 className="font-medium text-[#333]">{counselor.name}</h4>
                        <p className="text-sm text-gray-500">{counselor.specialty}</p>
                      </div>
                      {selectedCounselor === counselor.id && (
                        <div className="ml-auto">
                          <div className="w-6 h-6 rounded-full bg-[#5ECFBC] flex items-center justify-center">
                            <Check className="h-4 w-4 text-white" />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* Step 4: Additional Details */}
          {step === 4 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              <h3 className="text-lg font-medium text-[#333] mb-4">Appointment Details</h3>

              <div className="bg-[#B4E4E0]/20 rounded-lg p-4 mb-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Date</p>
                    <p className="font-medium text-[#333]">{date?.toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Time</p>
                    <p className="font-medium text-[#333]">{selectedTimeSlot}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Counselor</p>
                    <p className="font-medium text-[#333]">
                      {counselors.find((c) => c.id === selectedCounselor)?.name}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="sessionType" className="text-[#333] mb-2 block">
                    Session Type
                  </Label>
                  <RadioGroup value={sessionType} onValueChange={setSessionType} className="flex flex-col space-y-2">
                    {sessionTypes.map((type) => (
                      <div key={type.id} className="flex items-center space-x-2">
                        <RadioGroupItem value={type.id} id={type.id} />
                        <Label htmlFor={type.id}>{type.label}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>

                <div>
                  <Label htmlFor="notes" className="text-[#333] mb-2 block">
                    Additional Notes (Optional)
                  </Label>
                  <Textarea
                    id="notes"
                    placeholder="Please share any specific concerns or topics you'd like to discuss"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="min-h-[100px] border-[#B4E4E0] focus:border-[#5ECFBC]"
                  />
                </div>
              </div>
            </motion.div>
          )}
        </form>
      </CardContent>

      <CardFooter className="flex justify-between border-t p-6">
        {step > 1 ? (
          <Button
            type="button"
            variant="outline"
            onClick={handlePreviousStep}
            className="border-[#B4E4E0] hover:bg-[#B4E4E0]/20"
          >
            Back
          </Button>
        ) : (
          <div></div>
        )}

        {step < 4 ? (
          <Button type="button" onClick={handleNextStep} className="bg-[#5ECFBC] hover:bg-[#4DB6A5]">
            Continue
          </Button>
        ) : (
          <Button
            type="submit"
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="bg-[#5ECFBC] hover:bg-[#4DB6A5]"
          >
            {isSubmitting ? "Booking..." : "Book Appointment"}
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
