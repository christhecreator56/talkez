"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

const slides = [
  {
    title: "Mental Wellness Matters",
    description: "Take care of your mental health with our comprehensive resources and support.",
    image: "/placeholder.svg?key=7ivu1",
  },
  {
    title: "Connect with Professionals",
    description: "Book appointments with qualified mental health professionals at your convenience.",
    image: "/placeholder.svg?key=1fvmh",
  },
  {
    title: "Engage in Mind Games",
    description: "Strengthen your cognitive abilities with our collection of mind games.",
    image: "/placeholder.svg?key=g12s6",
  },
]

export function Carousel() {
  const [current, setCurrent] = useState(0)

  const next = () => setCurrent((current + 1) % slides.length)
  const prev = () => setCurrent((current - 1 + slides.length) % slides.length)

  useEffect(() => {
    const interval = setInterval(next, 5000)
    return () => clearInterval(interval)
  }, [current])

  return (
    <div className="relative rounded-xl overflow-hidden">
      <div className="relative h-[400px] overflow-hidden rounded-xl">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === current ? "opacity-100" : "opacity-0 pointer-events-none"
            }`}
          >
            <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${slide.image})` }}>
              <div className="absolute inset-0 bg-black/20" />
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <Card className="max-w-md mx-auto bg-white/90 backdrop-blur-sm p-6 text-center">
                <h3 className="text-2xl font-bold text-rose-600 mb-2">{slide.title}</h3>
                <p className="text-gray-700">{slide.description}</p>
              </Card>
            </div>
          </div>
        ))}
      </div>

      <Button
        variant="outline"
        size="icon"
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white"
        onClick={prev}
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <Button
        variant="outline"
        size="icon"
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white"
        onClick={next}
      >
        <ChevronRight className="h-6 w-6" />
      </Button>

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            className={`w-2 h-2 rounded-full transition-colors ${index === current ? "bg-rose-500" : "bg-white/50"}`}
            onClick={() => setCurrent(index)}
          />
        ))}
      </div>
    </div>
  )
}
