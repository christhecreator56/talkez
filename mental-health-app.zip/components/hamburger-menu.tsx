"use client"

import { useState, useEffect } from "react"
import { Menu, X, Home, Brain, User, BarChart, Calendar, Zap, MessageSquare } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Logo } from "@/components/logo"
import { useRouter } from "next/navigation"
import { LoadingScreen } from "./loading-screen"
import { motion } from "framer-motion"

export function HamburgerMenu() {
  const [open, setOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const [energyPoints, setEnergyPoints] = useState(0)
  const [userLevel, setUserLevel] = useState(1)

  // Calculate user level based on energy points
  const calculateLevel = (points: number) => {
    if (points < 15) return 1
    if (points < 30) return 2
    if (points < 50) return 3
    if (points < 75) return 4
    if (points < 100) return 5
    return Math.floor(points / 20) + 1
  }

  useEffect(() => {
    // Get initial energy points from localStorage or default to 8
    const storedEnergy = localStorage.getItem("energyPoints")
    const initialEnergy = storedEnergy ? Number.parseInt(storedEnergy) : 8
    setEnergyPoints(initialEnergy)
    setUserLevel(calculateLevel(initialEnergy))

    // Listen for energy updates from the progress page
    const handleEnergyUpdate = (event) => {
      const newEnergy = event.detail.points
      setEnergyPoints(newEnergy)
      setUserLevel(calculateLevel(newEnergy))
    }

    // Add event listener
    document.addEventListener("energyUpdated", handleEnergyUpdate)

    // Clean up event listener
    return () => {
      document.removeEventListener("energyUpdated", handleEnergyUpdate)
    }
  }, [])

  const menuItems = [
    {
      name: "Home",
      href: "/dashboard",
      icon: <Home className="h-5 w-5 mr-2 text-[#333]" />,
      bgColor: "bg-[#B4E4E0]",
    },
    {
      name: "Book Appointment",
      href: "/appointment",
      icon: <Calendar className="h-5 w-5 mr-2 text-[#333]" />,
      bgColor: "bg-[#5ECFBC]",
    },
    {
      name: "Mind Games",
      href: "/games",
      icon: <Brain className="h-5 w-5 mr-2 text-[#333]" />,
      bgColor: "bg-[#FFD166]",
    },
    {
      name: "Progress",
      href: "/dashboard/progress",
      icon: <BarChart className="h-5 w-5 mr-2 text-white" />,
      bgColor: "bg-[#FF9F1C]",
    },
    {
      name: "Chat Bot",
      href: "/chatbot",
      icon: <MessageSquare className="h-5 w-5 mr-2 text-white" />,
      bgColor: "bg-[#8B5CF6]",
    },
    {
      name: "Profile",
      href: "/profile",
      icon: <User className="h-5 w-5 mr-2 text-[#333]" />,
      bgColor: "bg-[#FFD166]",
    },
  ]

  const handleLinkClick = (href) => {
    setOpen(false)
    setIsLoading(true)

    // Navigate to the selected page
    setTimeout(() => {
      router.push(href)
      setTimeout(() => {
        setIsLoading(false)
      }, 1000)
    }, 100)
  }

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  const item = {
    hidden: { x: -20, opacity: 0 },
    show: { x: 0, opacity: 1, transition: { type: "spring", stiffness: 300, damping: 24 } },
  }

  return (
    <>
      {isLoading && <LoadingScreen />}
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="text-[#333] hover:bg-[#B4E4E0] rounded-full p-3 h-12 w-12" // Increased size and padding
            onClick={() => setOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-7 w-7" /> {/* Increased icon size */}
            <span className="sr-only">Toggle menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-[280px] sm:w-[350px] bg-[#B4E4E0] border-none">
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between py-4 border-b border-[#5ECFBC]/30">
              <div className="flex items-center">
                <Logo size="small" />
                <h2 className="text-xl font-bold text-[#333] ml-2">TalkEZ</h2>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="rounded-full hover:bg-[#5ECFBC]/20"
                onClick={() => setOpen(false)}
              >
                <X className="h-5 w-5 text-[#333]" />
                <span className="sr-only">Close menu</span>
              </Button>
            </div>

            <div className="py-4 px-1">
              <motion.div
                className="mb-4 bg-white rounded-2xl p-4 shadow-md"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-[#FFD166] flex items-center justify-center text-[#333] font-bold mr-2 shadow-sm">
                      {userLevel}
                    </div>
                    <h3 className="font-semibold text-[#333]">Level {userLevel}</h3>
                  </div>
                  <div className="flex items-center">
                    <Zap className="h-4 w-4 text-[#FFD166] mr-1" />
                    <span className="font-medium text-sm">
                      {energyPoints} / {userLevel * 15}
                    </span>
                  </div>
                </div>
                <div className="bg-[#f0f0f0] rounded-full h-3 overflow-hidden shadow-inner">
                  <motion.div
                    className="h-full bg-gradient-to-r from-[#FFD166] to-[#FF9F1C]"
                    initial={{ width: "0%" }}
                    animate={{
                      width: `${((energyPoints % (userLevel * 15) || energyPoints) / (userLevel * 15)) * 100}%`,
                    }}
                    transition={{ delay: 0.3, duration: 1, ease: "easeOut" }}
                  ></motion.div>
                </div>
              </motion.div>
            </div>

            <nav className="flex-1 py-2 overflow-y-auto">
              <motion.ul className="space-y-2 px-1" variants={container} initial="hidden" animate="show">
                {menuItems.map((item) => (
                  <motion.li key={item.name} variants={item}>
                    <motion.button
                      className={`flex items-center w-full px-4 py-4 text-[#333] ${item.bgColor} hover:opacity-90 rounded-xl shadow-sm transition-all duration-200`} // Increased padding
                      onClick={() => handleLinkClick(item.href)}
                      whileHover={{ scale: 1.03, x: 5 }}
                      whileTap={{ scale: 0.97 }}
                    >
                      <div className="w-10 h-10 rounded-full bg-white/80 flex items-center justify-center mr-3">
                        {" "}
                        {/* Increased size */}
                        {item.icon}
                      </div>
                      <span className="font-medium text-base">{item.name}</span> {/* Increased font size */}
                    </motion.button>
                  </motion.li>
                ))}
              </motion.ul>
            </nav>

            <div className="border-t border-[#5ECFBC]/30 py-4">
              <div className="px-4 py-2">
                <motion.div className="bg-white rounded-xl p-4 shadow-md" whileHover={{ scale: 1.02 }}>
                  <div className="flex items-center">
                    <Logo size="small" />
                    <div className="ml-2">
                      <p className="text-sm font-medium text-[#333]">TalkEZ</p>
                      <p className="text-xs text-gray-500">Mental Health Matters</p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}
