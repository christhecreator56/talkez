"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { MessageCircle } from "lucide-react"

export function LoadingScreen() {
  const [dotIndex, setDotIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setDotIndex((prev) => (prev + 1) % 3)
    }, 500)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="fixed inset-0 bg-gradient-to-b from-[#B4E4E0] to-[#5ECFBC]/40 flex flex-col items-center justify-center z-50">
      <div className="flex flex-col items-center">
        <motion.div
          initial={{ scale: 0.8, rotate: 0 }}
          animate={{ scale: 1.1, rotate: 10 }}
          transition={{
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
            duration: 1.2,
            ease: "easeInOut",
          }}
          className="relative mb-4"
        >
          {/* Speech bubble with TalkEZ logo */}
          <div className="w-24 h-24 bg-white rounded-2xl flex items-center justify-center shadow-lg relative">
            <motion.div
              animate={{ y: [0, -3, 0] }}
              transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
              className="text-[#5ECFBC] font-bold text-xl"
            >
              TalkEZ
            </motion.div>

            {/* Speech bubble tail */}
            <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-white rotate-45"></div>
          </div>

          {/* Message circle icon */}
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2 }}
            className="absolute -right-4 -top-2 bg-[#FF9B82] p-2 rounded-full shadow-md"
          >
            <MessageCircle className="w-5 h-5 text-white" />
          </motion.div>
        </motion.div>

        {/* Loading dots */}
        <div className="flex space-x-3 mt-6">
          {[0, 1, 2].map((index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0.3 }}
              animate={{ opacity: index === dotIndex ? 1 : 0.3, scale: index === dotIndex ? 1.2 : 1 }}
              className={`w-3 h-3 rounded-full ${index === dotIndex ? "bg-[#FF9B82]" : "bg-white"}`}
            ></motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}
