import Image from "next/image"
import Link from "next/link"

export function Logo({ size = "medium" }: { size?: "small" | "medium" | "large" }) {
  const dimensions = {
    small: { width: 40, height: 40 },
    medium: { width: 50, height: 50 },
    large: { width: 80, height: 80 },
  }

  const { width, height } = dimensions[size]

  return (
    <Link href="/dashboard" className="flex items-center">
      <Image
        src="/images/talkez-logo.png"
        alt="TalkEZ - Mental Health Matters"
        width={width}
        height={height}
        className="rounded-full"
        priority
      />
    </Link>
  )
}
