"use client"
import { Button } from "@/components/ui/button"
import { useIsMounted } from "@/hooks/use-client-only"

type TutorialStep = {
  title: string
  description: string
  target: string
  position: "top" | "bottom" | "left" | "right"
}

const tutorialSteps: TutorialStep[] = [
  {
    title: "Welcome to TalkEZ v85",
    description: "This tutorial will guide you through the main features of our mental health platform.",
    target: "body",
    position: "top",
  },
  {
    title: "Dashboard Overview",
    description: "This is your personal dashboard where you can see your progress and access all features.",
    target: ".dashboard-container",
    position: "top",
  },
  {
    title: "Book Appointments",
    description: "Click here to schedule sessions with mental health professionals.",
    target: ".appointment-tab",
    position: "bottom",
  },
  {
    title: "Chat with AI Assistant",
    description: "Our AI chatbot is available 24/7 to provide support and answer questions.",
    target: ".chatbot-tab",
    position: "bottom",
  },
  {
    title: "Mind Games",
    description: "Engage with therapeutic games designed to improve mental wellness.",
    target: ".games-tab",
    position: "bottom",
  },
  {
    title: "Track Your Progress",
    description: "Monitor your mental health journey with personalized insights and charts.",
    target: ".progress-section",
    position: "right",
  },
  {
    title: "Profile Settings",
    description: "Customize your profile and privacy settings from the navigation menu.",
    target: ".profile-link",
    position: "left",
  },
]

export function TutorialSteps({
  currentStep,
  onNext,
  onPrevious,
  onClose,
}: {
  currentStep: number
  onNext: () => void
  onPrevious: () => void
  onClose: () => void
}) {
  const isMounted = useIsMounted()

  if (!isMounted) {
    return null // Don't render anything during SSR
  }

  const step = tutorialSteps[currentStep]

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-white rounded-lg p-6 max-w-md shadow-xl">
        <h3 className="text-xl font-bold mb-2">{step.title}</h3>
        <p className="mb-4 text-gray-600">{step.description}</p>
        <div className="flex justify-between items-center">
          <div className="flex space-x-2">
            <Button variant="outline" onClick={onPrevious} disabled={currentStep === 0}>
              Previous
            </Button>
            <Button onClick={currentStep < tutorialSteps.length - 1 ? onNext : onClose}>
              {currentStep < tutorialSteps.length - 1 ? "Next" : "Finish"}
            </Button>
          </div>
          <div className="text-sm text-gray-500">
            {currentStep + 1} of {tutorialSteps.length}
          </div>
        </div>
      </div>
    </div>
  )
}
