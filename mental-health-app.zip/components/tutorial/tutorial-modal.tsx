"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { X, ArrowRight, ArrowLeft, CheckCircle } from "lucide-react"
import { saveToStorage, getFromStorage } from "@/lib/local-storage"

interface TutorialStep {
  title: string
  description: string
  targetId?: string
  position?: "top" | "bottom" | "left" | "right"
}

const tutorialSteps: TutorialStep[] = [
  {
    title: "Welcome to TalkEZ v85!",
    description: "This tutorial will guide you through the main features of our mental wellness platform.",
  },
  {
    title: "Dashboard",
    description: "This is your dashboard where you can see your progress and access all features.",
    targetId: "dashboard-cards",
  },
  {
    title: "Chat with AI",
    description: "Talk to our AI assistant about your feelings and get personalized support.",
    targetId: "chatbot-card",
  },
  {
    title: "Book Appointments",
    description: "Schedule sessions with our mental health professionals.",
    targetId: "appointment-card",
  },
  {
    title: "Mind Games",
    description: "Play games designed to improve your mental wellness and earn energy points.",
    targetId: "games-card",
  },
  {
    title: "Track Your Progress",
    description: "Monitor your mental health journey with personalized insights and charts.",
    targetId: "progress-section",
    position: "right",
  },
  {
    title: "Profile Settings",
    description: "Customize your profile and privacy settings from the menu.",
    targetId: "profile-link",
    position: "left",
  },
  {
    title: "You're All Set!",
    description: "You can revisit this tutorial anytime from the help menu. Start your wellness journey now!",
  },
]

export function TutorialModal() {
  const [open, setOpen] = useState(false)
  const [step, setStep] = useState(0)
  const [highlightedElementRect, setHighlightedElementRect] = useState<DOMRect | null>(null)

  useEffect(() => {
    const tutorialCompleted = getFromStorage<boolean>("tutorial_completed")
    if (!tutorialCompleted) {
      setTimeout(() => {
        setOpen(true)
      }, 500)
    }
  }, [])

  useEffect(() => {
    if (open && tutorialSteps[step].targetId) {
      const element = document.getElementById(tutorialSteps[step].targetId!)
      if (element) {
        setHighlightedElementRect(element.getBoundingClientRect())
      } else {
        setHighlightedElementRect(null)
      }
    } else {
      setHighlightedElementRect(null)
    }
  }, [step, open])

  const nextStep = () => {
    if (step < tutorialSteps.length - 1) {
      setStep(step + 1)
    } else {
      closeModal()
    }
  }

  const prevStep = () => {
    if (step > 0) {
      setStep(step - 1)
    }
  }

  const closeModal = () => {
    setOpen(false)
    saveToStorage("tutorial_completed", true)
  }

  const skipTutorial = () => {
    closeModal()
  }

  const restartTutorial = () => {
    setStep(0)
    setOpen(true)
  }

  const getTooltipPosition = () => {
    if (!highlightedElementRect) {
      return {
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
      }
    }

    const position = tutorialSteps[step].position || "bottom"
    const padding = 20

    switch (position) {
      case "top":
        return {
          bottom: `${window.innerHeight - highlightedElementRect.top + padding}px`,
          left: `${highlightedElementRect.left + highlightedElementRect.width / 2}px`,
          transform: "translateX(-50%)",
        }
      case "right":
        return {
          top: `${highlightedElementRect.top + highlightedElementRect.height / 2}px`,
          left: `${highlightedElementRect.right + padding}px`,
          transform: "translateY(-50%)",
        }
      case "bottom":
        return {
          top: `${highlightedElementRect.bottom + padding}px`,
          left: `${highlightedElementRect.left + highlightedElementRect.width / 2}px`,
          transform: "translateX(-50%)",
        }
      case "left":
        return {
          top: `${highlightedElementRect.top + highlightedElementRect.height / 2}px`,
          right: `${window.innerWidth - highlightedElementRect.left + padding}px`,
          transform: "translateY(-50%)",
        }
      default:
        return {
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
        }
    }
  }

  return (
    <>
      <button
        onClick={restartTutorial}
        className="text-sm text-gray-600 hover:text-gray-900 flex items-center gap-2 p-2"
      >
        <span>Restart Tutorial</span>
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        {highlightedElementRect && (
          <div
            style={{
              position: "fixed",
              top: highlightedElementRect.top - 5,
              left: highlightedElementRect.left - 5,
              width: highlightedElementRect.width + 10,
              height: highlightedElementRect.height + 10,
              zIndex: 9998,
              pointerEvents: "none",
              borderRadius: "0.375rem",
              boxShadow: "0 0 0 9999px rgba(0, 0, 0, 0.5)",
            }}
          />
        )}

        <DialogContent
          style={getTooltipPosition()}
          className="z-50 bg-white text-black border-none shadow-xl rounded-lg p-6 w-full max-w-md"
        >
          <DialogHeader>
            <DialogTitle>{tutorialSteps[step].title}</DialogTitle>
            <DialogDescription>{tutorialSteps[step].description}</DialogDescription>
          </DialogHeader>

          <div className="flex justify-between items-center mt-4">
            <Button variant="outline" size="sm" onClick={prevStep} disabled={step === 0}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>

            {step === tutorialSteps.length - 1 ? (
              <Button size="sm" onClick={closeModal}>
                Finish
                <CheckCircle className="ml-2 h-4 w-4" />
              </Button>
            ) : (
              <div className="space-x-2">
                <Button variant="secondary" size="sm" onClick={skipTutorial}>
                  Skip
                  <X className="ml-2 h-4 w-4" />
                </Button>
                <Button size="sm" onClick={nextStep}>
                  Next
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            )}
          </div>

          <div className="mt-4 flex justify-center">
            {tutorialSteps.map((_, index) => (
              <div
                key={index}
                className={`h-2 w-2 rounded-full mx-1 ${index === step ? "bg-blue-500" : "bg-gray-300"}`}
              />
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
