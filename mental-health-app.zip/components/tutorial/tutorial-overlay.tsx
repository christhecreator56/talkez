"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ChevronRight, ChevronLeft, X, Zap, MessageCircle, Calendar, Brain, User } from "lucide-react"

type TutorialStep = {
  title: string
  description: string
  icon: React.ReactNode
  position: "center" | "top-left" | "top-right" | "bottom-left" | "bottom-right"
  highlight?: string
}

const tutorialSteps: TutorialStep[] = [
  {
    title: "Welcome to TalkEZ v85!",
    description: "Let's take a quick tour to help you get the most out of your mental wellness companion.",
    icon: <Zap className="h-8 w-8 text-[#FFD166]" />,
    position: "center",
  },
  {
    title: "Dashboard",
    description: "This is your personal dashboard where you can access all features and track your wellness journey.",
    icon: <Zap className="h-8 w-8 text-[#FFD166]" />,
    position: "top-left",
    highlight: "#dashboard-cards",
  },
  {
    title: "Chat with AI",
    description: "Need someone to talk to? Our AI chatbot is here to listen and provide support anytime.",
    icon: <MessageCircle className="h-8 w-8 text-[#5ECFBC]" />,
    position: "bottom-right",
    highlight: "#chatbot-card",
  },
  {
    title: "Book Appointments",
    description: "Schedule sessions with counselors directly through the app.",
    icon: <Calendar className="h-8 w-8 text-[#FF9F1C]" />,
    position: "bottom-left",
    highlight: "#appointment-card",
  },
  {
    title: "Mind Games",
    description: "Engage with fun games designed to improve mental agility and reduce stress.",
    icon: <Brain className="h-8 w-8 text-[#8B5CF6]" />,
    position: "top-right",
    highlight: "#games-card",
  },
  {
    title: "Your Profile",
    description: "Customize your profile and manage your personal information and preferences.",
    icon: <User className="h-8 w-8 text-[#EF4444]" />,
    position: "top-right",
    highlight: "#profile-link",
  },
]

export function TutorialOverlay() {
  const [currentStep, setCurrentStep] = useState(0)
  const [isVisible, setIsVisible] = useState(true)
  const [hasSeenTutorial, setHasSeenTutorial] = useState(false)

  useEffect(() => {
    // Check if user has seen the tutorial before
    const tutorialSeen = localStorage.getItem("talkez_tutorial_completed")
    if (tutorialSeen) {
      setHasSeenTutorial(true)
      setIsVisible(false)
    } else {
      setHasSeenTutorial(false)
    }
  }, [])

  const handleNext = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      completeTutorial()
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const completeTutorial = () => {
    localStorage.setItem("talkez_tutorial_completed", "true")
    setHasSeenTutorial(true)
    setIsVisible(false)
  }

  const skipTutorial = () => {
    localStorage.setItem("talkez_tutorial_completed", "true")
    setHasSeenTutorial(true)
    setIsVisible(false)
  }

  const restartTutorial = () => {
    localStorage.removeItem("talkez_tutorial_completed")
    setHasSeenTutorial(false)
    setCurrentStep(0)
    setIsVisible(true)
  }

  // If tutorial has been seen, render a small help button
  if (hasSeenTutorial) {
    return (
      <Button
        onClick={restartTutorial}
        className="fixed bottom-4 right-4 rounded-full h-12 w-12 bg-[#5ECFBC] hover:bg-[#4DB6A5] shadow-lg z-50"
        aria-label="Show tutorial"
      >
        <Zap className="h-6 w-6 text-white" />
      </Button>
    )
  }

  if (!isVisible) return null

  const currentTutorialStep = tutorialSteps[currentStep]

  // Position the tutorial card based on the current step
  const getPositionClasses = () => {
    switch (currentTutorialStep.position) {
      case "top-left":
        return "top-24 left-4"
      case "top-right":
        return "top-24 right-4"
      case "bottom-left":
        return "bottom-24 left-4"
      case "bottom-right":
        return "bottom-24 right-4"
      case "center":
      default:
        return "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
    }
  }

  // Add highlight to the specified element
  useEffect(() => {
    let element: Element | null = null
    const highlightElement = currentTutorialStep.highlight
    if (highlightElement) {
      element = document.querySelector(highlightElement)
      if (element) {
        element.classList.add("tutorial-highlight")
      }
    }

    return () => {
      if (element) {
        element.classList.remove("tutorial-highlight")
      }
    }
  }, [currentStep, currentTutorialStep.highlight])

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          transition={{ duration: 0.3 }}
          className={`fixed ${getPositionClasses()} z-50 max-w-md w-full`}
        >
          <Card className="bg-white rounded-xl shadow-xl overflow-hidden border-none">
            <div className="bg-gradient-to-r from-[#5ECFBC] to-[#4DB6A5] p-4 flex items-center">
              <div className="bg-white rounded-full p-2 mr-3">{currentTutorialStep.icon}</div>
              <h3 className="text-white text-xl font-bold">{currentTutorialStep.title}</h3>
              <button
                onClick={skipTutorial}
                className="ml-auto text-white hover:bg-white/20 rounded-full p-1"
                aria-label="Close tutorial"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6">
              <p className="text-gray-700 mb-6">{currentTutorialStep.description}</p>
              <div className="flex justify-between items-center">
                <div className="flex space-x-1">
                  {tutorialSteps.map((_, index) => (
                    <div
                      key={index}
                      className={`h-2 w-2 rounded-full ${index === currentStep ? "bg-[#5ECFBC]" : "bg-gray-300"}`}
                    />
                  ))}
                </div>
                <div className="flex space-x-2">
                  {currentStep > 0 && (
                    <Button variant="outline" onClick={handlePrevious} size="sm">
                      <ChevronLeft className="h-4 w-4 mr-1" />
                      Back
                    </Button>
                  )}
                  <Button onClick={handleNext} size="sm">
                    {currentStep < tutorialSteps.length - 1 ? (
                      <>
                        Next
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </>
                    ) : (
                      "Get Started"
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
