// Helper functions for working with localStorage in the v85 version

// Type for any object with string keys
type StorageObject = Record<string, any>

// Save data to localStorage
export function saveToStorage(key: string, data: StorageObject): void {
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(`v85_${key}`, JSON.stringify(data))
    } catch (error) {
      console.error(`Error saving to localStorage: ${error}`)
    }
  }
}

// Get data from localStorage
export function getFromStorage<T = StorageObject>(key: string): T | null {
  if (typeof window !== "undefined") {
    try {
      const data = localStorage.getItem(`v85_${key}`)
      return data ? (JSON.parse(data) as T) : null
    } catch (error) {
      console.error(`Error retrieving from localStorage: ${error}`)
      return null
    }
  }
  return null
}

// Save array data to localStorage
export function saveArrayToStorage(key: string, data: any[]): void {
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(`v85_${key}_list`, JSON.stringify(data))
    } catch (error) {
      console.error(`Error saving array to localStorage: ${error}`)
    }
  }
}

// Get array data from localStorage
export function getArrayFromStorage<T = any>(key: string): T[] {
  if (typeof window !== "undefined") {
    try {
      const data = localStorage.getItem(`v85_${key}_list`)
      return data ? (JSON.parse(data) as T[]) : []
    } catch (error) {
      console.error(`Error retrieving array from localStorage: ${error}`)
      return []
    }
  }
  return []
}

// Remove data from localStorage
export function removeFromStorage(key: string): void {
  if (typeof window !== "undefined") {
    try {
      localStorage.removeItem(`v85_${key}`)
      localStorage.removeItem(`v85_${key}_list`)
    } catch (error) {
      console.error(`Error removing from localStorage: ${error}`)
    }
  }
}
