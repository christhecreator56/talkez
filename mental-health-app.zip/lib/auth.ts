import type { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import bcrypt from "bcryptjs"
import dbConnect from "@/lib/mongodb"
import User from "@/models/User"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
  },
  providers: [
    CredentialsProvider({
      async authorize(credentials) {
        const { email, password } = credentials

        await dbConnect()

        const user = await User.findOne({ email }).select("+password")
        if (!user) {
          throw new Error("Invalid credentials")
        }

        const isMatch = await bcrypt.compare(password, user.password)
        if (!isMatch) {
          throw new Error("Invalid credentials")
        }

        const userResponse = {
          _id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
        }

        return userResponse
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token = {
          id: user._id,
          email: user.email,
          role: user.role,
        }
      }

      return token
    },
    async session({ session, token }) {
      session.user = token as any
      return session
    },
  },
  secret: JWT_SECRET,
}
