// This is a mock implementation that uses localStorage instead of MongoDB
// as requested by the user to "remove database connection"

// Mock database connection function
export async function connectToDatabase() {
  console.log("Using local storage instead of MongoDB (v85)")

  // Only access localStorage on the client side
  const getLocalStorage = () => {
    if (typeof window !== "undefined") {
      return window.localStorage
    }
    // Return a mock localStorage for server-side rendering
    return {
      getItem: () => "[]",
      setItem: () => {},
    }
  }

  return {
    connected: true,
    client: {
      db: () => ({
        collection: (name: string) => ({
          // Mock collection methods
          findOne: async (query: any) => {
            const localStorage = getLocalStorage()
            const collection = JSON.parse(localStorage.getItem(`collection_${name}`) || "[]")
            return collection.find((item: any) => Object.keys(query).every((key) => item[key] === query[key])) || null
          },
          find: async (query: any = {}) => {
            const localStorage = getLocalStorage()
            const collection = JSON.parse(localStorage.getItem(`collection_${name}`) || "[]")
            return {
              toArray: async () =>
                collection.filter(
                  (item: any) =>
                    Object.keys(query).length === 0 || Object.keys(query).every((key) => item[key] === query[key]),
                ),
            }
          },
          insertOne: async (doc: any) => {
            const localStorage = getLocalStorage()
            const collection = JSON.parse(localStorage.getItem(`collection_${name}`) || "[]")
            const newDoc = { ...doc, _id: `local_${Date.now()}_${Math.random().toString(36).substring(2, 9)}` }
            collection.push(newDoc)
            localStorage.setItem(`collection_${name}`, JSON.stringify(collection))
            return { insertedId: newDoc._id, acknowledged: true }
          },
          updateOne: async (query: any, update: any) => {
            const localStorage = getLocalStorage()
            const collection = JSON.parse(localStorage.getItem(`collection_${name}`) || "[]")
            const index = collection.findIndex((item: any) =>
              Object.keys(query).every((key) => item[key] === query[key]),
            )
            if (index !== -1) {
              if (update.$set) {
                collection[index] = { ...collection[index], ...update.$set }
              }
              localStorage.setItem(`collection_${name}`, JSON.stringify(collection))
              return { modifiedCount: 1, acknowledged: true }
            }
            return { modifiedCount: 0, acknowledged: true }
          },
          deleteOne: async (query: any) => {
            const localStorage = getLocalStorage()
            const collection = JSON.parse(localStorage.getItem(`collection_${name}`) || "[]")
            const index = collection.findIndex((item: any) =>
              Object.keys(query).every((key) => item[key] === query[key]),
            )
            if (index !== -1) {
              collection.splice(index, 1)
              localStorage.setItem(`collection_${name}`, JSON.stringify(collection))
              return { deletedCount: 1, acknowledged: true }
            }
            return { deletedCount: 0, acknowledged: true }
          },
        }),
      }),
    },
  }
}

// Create the dbConnect function that will be exported as default
async function dbConnect() {
  return connectToDatabase()
}

// Export dbConnect as the default export
export default dbConnect
