import jwt from "jsonwebtoken"

// Secret key for JWT
const JWT_SECRET = process.env.JWT_SECRET || "talkez-default-secret-key-v85"

// Generate JWT token
export function generateToken(payload: any, expiresIn = "7d") {
  return jwt.sign(payload, JWT_SECRET, { expiresIn })
}

// Verify JWT token
export function verifyToken(token: string) {
  try {
    return jwt.verify(token, JWT_SECRET)
  } catch (error) {
    return null
  }
}

// Export verifyJwtToken as an alias for verifyToken to fix the missing export error
export const verifyJwtToken = verifyToken
