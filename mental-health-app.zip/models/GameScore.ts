import mongoose from "mongoose"

const GameScoreSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: [true, "User ID is required"],
  },
  gameType: {
    type: String,
    enum: ["memory", "wordAssociation", "numberNinja", "patternPuzzle"],
    required: [true, "Game type is required"],
  },
  score: {
    type: Number,
    required: [true, "Score is required"],
  },
  level: {
    type: Number,
    default: 1,
  },
  timeSpent: {
    type: Number, // in seconds
  },
  difficulty: {
    type: String,
    enum: ["easy", "medium", "hard"],
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

// Index for finding high scores
GameScoreSchema.index({ userId: 1, gameType: 1, score: -1 })

export default mongoose.models.GameScore || mongoose.model("GameScore", GameScoreSchema)
