import mongoose from "mongoose"

const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please provide a name"],
    maxlength: [60, "Name cannot be more than 60 characters"],
  },
  email: {
    type: String,
    required: [true, "Please provide an email"],
    unique: true,
    match: [/^\S+@\S+\.\S+$/, "Please provide a valid email"],
  },
  password: {
    type: String,
    required: [true, "Please provide a password"],
    minlength: [8, "Password must be at least 8 characters"],
    select: false, // Don't return password in queries
  },
  role: {
    type: String,
    enum: ["user", "admin", "counselor"],
    default: "user",
  },
  registerNumber: {
    type: String,
    sparse: true, // Allow null/undefined values
  },
  dateOfBirth: {
    type: Date,
  },
  gender: {
    type: String,
    enum: ["male", "female", "non-binary", "other", "prefer-not-to-say"],
  },
  occupation: String,
  emergencyContact: String,
  emergencyPhone: String,
  lastActive: {
    type: Date,
    default: Date.now,
  },
  energyPoints: {
    type: Number,
    default: 0,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

export default mongoose.models.User || mongoose.model("User", UserSchema)
