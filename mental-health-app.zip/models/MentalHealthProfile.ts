import mongoose from "mongoose"

const MentalHealthProfileSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: [true, "User ID is required"],
    unique: true,
  },
  stressLevel: {
    type: String,
    enum: ["low", "moderate", "high", "severe"],
  },
  sleepQuality: {
    type: String,
    enum: ["excellent", "good", "fair", "poor"],
  },
  concerns: [
    {
      id: String,
      label: String,
      checked: Boolean,
    },
  ],
  previousTherapy: {
    type: String,
    enum: ["yes", "no"],
  },
  medications: String,
  goals: String,
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

export default mongoose.models.MentalHealthProfile || mongoose.model("MentalHealthProfile", MentalHealthProfileSchema)
